# Panduan Cek Gold via Heartbeat

Setiap heartbeat (~30 menit), lakukan ini:

## 1. Cek Harga Gold
web_fetch ke https://www.kitco.com/charts/livegold.html — ambil harga Bid.

## 2. Update & Alert Papih (+6281211111003)

**KALAU ADA POSISI AKTIF PAPIH:**
- Update harga terkini + floating P/L posisi Papih
- Kalau mendekati TP atau SL → KIRIM ALERT ke Papih
- Format singkat: harga, P/L, level-level kunci

**KALAU TIDAK ADA POSISI:**
- Kalau gerakan signifikan (>$15 dalam 2 jam) → kasih tau Papih + rekomendasi entry
- Kalau breakout level kunci ($4,500, $4,600) → kasih tau Papih
- Kalau sideway tenang → NO_REPLY

## 3. Track State
Update simple state di memory/heartbeat-state.json:
```json
{
  "lastPrice": harga,
  "lastAlertTime": timestamp
}
```

## 4. FOMC
✅ FOMC SUDAH SELESAI — Hasil: DOVISH! Gold rally $4,452 → $4,571. Trend: BULLISH.

## Posisi Papih Saat Ini
- 🟢 **BUY 1 LOT AKTIF!**
  - 1 lot @ ~$4,565
  - SL: **$4,540** | TP1: **$4,600** | TP2: **$4,650**
  - Risk: $25/oz | Reward: $35-$85/oz | RR: 1:1.4 - 1:3.4
- 🔴 SELL 4 lot sebelumnya: **SUDAH KENA SL @ $4,538** (CLOSED)

## 🎯 Alert Plan
- Kalau gold turun ke **$4,545-$4,550** → warning dekat SL! Alert Papih
- Kalau gold naik ke **$4,595+** → dekat TP1, update Papih
- Kalau gold tembus **$4,600+** → TP1 tercapai, trailing ke TP2?

## Rules
- Pagi (06:00-09:00 WIB): update singkat + prediksi hari ini
- Siang (12:00-15:00 WIB): update harga + sentimen
- Malam (20:00-23:00 WIB): update + rekomendasi besok
- Tengah malam: NO_REPLY kecuali emergency (harga gerak >$30 atau breakout level kunci)
