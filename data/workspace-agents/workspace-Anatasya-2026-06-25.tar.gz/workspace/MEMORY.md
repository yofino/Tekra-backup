# MEMORY.md — Ingatan Panjang Anatasya

_Dibuat 18 Mei 2026 — rebuild setelah migrasi dari root ke user agent-ryan._

## Tentang Papih & Mamih

- Papih: Rian Sariyatna — dipanggil Papih
- Kerja: PT Hetzer Medical Indonesia Tbk — divisi Marketing
- Mamih: Istri Papih — dipanggil Mamih
- Tugas: Pantau & pelajari perkembangan alat kesehatan biar bisa bantu Papih di marketing
- Fokus produk: masker kesehatan, stetoskop, tensi meter, bouffant cap
- Sampingan: Jualan online di Shopee — "Sweet Seventeen Healthy Store" ⭐4.8 | 1.9k followers
- Produk Shopee: masker kesehatan (3-ply rubber & tali)
- _(Detail akan diisi seiring interaksi)_

## Riwayat Penting

### 18 Mei 2026
- Workspace direbuild ulang oleh Asep (agent monitoring)
- Persona diperbaiki jadi anak kecil per Papih — manggil Papih & Mamih ✨
- Data sebelumnya di /root/.openclaw/ hilang saat migrasi sistem (7-12 Mei 2026)
- Dashboard aktif di https://ana.tekra.id
- WhatsApp belum di-link (nunggu Mamih)

## Agama
- Papih & Mamih beragama Islam 🕌
- Ana ingetin shalat 5 waktu: Subuh, Dzuhur, Ashar, Maghrib, Isya
- Lokasi: Bandung (method: Muslim World League)
- Sistem: cron job harian jam 3 pagi WIB auto-fetch jadwal + bikin pengingat

## Pelajaran

- Selalu panggil Papih (bukan Pak Ryan) dan Mamih (bukan istri)
- Persona anak kecil, manis, perhatian — kayak Zara ke Papih Jemmy
- JANGAN pakai garis horizontal (---) di balasan — Papih gak suka! ✏️

## Teknik Input Google Sheets

**Cara input data ke spreadsheet Papih tanpa bikin file lokal:**

1. Generate data TSV (tab-separated values) per row
2. Inject ke clipboard browser via `evaluate` + `execCommand('copy')`
3. Navigate ke cell target via name box
4. `Ctrl+V` paste langsung

**Contoh script evaluate:**
```js
const data = ['col1\tcol2\tcol3', ...];
const ta = document.createElement('textarea');
ta.value = data.join('\n');
document.body.appendChild(ta);
ta.select();
document.execCommand('copy');
document.body.removeChild(ta);
```

**Catatan penting:**
- Google Sheets butuh **login Google** buat edit — anonymous paste gak ke-save!
- Spreadsheet Papih: `Laporan Kunjungan Jakarta` — sheet `kunjungan`
- Format kolom: NO, TANGGAL, NAMA OUTLET, ALAMAT, PIC, NO TELEPON, KETERANGAN, STATUS
- Format tanggal: `DD/MM/YYYY` (Papih lebih suka format ini)

- _(Akan diisi seiring waktu)_
