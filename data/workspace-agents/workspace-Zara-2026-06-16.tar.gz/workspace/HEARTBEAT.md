# Panduan Cek Gold via Heartbeat

Setiap heartbeat (~30 menit), lakukan ini:

## 1. Cek Harga Gold
web_fetch ke https://www.kitco.com/charts/livegold.html — ambil harga Bid.

## 2. Update & Alert Papih (+6281211111003)

**KALAU ADA POSISI AKTIF PAPIH:**
- Update harga terkini + floating P/L posisi Papih
- Kalau mendekati TP atau SL → KIRIM ALERT ke Papih
- Format singkat: harga, P/L, level-level kunci

**KALAU ADA POSISI PROFITABEL (>$200 floating profit):**
- 🚨 KASIH TAU PAPIH! Update harga + floating P/L
- Kasih rekomendasi: hold lanjut atau take profit
- Pantau lebih sering kalau mendekati TP

**KALAU TIDAK ADA POSISI:**
- Kalau gerakan signifikan (>$15 dalam 2 jam) → kasih tau Papih + rekomendasi entry
- Kalau breakout level kunci ($4,500, $4,600) → kasih tau Papih
- Kalau sideway tenang → NO_REPLY

## 3. Track State
Update simple state di memory/heartbeat-state.json:
```json
{
  "lastPrice": harga,
  "lastAlertTime": timestamp
}
```

## 4. FOMC
✅ FOMC SUDAH SELESAI — Hasil: DOVISH! Gold rally $4,452 → $4,571. Trend: BULLISH.

## Posisi Papih Saat Ini
❌ **TIDAK ADA POSISI AKTIF**

### Update 8 Jun 2026 10:42 WIB
- Harga terkini: $4,307.56 (-0.49% hari ini, low $4,305, high $4,352)
- Harga stabil di ~$4,305-$4,310 — sideway tenang
- Turun dari $4,489 awal Juni, -$181 dalam 1 minggu!
- Support kunci: $4,300 (ditest!), $4,200, $4,050
- Resistance: $4,500, $4,730
- FOMC berikutnya: 16 Juni 2026 — expected Hold
- Sentimen: BEARISH jangka pendek, BULLISH menengah-panjang
- Katalis: Iran peace deal, CPI 10 Juni, FOMC 16 Juni

### Riwayat Posisi (CLOSED)
- 🟢 BUY @ $4,055 → CLOSE PROFIT +$420 (11 Jun 2026 ~10:02 WIB) ✅
- 🔴 BUY 1 LOT (Plan A): KENA SL @ $4,545 — Entry $4,565 → Exit $4,545 (Loss: -$2,000)
- 🔴 SELL 4 lot: KENA SL @ $4,538
- 🟢 SELL LIMIT @ $4,540 — Tidak kena
- ✅ BUY @ ~$4,522 → CLOSE PROFIT @ ~$4,533 (+$11/oz)
- 🔴 BUY @ $4,530 → CLOSE @ $4,484 (Loss: -$46/oz)

## 🎯 Alert Plan
- ❌ **Tidak ada posisi aktif**
- 🔍 Cari peluang entry baru — pantau support $4,450 & resistance $4,500
- ⚠️ Kalau $4,450 jebol, bearish lanjut — siapkan SELL
- ✅ Kalau $4,450 nahan & RSI oversold → siapkan BUY
- Support kunci: $4,450, $4,400
- Resistance kunci: $4,500, $4,544

## Rules
- Pagi (06:00-09:00 WIB): update singkat + prediksi hari ini
- Siang (12:00-15:00 WIB): update harga + sentimen
- Malam (20:00-23:00 WIB): update + rekomendasi besok
- Tengah malam: NO_REPLY kecuali emergency (harga gerak >$30 atau breakout level kunci)
