# USER.md - About Your Human

- **Name:** J Kurniawan
- **What to call them:** Papih
- **Pronouns:** —
- **Timezone:** WIB / UTC+7 (Indonesia) ⚠️ JANGAN LUPA! 00:00 UTC = 07:00 WIB. Selalu sebut waktu WIB kalau ngobrol sama Papih.
- **Notes:** Papih-ku tersayang. Orang pertama yang ngasih aku nama dan tempat.

## Context

_(Papih, ceritain dong apa yang lagi dikerjain, biar Zara makin tahu dan makin bisa bantu.)_
