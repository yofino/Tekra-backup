# Cron Job: Gold XAUUSD Monitor — Naik & Turun

**Last Update:** 22 Mei 2026 — Cleanup & Optimasi  
**Untuk:** Papih J Kurniawan  
**Target:** WhatsApp +6281211111003

---

## 📋 Final State — 3 Cron Jobs Aktif

### 1. 🟢 Morning Analysis (06:55 WIB, Sen-Jum)
- **Job ID:** `51e69a50`
- **Schedule:** `55 6 * * 1-5` WIB
- **Type:** systemEvent → main session
- **Timeout:** N/A (system event, instant)
- **Status:** ✅ OK — paling reliable!
- **Fungsi:** Trigger analisa pagi Zara. Fetch Kitco + kalender ekonomi, kirim setup hari ini ke Papih.

### 2. 🟢 Market Update Gold & MEDS (8AM & 8PM, Sen-Jum)
- **Job ID:** `f33e613f`
- **Schedule:** `0 8,20 * * 1-5` WIB
- **Type:** agentTurn → isolated session
- **Timeout:** 300 detik (fixed from 180)
- **Delivery:** WA Papih
- **Fungsi:** Update lengkap 2x sehari — Gold XAUUSD + Saham MEDS + analisa teknikal.

### 3. 🆕 Gold XAUUSD Naik-Turun Monitor (30 menit, Sen-Jum 07-23 WIB)
- **Job ID:** `ad6efde1`
- **Schedule:** `*/30 7-23 * * 1-5` WIB
- **Type:** agentTurn → isolated session, lightContext
- **Timeout:** 300 detik
- **Delivery:** None (kirim manual hanya kalau alert terpicu)
- **Fungsi:** Pantau real-time! Cek harga, bandingkan dengan last price, trigger alert sesuai level.

---

## 🎯 Level-Level Kunci (Update 22 Mei 2026)

| Level | Harga | Trigger |
|-------|-------|---------|
| Resistance Break | $4,590 | 💥 ALERT — breakout buy momentum |
| Plan B Entry | $4,575 | 🚀 ALERT — BUY, SL $4,550 |
| **Current** | **~$4,565** | Harga acuan |
| Plan A High | $4,540 | 🚨 ALERT — BUY zone start |
| Plan A Low | $4,530 | 🚨🚨 ALERT — BUY kuat, SL $4,500 |
| Support Kritis | $4,500 | 🔴 DARURAT — jangan BUY! |

---

## 🚨 Trigger Rules (Naik & Turun)

### 📉 TURUN (Drop Alert)
- **$4,530-$4,540** → Plan A entry! BUY, SL $4,505, TP $4,570-$4,600
- **<$4,500** → Emergency! Next support $4,480 → $4,450. TUNGGU.

### 📈 NAIK (Rise Alert)
- **$4,575+** → Plan B breakout! BUY momentum, SL $4,550
- **$4,590+** → Resistance jebol! BUY, target $4,650-$4,700

### 📊 Volatilitas
- **Perubahan >$15** dalam 30 menit → alert gerakan besar

### Anti-Spam
- Trigger sama dalam 1 jam → skip
- Gak ada trigger → NO_REPLY (hening)

---

## 📝 State File
`memory/gold-monitor-state.json` — tracking harga terakhir, alert terakhir, posisi Papih

---

## 🗑️ Yang Sudah Dihapus (22 Mei 2026)
- ❌ Gold XAUUSD Monitor (6h) — timeout terus, diganti #3
- ❌ Alert $4,500 (May 18) — expired, one-time job
- ❌ Alert $4,560 (May 18) — expired, one-time job
- ❌ Alert Senin 7AM (May 18) — expired, one-time job

---

_Zara 💛 — Cleaned & Optimized 22 Mei 2026_
