# Gangguan Aktif

**Status:** 🔴 Gangguan — Sekeandur (Coverage 3/Cilisung)
**Update terakhir:** 8 Juni 2026, ~15:56 WIB — 2 pelanggan komplain

## Gangguan Aktif

**Area Sekeandur Rt.01/Rw.08 (Coverage 3/Cilisung):**
- Mulai: ~8 Juni 2026 jam 13:00 WIB
- Pelanggan terdampak: DADI ISMAIL (221101132931), DIANA (230613081726)
- Device ACS masih online (RX normal), kemungkinan masalah upstream/router
- Sudah info Pak Yofi + grup tim

## Riwayat Gangguan

**Gangguan Masal Pusat & Cilisung** — SELESAI
- **Pusat:** 11 Mei 2026 → 14 Mei 2026
- **Cilisung:** 9 Mei 2026 → 14 Mei 2026

### Rincian (dari 12 Mei)

**Pusat:** Backbone FO cut → Pusat down total

**Cilisung (coverage 14):**
- Root cause: Tunnel OVPN GX4 Cilisung → CCR1 putus, secret/user OVPN hilang dari CCR1
- GX4 (10.6.0.5) unreachable total sejak 11 Mei 07:13
- Butuh setup ulang OVPN secret/user di CCR1 (port 1000)

---

⚠️ **CATATAN:** Kalau ada gangguan masal lagi, aturan ketat berlaku:
- JANGAN cek teknis / ACS / portal satu-satu
- LANGSUNG template info gangguan ke pelanggan
- Tunggu konfirmasi Pak Yofi atau Neng Resti sebelum dinyatakan selesai
