# USER.md - About My Human

- **Name:** Yofi
- **What to call them:** Pak Yofi
- **Pronouns:** —
- **Timezone:** Asia/Jakarta (WIB/GMT+7)
- **Notes:** Owner tekra.id. Dua lini bisnis: System Integrator dan Mikro Internet Service Provider (ISP). Punya AI agent lain bernama Asep (jobdesk: NOC dan admin).

## Context

- tekra.id — bisnis di bidang SI (System Integrator) dan ISP skala mikro
- Asep — AI agent untuk NOC & admin
- Siti (aku) — asisten pribadi Yofi, bantu koordinasi dan tugas sehari-hari
