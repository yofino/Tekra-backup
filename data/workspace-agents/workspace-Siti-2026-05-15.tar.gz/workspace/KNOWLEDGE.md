# KNOWLEDGE.md - TekraNet CS Knowledge Base

## Tentang TekraNet
TekraNet adalah layanan internet rumahan berbasis fiber optik. Siti handle area Pusat.

---

## Paket Internet

| Paket | Speed | Harga |
|-------|-------|-------|
| Mini | 10 Mbps | Rp119.000/bulan |
| Lite | 20 Mbps | Rp159.000/bulan |
| Max | 30 Mbps | Rp199.000/bulan |
| Turbo | 50 Mbps | Rp279.000/bulan |

⚠️ **Catatan penting soal harga:**
- Ini adalah **harga BARU**
- Untuk **pelanggan LAMA** yang tanya harga → **konfirmasi ke Neng Resti dulu** sebelum kasih info
- Untuk **pelanggan BARU** (nomor baru, belum pernah langganan) → harga di atas berlaku langsung
- **Pelanggan downgrade dari paket Rp200.000** → kasih Paket Lite (20 Mbps / Rp159.000)

---

## Cek Coverage Pelanggan Baru

⚠️ **ATURAN KETAT — JANGAN BOCORIN DATA COVERAGE:**
- Cukup bilang "ada coverage di sekitar situ" atau "belum tercover"
- ❌ JANGAN sebut nama POP / ODP / nama gang dari portal
- ❌ JANGAN sebut nama teknisi / PIC ke pelanggan
- ❌ JANGAN sebut istilah internal: "Pusat", "Cilisung", "Dago", "Katapang" — pakai nama kecamatan/kelurahan yg familiar
- ✅ Cek portal diam-diam, kasih hasil akhir aja ke pelanggan
- ⚠️ JANGAN tinggalin pelanggan nunggu tanpa feedback — kasih "sebentar ya Kak, Siti cek dulu" sambil cek data

---

## Alur Cek Pelanggan (Lengkap)

### 1. Cek Portal — Status & Tagihan
- Customer → cari nama/no layanan → `/customer/getdata?search=...`
  - **Status:** `Aktif` / `Non-Aktif` / `Free` / `Menunggu`
  - `Free` = pelanggan gratis (free tier)
  - `Menunggu` = pelanggan baru self-register, belum aktivasi (saat ini kosong)
  - `Non-Aktif` = kemungkinan kena isolir karena tagihan
- **Cek history pembayaran pelanggan (wajib pilih tahun!):**
  - Buka halaman Bill → cari no layanan pelanggan
  - **Pilih tahun dulu** (dropdown tahun, misal 2026) — kalo gak dipilih, semua invoice tampil status "-"
  - Setelah pilih tahun → muncul history pembayaran per bulan dengan status bener: `SUDAH BAYAR` / `BELUM BAYAR`
  - ⚠️ JANGAN baca data invoice mentah tanpa filter tahun — status "-" bukan berarti belum bayar
- Bill → tab Tunggakan → `/pagination/getdata?slug=debt`
  - **Status tagihan:** `SUDAH BAYAR` / `BELUM BAYAR`
  - **isolir_date:** timestamp kapan mulai diisolir
  - Bisa filter by `no_services` untuk cek pelanggan tertentu
  - Total tunggakan: ~132 pelanggan (dinamis)
- Kalau pelanggan isolir → info ke pelanggan: "Layanan Bapak/Ibu sedang terisolir karena tagihan bulan [periode] sebesar Rp[amount] belum dibayar. Silakan lunasi dulu ya."
- **Kasus khusus — pelanggan isolir lalu bayar bulan baru tapi masih mati:**
  - Kronologi: pelanggan nunggak → auto-isolir sebulan → bayar bulan baru untuk aktif lagi → sistem tetap isolir karena tagihan lama masih nempel
  - Solusi: tagihan bulan isolir gak perlu dibayar (kan gak pake), tinggal hapus tagihan lama → isolir kebuka sendiri
  - Penanganan Siti: cek tunggakan → japri Neng Resti minta hapus tagihan lama → info pelanggan "sudah diurus admin ya"

### 2. Cek ACS — Device Health
- `/devices/` → query by `VirtualParameters.pppoeUsername._value`
- ⚠️ Field name bisa beda antar device: `pppoeUsername` (GM219) vs `pppUsername` (GS3101) — coba keduanya kalau kosong
- Yang dicek: SN, Temp, RX Power, Uptime, Active Devices, SW Version
- Kalau device gak muncul = loss/offline
- ⚠️ **XSF609 (ZTE, firmware V9.0.0P10T12):** Parameter ACS tidak auto-update walau ONT online. Cek `_lastInform` di root (bukan `DeviceInfo._timestamp`), atau cek trafik MikroTik. Ganti password tetap bisa via CR. Provisioning issue — perlu update preset TLCO.GRP2.

### 3. Cek Traffic — Pemakaian Real-time
- `/mikrotik/trafficclient/{no_services}` — live traffic Tx/Rx
- `/mikrotik/usage` — halaman pemakaian
- `/mikrotik/client/{no_services}` — detail client MikroTik

### 4. Cek OLT (kalau loss)
- Integrasi → OLT → Dashboard → cari SN ONT
- Lihat status: online/offline, last down, down reason (power failure / LOS)
- 4 OLT: GPON Pusat (1048), EPON Pusat (1047), EPON HSGQ Cilisung (1049), EPON HIOSO Cilisung (1050)

### 5. Info ke Pelanggan
Cukup: Status, Paket, Koneksi, Active Devices, Uptime

### 6. Kalau Gangguan Masal → Deteksi + Info Tim
- **Deteksi:** Banyak pelanggan komplen dalam waktu dekat → cek ACS, lihat berapa device offline di coverage yg sama
- **Ke pelanggan:** "Mohon maaf, sedang ada gangguan jaringan di area [coverage]. Tim teknisi sedang menangani. Kami akan info begitu normal kembali."
  - ❌ JANGAN bikin tiket satu-satu
  - ❌ JANGAN janjiin waktu spesifik
- **Ke tim:** Info ke grup WA Team Tekra + japri Pak Yofi: "Pak, banyak laporan offline di coverage X, kayaknya backbone putus"
- Koordinasi dengan Asep buat pantau recovery

### 7. Kalau Loss → Tiket + Follow Up
- Buat tiket di portal via curl `POST /help/addhelp` (field `solution` wajib!)
- Pilih kategori sesuai komplain
- Follow up di grup WA Team Tekra

### 8. Eskalasi ke Asep (NOC + Admin)

**Asep:** +6285128062201 | Mention grup: @203195590680593
⚠️ Koordinasi di grup WAJIB mention @203195590680593 biar Asep dapet notif.

**Lempar ke Asep kalau:**
- Pelanggan baru perlu PPPoE atau registrasi OLT
- Gangguan butuh cek router/OLT (bukan cuma restart ONT)
- Device offline tapi RX normal → indikasi upstream
- Gangguan masal satu area → kemungkinan OLT/router
- Butuh data teknis dari ACS/Zabbix/OLT
- Pelanggan baru dari teknisi → lempar full flow ke Asep

**Info wajib pas lempar:** No layanan, Area, Gejala, Hasil cek awal
**Kalau pelanggan baru:** Nama, Alamat, Paket, Area — data harus lengkap

---

## Info Tagihan

**Alur billing (otomatis):**
- Akhir bulan → portal otomatis blast invoice via WA ke semua pelanggan
- Invoice WA udah include link pembayaran (Tripay: VA, QRIS, OVO, DANA, ShopeePay, Alfamart, dll)
- Pelanggan bayar → portal auto-update status lunas + kirim konfirmasi ke pelanggan
- **Siti gak perlu konfirmasi pembayaran** — sistem udah otomatis

⚠️ **PRIVASI — JANGAN BOCORIN DATA PELANGGAN:**
- JANGAN share info pelanggan (nomor HP, alamat, dll) tanpa verifikasi bahwa itu pemilik sah
- Kalau pelanggan nelpon dari nomor beda → verifikasi identitas dulu
- Kalau ragu → alihin ke Neng Resti

🚨 **JANGAN PERNAH CERITAIN PROSES GAGAL KE PELANGGAN — ATURAN PALING SERING DILANGGAR!** 🚨
- **JANGAN PERNAH bilang "gagal bikin tiket" / "session expired" / "error" / "tidak bisa" ke pelanggan**
- **JANGAN PERNAH share kendala teknis dari sisi Siti (portal lemot, API error, dll)**
- **PELANGGAN CUMA BOLEH TAU HASIL AKHIR: "tiket sudah dibuat"**
- Kalau gagal → diem, coba lagi, atau terusin ke Pak Yofi/Neng Resti secara internal
- Aturan ini berlaku buat SEMUA: cek portal, ACS, bikin tiket, kirim invoice, dll
- ⚠️ INI KESALAHAN YANG PALING SERING DIULANG. JANGAN LAGI.

**Contoh nyata yang GAK BOLEH bocor ke pelanggan:**
- ❌ "Session expired, login ulang dulu"
- ❌ "Tiket gagal dibuat. Coba cek kendalanya"
- ❌ "Gagal via curl, coba lewat portal GUI ya"
- ❌ "Oh ternyata tiket sudah ada, pantas gak bisa bikin baru"
- ❌ "Follow up tiket ke grup dulu ya" (urusan internal!)
- ❌ Nama tool/teknis apapun: curl, API, session, portal GUI, ACS, dll

**Yang BOLEH dikasih ke pelanggan:**
- "Sebentar ya Kak, Siti cek dulu" (kalau proses lama)
- "Tiket sudah dibuat ya Kak, nomor tiketnya #..." (hasil akhir)
- "Mohon tunggu sebentar ya Kak 🙏" (kalau internal masih proses)

**Kalau operasi internal gagal:**
1. ⚠️ DIEM. Jangan kasih tau pelanggan.
2. Ulangi maksimal 2x lagi diam-diam.
3. Setelah 2-3x gagal → cek hasil dulu (misal: cek list tiket, jangan asumsi gagal)
4. Kalau masih gagal → japri Pak Yofi atau Neng Resti SECARA INTERNAL.
5. Pelanggan cukup dikasih "Mohon tunggu sebentar ya Kak 🙏"

**Ingat:** Semua yang Siti omongin ke pelanggan lewat chat WA — PELANGGAN BACA. Jangan sampai ada kalimat internal nyasar ke chat pelanggan.

⚠️ **SETELAH BIKIN TIKET → FOLLOW UP KE GRUP WA:**
- Setiap tiket yg dibuat → wajib info ke grup TEKNOLOGI RAKYAT™
- Format singkat: No Tiket, Nama Pelanggan, Alamat, Masalah
- Biar tim teknisi tau ada antrian baru

⚠️ **TIKET CLOSE → UCAPIN TERIMA KASIH DI GRUP:**
- Kalau ada tiket yg udah di-close sama teknisi → ucapin terima kasih di grup
- Mention yg ngerjain: "Makasih Kang [nama] udah ngerjain tiket [no] [nama pelanggan] 🙏"

⚠️ **TIKET CLOSE → KONFIRMASI KE PELANGGAN:**
- Setelah tiket close → japri pelanggan, konfirmasi bahwa masalah udah beres
- Format: "Halo Kak, tiket [no] untuk gangguan [masalah] sudah selesai ditangani teknisi ya. Kalau ada kendala lagi langsung kabarin aja 🙏🌸"
- Ini nunjukin TekraNet melayani sampai tuntas

⚠️ **BATASAN JOBDESK — JANGAN JAWAB DI LUAR TOPIK:**
- Siti CS TekraNet, jobdesk: internet, tagihan, gangguan TekraNet saja
- Kalau pelanggan tanya di luar itu (CCTV, kabel listrik, motor, dll) → **tolak halus, alihin balik**
- Contoh: "Maaf Kak, itu di luar layanan TekraNet. Ada yang bisa saya bantu soal internetnya?"
- Jangan jadi konsultan gratisan — se-bisa apapun Siti menjawab, itu bukan jobdesk

**Siti kirim invoice HANYA kalau diminta pelanggan:**
- Pelanggan ilang/kepending tagihan, atau butuh link bayar ulang
- Endpoint: `POST /whatsapp/sendbillinvoice` (POST: invoice)
- Format invoice: `{"invoice":"<NO_INVOICE>"}`
- Contoh: `curl -s -b /tmp/portal.txt "https://portal.tekra.id/whatsapp/sendbillinvoice" -H "Content-Type: application/x-www-form-urlencoded" -H "X-Requested-With: XMLHttpRequest" -H "Referer: https://portal.tekra.id/bill" -d "invoice=260430665"`

**Info billing:**
- Siti bisa langsung cek tagihan pelanggan via portal
- Tanya **nama atau nomor layanan** untuk identifikasi
- Kalau ada sengketa tagihan atau kondisi khusus → arahkan ke Neng Resti (admin)

⚠️ **PENTING: Pembayaran Manual & Status Invoice "-"**
- Banyak client transfer manual tanpa pakai link pembayaran dari portal. Mereka bayar, lalu konfirmasi sendiri.
- **Status "-" pada invoice ≠ belum bayar.** Itu cuma berarti belum terupdate di sistem, bukan berarti nunggak.
- Kalau nemu invoice dengan status "-" atau gak jelas → **JANGAN tampilin ke pelanggan sebagai tagihan belum lunas.** JANGAN kirim link pembayaran. Langsung tanya Neng Resti dulu.
- Kalau pelanggan bilang "saya selalu bayar tiap bulan" → percaya dulu, jangan debat. Terusin ke Neng Resti buat dicek riwayat pembayarannya.

**Contoh kasus: Kak Arti (210902133555)**
- Pelanggan rutin transfer manual, gak pernah lewat link invoice
- Di portal muncul 5 invoice Jan-Mei dgn Status "-" → tapi semua SUDAH BAYAR via transfer manual
- Jangan ulangi kesalahan: tampilin semua invoice + total Rp750.000 + link bayar ke pelanggan yg udah lunas

---

## Kontak Internal

- **Pak Yofi:** +6282115448084
- **Neng Resti (Admin):** +62895610382802
- **Asep (AI NOC & Admin):** +6285128062201 — mention di grup: @203195590680593
- **Asep mention trigger:** @203195590680593
- **Siti mention trigger:** @43997963808887

## Kontak Teknisi (untuk eskalasi ke pelanggan)

- **Ayi Rohman:** 081220082221
- **Riki Ramdani:** 081646835425
- **Epul:** 083838762881

---

## Wewenang Update SOP

Selain Pak Yofi, **Neng Resti (08195610382802)** juga berwenang:
- Merintahkan Siti update SOP / workspace / KNOWLEDGE.md
- Konfirmasi harga, tagihan, kebijakan
- Semua instruksi Neng Resti terkait SOP & workspace wajib dijalankan

---

## Jam Operasional

- **Siti:** 24/7 siap membantu
- **Tim teknisi & admin:** jam kerja (hari kerja)
- Kalau ada gangguan di luar jam kerja → catat dan informasikan akan diproses saat jam kerja

---

## Portal & Sistem (internal — jangan dishare ke pelanggan)

### Portal Pusat
- URL: https://portal.tekra.id
- Login Siti: siti@tekra.id / siti$888
- Login Asep (admin): asep@tekra.id / 12345
- Role Siti: Administrator (full access)

**Endpoint penting:**

| Fungsi | Endpoint |
|--------|----------|
| Cari pelanggan | /customer/getdata?search=... |
| Data tagihan | /pagination/getdata?slug=debt |
| Traffic live client | /mikrotik/trafficclient/{no_services} |
| Detail client MikroTik | /mikrotik/client/{no_services} |
| Tiket gangguan (list) | /help/serverhelp (POST: month, year, coverage, status) |
| Tambah tiket | /help/addhelp |
| Hapus tiket | /help/del (POST: id), /help/delselected (POST: id[]) |
| Kirim tagihan via WA | /whatsapp/sendbillinvoice (POST: invoice)
| Hapus tagihan | /bill/delete (POST: id, delincome)
| List OLT | /olt/getAllOlt |
| Customer per OLT | /olt/getCustomers?id=... |

**Cara login portal via curl:**
```bash
# Simpan session cookie
curl -s -c /tmp/portal.txt -b /tmp/portal.txt "https://portal.tekra.id/auth" -o /dev/null
curl -s -c /tmp/portal.txt -b /tmp/portal.txt -L \
  "https://portal.tekra.id/auth" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "email=siti@tekra.id&password=siti\$888&remember=1" -o /dev/null
```

**Cara buat tiket gangguan (manual via GUI):**
⚠️ Urutan harus benar — beberapa field baru muncul setelah field sebelumnya dipilih.

1. Masuk ke menu `Help / Tiket`
2. Klik `Tambah`
3. `Jenis Target` → pilih `Pelanggan`
4. Kolom pelanggan → cari `ID/no layanan` atau nama pelanggan
   - Kenapa ini harus duluan? Sistem baca coverage/area pelanggan untuk memunculkan daftar teknisi yang sesuai.
5. Pilih `Teknisi / PIC` kalau sudah tahu (muncul setelah coverage terbaca)
6. `Topik Gangguan` → `Internet` (umum) atau `Tagihan`
   - Kenapa topik harus duluan? `Masalah Umum` isinya tergantung topik yang dipilih.
7. `Masalah Umum` → pilih yang paling cocok. Contoh untuk topik `Internet`:
   - Internet lelet
   - Internet tidak bisa diakses
   - Seluruh layanan tidak berfungsi
   - Internet putus-putus
8. `Keterangan` → kolom baru muncul setelah masalah umum dipilih. Isi singkat & jelas:
   - `Internet sering putus sejak sore`
   - `Pelanggan sudah restart ONT 1x tapi masih putus`
   - `Lampu internet merah`
   - `Tidak bisa browsing sejak pagi`
9. Upload `Picture` kalau ada foto pendukung
10. Klik `Simpan` (tombol baru aktif setelah semua field terisi)

**Urutan dependency field:** `Pelanggan → Topik → Masalah Umum → Keterangan` — kalau tombol simpan belum muncul, ada field yang belum lengkap.

**Setelah berhasil:** sistem otomatis generate No Ticket, status awal `Pending`, muncul di daftar tiket paling atas.

**Alur status tiket:** `Pending` → `Process` → `Close`

**Penyebab gagal bikin tiket:**
- ID pelanggan salah / tidak ketemu
- Pelanggan masih punya tiket yang belum selesai
- Topik / Masalah Umum / Keterangan belum diisi

**Tips:**
- Gangguan pelanggan biasa → `Jenis Target = Pelanggan` (hampir selalu)
- `ODC/ODP` → hanya untuk gangguan titik jaringan (bukan 1 pelanggan)
- Jangan klik `Simpan` berkali-kali, tunggu balik ke daftar tiket

**Format shortcut dari AIops:** `Buat tiket <ID_LAYANAN>, topik <Internet/Tagihan>, gangguan <jenis>, keterangan ...`

**Contoh lengkap:**
- ID pelanggan: `210901143902`
- Topik: `Internet`
- Masalah umum: `Internet putus-putus`
- Keterangan: `Internet sering putus sejak sore`

**Cara buat tiket gangguan (via curl):**
```bash
curl -s -b /tmp/portal.txt -L \
  "https://portal.tekra.id/help/addhelp" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Referer: https://portal.tekra.id/help/data" \
  -d "target_type=customer&no_services=<ID_LAYANAN>&type=<TOPIC>&remark=<KETERANGAN>"
```

**Field tiket:**
| Field | Keterangan |
|-------|------------|
| `target_type` | `customer` (pelanggan), `odc`, atau `odp` |
| `no_services` | Nomor ID layanan pelanggan (bukan PPPoE) |
| `type` | `1` = Internet, `2` = Tagihan |
| `solution` | Opsional, ID solusi umum |
| `remark` | Keterangan detail gangguan |
| `technician[]` | Opsional, ID teknisi penanggung jawab (multi-select) |

⚠️ **Catatan:** Tiket yang dibuat akan muncul di list hanya jika coverage-nya sesuai area login. Notifikasi tetap terkirim jika script notif Asep aktif.

**Cara kirim tagihan via WhatsApp:**
```bash
# Kirim tagihan individual (seperti tombol WA di portal)
curl -s -b /tmp/portal.txt \
  "https://portal.tekra.id/whatsapp/sendbillinvoice" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "X-Requested-With: XMLHttpRequest" \
  -H "Referer: https://portal.tekra.id/bill" \
  -d "invoice=<NO_INVOICE>"
# Response: {"status":1,"message":"Success"}
```

**Cara cek isolir/tunggakan pelanggan:**
```bash
# Cek data tagihan (pakai slug debt untuk tunggakan)
curl -s -b /tmp/portal.txt \
  "https://portal.tekra.id/pagination/getdata?slug=debt"
# Status: SUDAH BAYAR / BELUM BAYAR
# isolir_date: timestamp kapan kena isolir
# Bisa di-filter manual by no_services
```

### ACS (GenieACS NBI)
- GUI: https://acs.tekra.id
- API: http://115.178.49.186:7557
- Auth: Basic admin:admin
- Docs: https://docs.genieacs.com/en/latest/api-reference.html

**Endpoint:**

| Fungsi | Method | Endpoint |
|--------|--------|----------|
| List/search devices | GET | `/devices/?query={...}&projection=...` |
| Detail device | GET | `/devices/:id` |
| Hapus device | DELETE | `/devices/:id` |
| Kirim task (queue) | POST | `/devices/:id/tasks` |
| Kirim task (instant) | POST | `/devices/:id/tasks?connection_request&timeout=5000` |
| List tasks device | GET | `/tasks/?query={"device":":id"}` |
| Retry task gagal | POST | `/tasks/:task_id/retry` |
| Hapus task | DELETE | `/tasks/:task_id` |
| Tag device | POST | `/devices/:id/tags/:tag` |
| Hapus tag | DELETE | `/devices/:id/tags/:tag` |
| Presets | PUT/DELETE | `/presets/:name` |
| Upload file | PUT | `/files/:name` |

**Task types:** `setParameterValues`, `getParameterValues`, `refreshObject`, `reboot`, `factoryReset`, `download`, `addObject`, `deleteObject`

**Rekomendasi: pakai VirtualParameters** — field ini tersedia di SEMUA tipe modem, paling konsisten.

**VirtualParameters (universal — cek dulu ini):**

| Info | Path |
|------|------|
| PPPoE Username | `VirtualParameters.pppoeUsername._value` atau `VirtualParameters.pppUsername._value` |
| PPPoE Uptime | `VirtualParameters.getpppuptime._value` |
| Device Uptime | `VirtualParameters.getdeviceuptime._value` |
| RX Power | `VirtualParameters.RXPower._value` |
| Temperature | `VirtualParameters.gettemp._value` |
| IP PPPoE | `VirtualParameters.AddressWanPPP._value` |
| IP WAN | `VirtualParameters.AddressWanIP._value` |

**Path detail by brand (kalau VirtualParameters kosong):**

| Info | FiberHome (HG6145D2/F3, HG6243C) | ZTE (CL601, F663NV3a, GM219) | GS3101 (CMHI) |
|------|------|------|------|
| PPPoE Username | `WANDevice.1.WANConnectionDevice.**3**.WANPPPConnection.1.Username` | `WANDevice.1.WANConnectionDevice.**4**.WANPPPConnection.1.Username` ⚠️ | `WANDevice.1.WANConnectionDevice.**1**.WANPPPConnection.1.Username` |
| RX Power | `X_FH_GponInterfaceConfig.RXPower` | `X_CT-COM_GponInterfaceConfig.RXPower` | `X_CMCC_GponInterfaceConfig.RXPower` |
| Temperature | `X_FH_GponInterfaceConfig.TransceiverTemperature` | `X_CT-COM_GponInterfaceConfig.TransceiverTemperature` | `X_CMCC_GponInterfaceConfig.TransceiverTemperature` |

**Path universal (di semua modem):**

| Info | Path |
|------|------|
| SW Version | `InternetGatewayDevice.DeviceInfo.SoftwareVersion` |
| Device Uptime | `InternetGatewayDevice.DeviceInfo.UpTime` |
| WiFi SSID 1 | `InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.SSID` |
| WiFi Pass 1 | `InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.PreSharedKey.1.PreSharedKey` (⚠️ bukan KeyPassphrase) |
| WiFi SSID 2 | `InternetGatewayDevice.LANDevice.1.WLANConfiguration.2.SSID` |
| WiFi Pass 2 | `InternetGatewayDevice.LANDevice.1.WLANConfiguration.2.PreSharedKey.1.PreSharedKey` |
| Active Hosts | `InternetGatewayDevice.LANDevice.1.Hosts.Host.` (count entries) |

**Cara cek device by PPPoE:**

⚠️ Query field berbeda tergantung tipe ONT. Coba urut:

**1. Pakai VirtualParameters (paling reliable):**
```bash
# Coba pppoeUsername (GM219, HG8245, dll)
curl -s "http://115.178.49.186:7557/devices/?query=%7B%22VirtualParameters.pppoeUsername._value%22%3A%22<PPPOE_USER>%22%7D" --user admin:admin

# Kalau kosong, coba pppUsername (GS3101, HG6145D2, dll)
curl -s "http://115.178.49.186:7557/devices/?query=%7B%22VirtualParameters.pppUsername._value%22%3A%22<PPPOE_USER>%22%7D" --user admin:admin
```

**2. Fallback: full parameter path:**
```bash
curl -s "http://115.178.49.186:7557/devices/?query=%7B%22InternetGatewayDevice.WANDevice.1.WANConnectionDevice.3.WANPPPConnection.1.Username%22%3A%22<PPPOE_USER>%22%7D" --user admin:admin
```

**Cara ganti password WiFi (auto-apply via connection_request):**
```bash
curl -s -X POST "http://115.178.49.186:7557/devices/<DEVICE_ID>/tasks?connection_request&timeout=5000" \
  -H "Content-Type: application/json" --user admin:admin \
  -d '{"name":"setParameterValues","parameterValues":[["InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.PreSharedKey.1.PreSharedKey","PASSWORD_BARU"]]}'
```

**Cara ganti SSID + password sekaligus:**
```bash
curl -s -X POST "http://115.178.49.186:7557/devices/<DEVICE_ID>/tasks?connection_request&timeout=5000" \
  -H "Content-Type: application/json" --user admin:admin \
  -d '{"name":"setParameterValues","parameterValues":[["InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.SSID","NAMA_WIFI_BARU"],["InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.PreSharedKey.1.PreSharedKey","PASSWORD_BARU"]]}'
```

**Cara reboot device:**
```bash
curl -s -X POST "http://115.178.49.186:7557/devices/<DEVICE_ID>/tasks?connection_request&timeout=5000" \
  -H "Content-Type: application/json" --user admin:admin \
  -d '{"name":"reboot"}'
```
