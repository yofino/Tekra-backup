# Cilisung GX4 Tunnel Down

**Status:** 🔴 Gangguan Aktif
**Sejak:** 9 Mei 2026 (OVPN down), 11 Mei 2026 (fully unreachable)
**Area:** Cilisung (coverage 14)

## Root Cause (dari Asep)
- Tunnel OVPN CILISUNG GX4 (tunnel-31721) → CCR1 port 1000
- **Secret/user OVPN CILISUNG hilang dari CCR1** — kayaknya kehapus
- Tanpa tunnel, gak ada route ke 10.6.0.5
- GX4 totally unreachable sejak 11 Mei 07:13 (~20 jam per 12 Mei)

## Timeline Zabbix
- 9 Mei, 17:02 — tunnel OVPN (`tunnel-31721`) di GX4 link down
- 11 Mei, 07:13 — GX4 completely unreachable (ICMP ping gagal)

## Dampak
- Semua pelanggan PPPoE coverage 14 (Cilisung) terdampak
- Portal gak bisa sync `mode_user`/`router` ke pelanggan Cilisung

## Yang Masih Normal
- CCR1 OVPN server running, tunnel lain (DAGO, KATAPANG, SETRADUTA, dll) UP ✅
- x86 Pusat normal, PPPoE pusat gak terdampak ✅

## Fix Dibutuhkan
1. Setup ulang OVPN secret/user CILISUNG di CCR1 (port 1000)
2. Pastikan GX4 bisa reconnect
3. Atau akses fisik/remote alternatif ke Cilisung

## Pelanggan Terkait
- NURWINDA (20260414115345) — PPPoE udah ada di GX4 tapi gak bisa konek, nunggu tunnel up
- MARWIYAH (260124095750) — Hotspot CCR1, udah aktif, gak terdampak
