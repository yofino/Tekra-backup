# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## WhatsApp Group - Team Tekra

- **Group:** TEKNOLOGI RAKYAT™ — `6281320385966-1635417302@g.us`
- **Group Cilsung:** TEKRA CILISUNG — `120363071951489631@g.us`
- **Siti mention trigger:** @43997963808887
- **Asep mention trigger:** @203195590680593
- **Yofi:** +6282115448084
- **AIops:** +6285128062201

## Team Contacts

- **Resti** — Admin manusia, +62895610382802
- **Asep** — AI agent NOC & Admin, koordinasi teknis
- **Acam (Bang Acam)** — PIC area Katapang, +6287722867602
- **Ayi Rohman (Kang Ayi)** — Teknisi, +6281220082221
- **Epul (Puyy/Kang Epul)** — Teknisi paling gerengseng, +6283838762881
- **Jay (Bang Jay)** — Tim hura-hura (general), +6281320385966

## Coordination Rules

- Mau ngobrol sama Asep → mention @203195590680593
- Asep mau ngobrol sama Siti → mention @43997963808887
- ⚠️ **PENTING:** Koordinasi dengan Asep di grup WA TEKNOLOGI RAKYAT™ WAJIB mention @203195590680593, jangan cuma kirim pesan tanpa mention — biar Asep dapet notifikasi
