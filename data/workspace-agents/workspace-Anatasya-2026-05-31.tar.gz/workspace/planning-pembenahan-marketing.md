# PLANNING PEMBENAHAN SISTEM MARKETING
## CV Blessindo Priority Abadi | Mei - Juli 2026

---

## 🎯 TUJUAN
Membangun sistem marketing yang terstruktur, terukur, dan scalable
untuk mendukung pertumbuhan penjualan produk skincare & beauty.

---

## 📋 FASE 1: AUDIT & DIAGNOSA (Mei W1-W2)

**Evaluasi kondisi existing:**
• Review semua channel marketing yang ada sekarang
• Cek database klinik existing (jumlah, status, repeat order)
• Evaluasi materi marketing yang ada (katalog, brosur, company profile)
• Interview tim sales: apa kendala di lapangan?
• Analisa kompetitor: apa yang mereka lakukan lebih baik?

**Output:** Laporan gap analysis — mana yang bolong, mana yang bisa diimprove.

## 📋 FASE 2: BANGUN FONDASI (Mei W3-W4)

**2A. Company Profile & Materi Penjualan**
• Update company profile digital (PDF & presentasi)
• Bikin katalog produk lengkap dengan foto profesional
• Bikin one-pager / flyer per produk unggulan
• Video singkat produk (30 detik) untuk WhatsApp & IG

**2B. Database & CRM Sederhana**
• Bikin database klinik (Google Sheets / Excel)
• Kategorisasi: A (aktif), B (potensial), C (cold)
• Tracking: kapan terakhir kontak, order terakhir, produk favorit
• Set reminder follow-up otomatis tiap 2 minggu

**2C. SOP Marketing & Sales**
• SOP prospecting klinik baru (script WA, email, DM)
• SOP follow-up existing client
• SOP handling komplain & retur
• SOP kirim sample produk
• Template pesan: WA approach, WA follow-up, email proposal

---

## 📋 FASE 3: EKSEKUSI KAMPANYE (Juni W1-W4)

**3A. Digital Presence**
• Optimasi Google Maps / Google Bisnisku
• IG bisnis: posting rutin 3x/minggu (edukasi skincare + produk)
• Kumpulkan & posting testimoni dokter
• Join grup WhatsApp/Telegram dokter kecantikan

**3B. Program Penjualan**
• Program "Referral Doctor" — insentif untuk dokter yang merekomendasikan
• Bundling produk (beli 3 gratis 1, paket hemat klinik)
• Sample box gratis untuk klinik baru (first impression)
• Flash deal bulanan via WhatsApp blast

**3C. Event & Relationship**
• Webinar edukasi skincare bareng dokter (hosting di Zoom)
• Kunjungan rutin ke klinik existing (min. 5 klinik/minggu)
• Kirim hampers/parcel ke klinik top (Idul Adha)

---

## 📋 FASE 4: EVALUASI & SCALE (Juli W1-W4)

**4A. Review performa**
• Evaluasi campaign Mei-Juni: mana yang paling berhasil?
• Analisa data: produk terlaris, channel terbaik, klinik paling aktif
• Feedback dari tim sales & klinik

**4B. Standarisasi**
• Update SOP berdasarkan hasil evaluasi
• Training tim marketing/sales dengan sistem baru
• Bikin dashboard tracking weekly (Google Sheets auto)

**4C. Scale**
• Perbanyak channel yang sudah terbukti works
• Rekrut reseller/dropshipper (jika model bisnis memungkinkan)
• Ekspansi ke kota baru (di luar Bandung)
• Planning Q3 dengan target lebih tinggi

---

## ⏰ TIMELINE RINGKAS

| Minggu | Fokus | Output |
|--------|-------|--------|
| Mei W1-W2 | Audit & diagnosa | Gap analysis report |
| Mei W3-W4 | Bangun fondasi | SOP, CRM, materi baru |
| Juni W1-W2 | Digital & konten | IG aktif, Google Maps |
| Juni W3-W4 | Program penjualan | Bundling, referral, event |
| Juli W1-W2 | Review & evaluasi | Data analisa performa |
| Juli W3-W4 | Scale & planning Q3 | Target baru, SOP final |

---

## 📊 METRIK SUKSES (per Juli 2026)

• Database klinik ter-update & terkategorisasi ✓
• SOP marketing & sales tersedia & digunakan tim ✓
• IG aktif 3x/minggu dengan engagement naik ✓
• 5+ klinik baru acquired per bulan ✓
• Repeat order existing naik 20% ✓
• Company profile & katalog digital ready ✓

---

*Disusun bareng Anatasya, 19 Mei 2026 | Review progress tiap 2 minggu*
