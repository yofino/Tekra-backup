# Template Follow-Up WhatsApp — 10 Skenario

---

## 1. FOLLOW-UP SETELAH KENALAN (H+1)
> Halo Bapak/Ibu [Nama]! 🙌
> 
> Kemarin seneng banget bisa ngobrol soal rencana brand skincare [Nama Brand]. Saya udah siapin beberapa referensi formula yang sesuai sama kebutuhan [Ibu/Bapak].
> 
> Kapan ada waktu luang 15 menit buat saya jelasin via call? 🙏

---

## 2. FOLLOW-UP SETELAH KIRIM KATALOG (H+2)
> Bapak/Ibu [Nama], udah sempet liat katalog yang saya kirim kemarin? 📖
> 
> Kalau ada yang mau ditanyain — soal formula, MOQ, atau estimasi biaya — langsung WA aja ya. Saya bantu jelasin se-detail mungkin. Gak perlu sungkan 🤗

---

## 3. FOLLOW-UP SETELAH KIRIM SAMPLE (H+3)
> Halo Bapak/Ibu [Nama]! Gimana sample-nya? Udah dicoba? 🧴✨
> 
> Saran saya: coba 3-5 hari biar kerasa hasilnya. Favorit saya yang [Serum Brightening] — teksturnya ringan & cepet nyerap. 
> 
> Kalau udah nyoba, boleh share feedback-nya ya. Biar saya bisa rekomendasiin formula yang paling pas 😊

---

## 4. FOLLOW-UP SETELAH KIRIM PROPOSAL (H+2)
> Bapak/Ibu [Nama], saya mau follow-up soal proposal yang saya kirim. Ada yang perlu saya jelasin lebih detail?
> 
> Oh ya, slot produksi bulan [bulan] tinggal 2 loh. Jadi kalau memang cocok dan mau mulai, saya bisa booking-in dulu supaya gak kehabisan 🗓️

---

## 5. FOLLOW-UP PROSPECT DIAM (H+7)
> Bapak/Ibu [Nama], cuma mau cek aja — apa masih ada yang bikin ragu buat mulai brand skincare-nya?
> 
> Saya kebetulan ada cerita menarik: salah satu klien kita mulai dari 50 pcs doang, sekarang udah 5.000 pcs per bulan. Mulai dari kecil gak masalah, yang penting mulai dulu 🚀
> 
> Kapan kita ngobrol santai aja, gak ada komitmen apa-apa 😊

---

## 6. FOLLOW-UP PROSPECT DIAM LAMA (H+14)
> Halo Pak/Bu [Nama]! Sudah lama ya gak ngobrol. Semoga sehat selalu 🙏
> 
> Saya cuma mau update: kita baru aja launching 3 formula baru nih — ada [Retinol Serum], [Ceramide Moisturizer], sama [Niacinamide Toner]. Formula ini lagi tren banget di pasaran.
> 
> Kalau tertarik, saya bisa kasih detailnya. Atau... masih stay dengan rencana sebelumnya? 😄

---

## 7. FOLLOW-UP SETELAH MEETING (H+1)
> Terima kasih banyak waktunya tadi, Bapak/Ibu [Nama]! Diskusinya insightful banget ✨
> 
> Sesuai yang kita bahas, saya akan siapin:
> 1. Revisi formula dengan konsentrasi [X]%
> 2. Opsi packaging pump vs dropper
> 3. Timeline detail dari mulai sampai BPOM terbit
> 
> Paling lambat [hari] [tanggal] saya kirim ya. Kalau ada yang mau ditambahin, feel free to chat! 🙌

---

## 8. FOLLOW-UP ABIS NEGOSIASI (H+1)
> Bapak/Ibu [Nama], saya udah diskusiin request [Ibu/Bapak] ke team internal. 
> 
> Kabar baik! ✅ Kita bisa fasilitasi [poin yang dinego], dengan catatan [syarat kecil]. 
> 
> Saya juga bikinin 2 opsi paket biar [Ibu/Bapak] bisa bandingin:
> - Paket A: [detail singkat] — Rp [harga]
> - Paket B: [detail singkat] — Rp [harga]
> 
> Kapan bisa kita bahas bareng? 😊

---

## 9. FOLLOW-UP CLOSING GENTLE PUSH
> Bapak/Ibu [Nama], kayaknya kita udah bahas semua ya, tinggal eksekusi nih 🚀
> 
> Timeline ideal-nya: kalau kita mulai [bulan ini], produk bisa ready [3-4 bulan lagi] — pas banget buat [event/musim/tren].
> 
> Saya bantu urus semuanya dari sini. [Ibu/Bapak] tinggal santai aja. Gimana, kita mulai aja? 💪

---

## 10. FOLLOW-UP PROSPECT LOST (GRACEFUL EXIT)
> Halo Bapak/Ibu [Nama], terima kasih banyak udah ngobrol dan explore bareng Blessindo selama ini 🙏
> 
> Kalau suatu saat [Ibu/Bapak] mau mulai lagi, atau ada temen yang butuh jasa maklon — saya selalu siap bantu. Kontak saya tetep aktif.
> 
> Semoga sukses selalu! ✨

---

## BONUS: TEMPLATE KONTAK PERTAMA (COLD DM/WA)
> Halo Kak [Nama]! 🙌
> 
> Saya [Nama] dari Blessindo — pabrik maklon skincare bersertifikasi BPOM, HALAL, dan CPKB di Bandung.
> 
> Liat brand skincare Kakak keren banget! Kalau suatu saat mau bikin produk sendiri dengan formula eksklusif (bukan reseller), saya bisa bantu dari A-Z — formulasi, legalitas, produksi, sampai saran packaging.
> 
> Boleh saya kirim katalog + info lengkapnya? Gratis kok, gak ada ikatan 😊
