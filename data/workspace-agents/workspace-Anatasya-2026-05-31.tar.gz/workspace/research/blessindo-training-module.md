# Modul Training Sales Rep — Blessindo Prioriti Abadi (3 Minggu)

---

## MINGGU 1: PRODUCT KNOWLEDGE
**Goal:** Sales rep ngerti produk, proses, & legalitas sampai bisa jelasin ke prospect tanpa bantuan.

### Hari 1 — Kenalan Bisnis Blessindo
- Sejarah Blessindo (2015-sekarang)
- Visi & misi perusahaan
- Struktur organisasi & siapa ngapain
- Kenapa Blessindo beda: BPOM + HALAL + CPKB + Dermatology = full package

### Hari 2 — Produk & Formula (I)
- Kategori produk: facial wash, toner, serum, moisturizer, sunscreen, eye cream
- Jenis formula: brightening, anti-aging, acne, hydrating, sensitive skin
- Perbedaan formula dokter vs formula komersial
- Test: hafalin minimal 10 jenis produk + fungsinya

### Hari 3 — Produk & Formula (II)
- Packaging options: jar, pump, tube, sachet, dropper
- Labeling & desain kemasan
- Minimum Order Quantity (MOQ) per produk
- Kalkulasi estimasi biaya maklon (simulasi 3 skenario)

### Hari 4 — Legalitas & Regulasi
- BPOM: proses, timeline, syarat, biaya
- HALAL: proses sertifikasi, syarat bahan
- CPKB: apa itu & kenapa penting
- HAKI merk: cara daftar, estimasi biaya
- Test: jelasin proses BPOM ke temen sekelas dalam 5 menit

### Hari 5 — Kompetitor & Positioning
- Siapa kompetitor: Mash Moshem, Dreamlab, Sinon Aquif, Pillars
- Kelebihan Blessindo vs mereka (side-by-side comparison)
- Cara jawab: "Kenapa harus Blessindo, bukan yang lain?"
- Roleplay: prospect bandingin harga — gimana jawabnya?

---

## MINGGU 2: SALES SKILL
**Goal:** Sales rep bisa konsultasi, handle objection, & closing dengan percaya diri.

### Hari 1 — Needs Assessment
- Teknik bertanya: gali pain point prospect
- Framework SPIN (Situation, Problem, Implication, Need)
- Kenali persona prospect: dokter, brand owner pemula, online seller
- Roleplay: 10 menit konsultasi awal, temukan kebutuhan asli prospect

### Hari 2 — Presentasi & Storytelling
- Struktur presentasi 10 menit yang powerful
- Storytelling: ceritakan brand-client yang sukses bareng Blessindo
- Jangan jualan produk — jual solusi & hasil
- Praktek: bikin presentasi 5-slide + tampilin di depan kelas

### Hari 3 — Handling Objection
- Objection harga: "Mahal ya..." — jabarkan value, bukan potong harga
- Objection legalitas: "BPOM lama ya?" — jelasin timeline realistis
- Objection trust: "Pengalaman sama vendor lain gimana?" — testimoni + data
- Objection waktu: "Bisa lebih cepet gak?" — jelasin proses produksi
- Latihan: 20 objection umum, harus bisa jawab semua

### Hari 4 — Closing Technique
- Trial close: "Kalau sample-nya cocok, langkah selanjutnya gimana?"
- Assumptive close: "Kita mulai produksi bulan depan ya?"
- Urgency close: "Slot produksi bulan ini tinggal 2"
- Alternative close: "Mau yang paket starter atau paket premium?"
- Roleplay: full sales call dari awal sampe closing

### Hari 5 — Follow-Up System
- Follow-up timeline: H+1, H+3, H+7, H+14, H+30
- Template WA follow-up (5 skenario berbeda)
- Kapan harus "nge-dorong" dan kapan harus kasih ruang
- Praktek: tulis 10 follow-up message untuk 10 skenario

---

## MINGGU 3: PRAKTEK & SHADOWING
**Goal:** Sales rep siap terjun langsung dengan pengawasan minimal.

### Hari 1 — Shadowing Senior
- Ikut senior sales visit klinik/dokter (2-3 visit)
- Catat: gimana senior buka obrolan, gali kebutuhan, handle objection
- Observasi body language & tone suara
- Debrief sore: tanya kenapa senior ngambil keputusan tertentu

### Hari 2 — Semi-Mandiri dengan Backup
- Sales rep baru yang lead — senior jadi observer
- Visit 2 prospect dengan senior nemenin (tapi diem)
- Senior kasih feedback setelah tiap visit
- Perbaiki kelemahan yang ditemukan

### Hari 3 — Bikin Proposal Sendiri
- Dapet 1 prospect real — bikin full proposal
- Proposal direview senior sebelum dikirim
- Kirim proposal + presentasi ke prospect
- Review feedback dari prospect

### Hari 4 — Full Practice Day
- Prospecting mandiri: DM/call 20 lead baru
- Update CRM sendiri tanpa bantuan
- Follow-up ke semua existing prospect
- Senior review di akhir hari

### Hari 5 — Ujian Akhir & Sertifikasi
- **Tes tertulis**: product knowledge, legalitas, competitor (nilai min 80)
- **Roleplay ujian**: full sales call dari A-Z, dinilai oleh Sales Lead
- **Presentasi final**: pitch Blessindo ke panel (simulasi prospect besar)
- Lulus → dapet sales kit + territory assignment
- Belum lulus → remedial 1 minggu tambahan

---

## MATERIAL YANG HARUS DISIAPIN

- [ ] Buku panduan product knowledge (PDF + cetak)
- [ ] Katalog produk + formula + harga
- [ ] Sample kit (5 jenis produk tester)
- [ ] Slide deck company profile
- [ ] Comparison sheet vs kompetitor
- [ ] Template proposal (Google Docs)
- [ ] Script handling objection (20 situasi)
- [ ] Template follow-up WA (10 skenario)
- [ ] CRM template / Google Sheet
- [ ] Form penilaian ujian akhir

---

## EVALUASI MINGGUAN

| Aspek | Week 1 | Week 2 | Week 3 |
|---|---|---|---|
| Product knowledge | Quiz Harian | Test lisan random | Ujian tertulis |
| Sales skill | Observasi roleplay | Roleplay dinilai | Live assessment |
| Attitude | Kedisiplinan | Inisiatif | Kemandirian |
| CRM update | - | Kelengkapan data | Akurasi pipeline |
