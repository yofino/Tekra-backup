# TEMPLATE PROPOSAL MAKLON
## BLESSINDO PRIORITI ABADI

---

**Disiapkan untuk:** [Nama Brand/Prospect]
**Tanggal:** [DD MMMM YYYY]
**Sales Rep:** [Nama]

---

## 1. RINGKASAN EKSEKUTIF

Terima kasih atas kepercayaan [Ibu/Bapak] untuk menjajaki kerjasama maklon bersama Blessindo Prioriti Abadi. Proposal ini disusun berdasarkan kebutuhan yang telah didiskusikan bersama.

Blessindo adalah pabrik maklon skincare bersertifikasi **BPOM · HALAL · CPKB** yang telah melayani dokter, klinik, dan brand owner di seluruh Indonesia sejak 2015.

---

## 2. SPESIFIKASI PRODUK

| Detail | Spesifikasi |
|---|---|
| Nama Produk | [Nama] |
| Kategori | [Serum / Moisturizer / Facial Wash / etc] |
| Formula Utama | [Brightening / Anti-aging / Acne / etc] |
| Bahan Aktif | [Niacinamide 10%, Retinol 0.5%, etc] |
| Tekstur | [Gel / Cream / Water-based / etc] |
| Target Kulit | [Semua jenis / Normal-Oily / Sensitif / etc] |
| Wangi | [Fragrance-free / Rose / Lavender / etc] |

---

## 3. OPSI KEMASAN

| Opsi | Material | Volume | Estimasi Biaya | Visual |
|---|---|---|---|---|
| A | Botol kaca + dropper | 30ml | Rp [xx]/unit | [Foto] |
| B | Botol pump airless | 30ml | Rp [xx]/unit | [Foto] |
| C | Tube | 50ml | Rp [xx]/unit | [Foto] |

---

## 4. RINCIAN BIAYA

| Komponen | Biaya |
|---|---|
| Formulasi eksklusif (R&D + sample) | Rp [x.xxx.xxx] |
| Pengurusan BPOM | Rp [x.xxx.xxx] |
| Sertifikasi HALAL | Rp [x.xxx.xxx] |
| Produksi (per unit @ MOQ [xxx] pcs) | Rp [xx.xxx]/unit |
| Packaging + label (per unit) | Rp [xx.xxx]/unit |
| **TOTAL ESTIMASI** | **Rp [xx.xxx.xxx]** |

---

## 5. PAKET PILIHAN

### PAKET STARTER ✨
- MOQ: [xxx] pcs
- Formula eksklusif
- BPOM + HALAL included
- 1 varian produk
- Cocok untuk: brand baru, test market

### PAKET GROWTH 🚀
- MOQ: [xxx] pcs
- Formula eksklusif + 1 revisi
- BPOM + HALAL included
- 2 varian produk
- Bonus: 1 sesi konsultasi branding

### PAKET PREMIUM 👑
- MOQ: [xxx] pcs
- Formula eksklusif + unlimited revisi
- BPOM + HALAL + HAKI included
- 3-5 varian produk
- Bonus: foto produk profesional + landing page

---

## 6. TIMELINE

| Tahap | Durasi | Keterangan |
|---|---|---|
| Konsultasi formula | 1-2 minggu | Diskusi dengan team R&D |
| Sample production | 2-3 minggu | Formula diracik, diuji lab |
| Approval sample | 1 minggu | Klien test & approve |
| Produksi massal | 3-4 minggu | Produksi sesuai MOQ |
| Packaging | 1-2 minggu | Cetak box, label, segel |
| Pengurusan BPOM | 3-6 bulan | Diproses paralel |
| **TOTAL (sampai siap jual)** | **~3-4 bulan** | Produk ready, BPOM menyusul |

---

## 7. MENGAPA BLESSINDO?

✅ **11 tahun pengalaman** — melayani dokter & klinik seluruh Indonesia
✅ **Sertifikasi terlengkap** — BPOM, HALAL, CPKB, Dermatology-tested
✅ **Formula eksklusif** — dikembangin bareng MBC Labs, bukan copy-paste
✅ **All-in-one service** — dari formulasi sampai legalitas, kami handle semua
✅ **Tumbuh bersama** — support gak berhenti setelah produksi

---

## 8. TESTIMONI KLIEN

> "[Quote testimoni singkat dari klien sukses]"
> — **[Nama Brand], [Kota]**
> *(Produk: [Nama Produk], terjual [x.xxx] pcs/bulan)*

> "[Quote testimoni singkat]"
> — **[Nama Brand], [Kota]**

---

## 9. LANGKAH SELANJUTNYA

1. **Review** proposal ini bersama tim internal
2. **Meeting** lanjutan — diskusi detail formula & revisi
3. **Trial sample** — produksi sample kecil untuk uji coba
4. **Approval** — tanda tangan kontrak & mulai produksi

---

## KONTAK

**Blessindo Prioriti Abadi**
Jl. Batununggal Elok Raya No.9, Bandung 40267
📞 +62 22 7509999
📱 +62 878-2599-1199
📧 marketing@blessindo.co.id

**Sales Rep: [Nama]**
📱 [Nomor WA]
---

*Proposal berlaku 30 hari sejak tanggal di atas. Harga dapat berubah sesuai fluktuasi bahan baku.*
