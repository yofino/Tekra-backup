# Planning Sales Representatives — Blessindo Prioriti Abadi

## 1. Struktur Tim Sales

### A. Pembagian Territory
| Posisi | Target Area | Fokus Segmen |
|---|---|---|
| Sales Rep 1 | Bandung & Jabar | Dokter, klinik kecantikan, apotek |
| Sales Rep 2 | Jakarta & Banten | Brand owner, klinik premium, distributor |
| Sales Rep 3 | Jateng & Jatim | Dokter, klinik, online seller |
| Sales Rep 4 | Sumatera & Kalimantan | Remote/online, klinik besar |
| Sales Lead | All | Manage team, closing deal besar, B2B partnership |

### B. Struktur Komisi
| Komponen | Detail |
|---|---|
| Gaji Pokok | UMR + tunjangan transport |
| Komisi per closing | 3-5% dari nilai kontrak pertama |
| Komisi repeat order | 1-2% dari repeat order (passive income) |
| Bonus quarterly | Capai target 100% → bonus 1x gaji |
| Bonus tahunan | Top performer → trip/insentif khusus |

## 2. Target Market & Segmentasi

### Primary (Fokus Utama)
- **Dokter & klinik kecantikan** — udah jadi core business Blessindo
- **Brand owner skincare baru** — tren "bikinin brand sendiri" lagi booming

### Secondary (Growth)
- **Online seller / dropshipper** — pasar gede, MOQ kecil
- **Distributor regional** — perluas jangkauan ke luar Jawa
- **Klinik besar / RS** — volume besar, long-term contract

## 3. Sales Process (SOP)

```
LEAD → KUALIFIKASI → KONSULTASI → SAMPLE → PROPOSAL → CLOSING → ONBOARDING
```

| Step | Aktivitas | Tools |
|---|---|---|
| **Lead** | Dapetin kontak dari IG, web, event, referral | CRM / Google Sheet |
| **Kualifikasi** | Tanya: budget? segmen? udah ada brand? | Form kualifikasi WA |
| **Konsultasi** | Edukasi proses maklon, legalitas, estimasi biaya | Zoom/WA Call |
| **Sample** | Kirim sample produk + katalog formula | Sample kit fisik |
| **Proposal** | Kirim proposal: formula, packaging, timeline, harga | PDF proposal |
| **Closing** | Follow-up, negosiasi, kontrak | MoU / kontrak digital |
| **Onboarding** | Serah terima ke tim produksi + kickoff meeting | Timeline produksi |

## 4. Target Bulanan per Sales Rep

| Bulan | Target Leads | Target Konsultasi | Target Closing | Revenue Target |
|---|---|---|---|---|
| 1-3 (learning) | 40 | 20 | 3 | Rp 50jt |
| 4-6 (ramp-up) | 50 | 30 | 5 | Rp 100jt |
| 7+ (full speed) | 60 | 40 | 8 | Rp 200jt |

## 5. Tools yang Dibutuhkan Sales Rep

### Wajib Ada
- **Katalog digital** — PDF berisi formula, packaging options, harga MOQ
- **Sample kit** — sample produk fisik + tester buat dikasih ke prospect
- **WA Business** — katalog produk, auto-reply, quick reply template
- **Google Sheet / CRM** — tracking lead, follow-up reminder
- **Company profile deck** — slide presentasi singkat

### Nice to Have
- Landing page inquiry form yang langsung masuk ke WhatsApp
- Video virtual tour pabrik
- Testimoni video dari brand-client sukses
- Kalkulator estimasi biaya maklon

## 6. Training Sales Rep

### Minggu 1 — Product Knowledge
- Proses maklon dari A-Z
- Jenis produk & formula yang bisa dibuat
- Legalitas: BPOM, HALAL, CPKB — bedanya apa
- Minimum Order Quantity (MOQ) & pricing structure

### Minggu 2 — Sales Skill
- Teknik konsultasi & needs assessment
- Handling objection (harga, legalitas, kompetitor)
- Closing technique untuk B2B
- Follow-up system

### Minggu 3 — Shadowing
- Ikut senior sales visit klinik/dokter
- Roleplay closing call
- Bikin proposal pertama (direview)

## 7. Daily Routine Sales Rep

| Jam | Aktivitas |
|---|---|
| 08:00-09:00 | Briefing pagi + cek pipeline |
| 09:00-12:00 | Prospecting (WA, DM, call lead baru) |
| 12:00-13:00 | Istirahat |
| 13:00-15:00 | Visit / meeting prospect |
| 15:00-16:00 | Follow-up existing prospect |
| 16:00-17:00 | Update CRM + laporan harian |

## 8. Lead Generation Strategy

### Inbound (lead datang sendiri)
- Optimasi IG — konten edukasi + CTA "Konsultasi Gratis"
- Google Ads — keyword "maklon skincare BPOM"
- Landing page inquiry form
- Referral dari existing client

### Outbound (sales cari lead)
- DM ke brand skincare baru di IG/TikTok
- Visit klinik kecantikan langsung
- Join komunitas brand owner di WhatsApp/Telegram
- Hadir di event & pameran industri

## 9. KPI & Reporting

### Weekly Report
- Leads baru minggu ini
- Konsultasi dilakukan
- Proposal terkirim
- Closing deal
- Revenue booked

### Monthly Review
- Target vs actual
- Pipeline health (berapa di tiap stage)
- Conversion rate per stage
- Revenue per sales rep
- Feedback dari prospect yang lost

## 10. Timeline Implementasi

| Minggu | Milestone |
|---|---|
| 1-2 | Siapkan tools (katalog, sample kit, CRM, training module) |
| 3 | Rekrut / assign sales rep internal |
| 4-5 | Training intensif |
| 6 | Soft launch — mulai prospecting dengan KPI rendah |
| 7-8 | Review & adjustment |
| 9+ | Full speed dengan KPI penuh |
