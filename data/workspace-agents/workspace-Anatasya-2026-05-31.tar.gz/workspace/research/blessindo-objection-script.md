# Script Handling Objection — 20 Skenario Lengkap

---

## OBJECTION HARGA (5 Skenario)

### 1. "Mahal ya dibanding yang lain..."
> "Ibu/Bapak, kalau bicara maklon skincare, kita gak cuma beli produk — kita investasi di keamanan brand. Blessindo itu satu dari sedikit maklon yang udah lengkap: BPOM, HALAL, CPKB, Dermatology-tested. Jadi pas produk Ibu/Bapak launch, gak ada drama legalitas di belakang. Bandingin sama yang murah tapi nanti kena masalah BPOM — biayanya justru lebih mahal."

### 2. "Ada yang nawarin lebih murah, nih..."
> "Wah boleh banget dibandingin Bu/Pak. Tapi coba cek 3 hal: mereka ada CPKB gak? Uji dermatology-nya ada? Formula dikembangin sama siapa? Banyak yang lebih murah karena pake formula generik tanpa R&D. Di Blessindo, formula Ibu/Bapak dikembangin eksklusif bareng MBC Labs. Jadi produknya unique, bukan copy-paste."

### 3. "MOQ-nya terlalu besar, saya baru mulai..."
> "Paham banget Bu/Pak. Justru karena baru mulai, penting pilih partner yang bisa bantu dari nol. Kita ada opsi paket starter — MOQ lebih kecil, tapi tetap dapet legalitas lengkap. Nanti pas brand Ibu/Bapak udah jalan, kita tinggal scale up. Jadi tumbuhnya bareng-bareng."

### 4. "Bisa kurang gak harganya?"
> "Harga yang kita kasih udah include semuanya Bu/Pak — formulasi eksklusif, legalitas BPOM, sertifikasi HALAL, quality control ketat, dan konsultasi gratis selama proses. Kalau kita potong harga, kualitas yang dikorbankan. Dan itu bukan cara Blessindo kerja. Tapi... kita bisa diskusi opsi paket yang sesuai budget."

### 5. "Saya perlu itung-itung dulu, budget-nya..."
> "Justru saya bantu hitungin sekarang Bu/Pak! 🤓 Coba kita lihat: berapa target harga jual produknya? Kalau harga jual Rp 150rb/pcs dan modal maklon Rp 45rb/pcs, marginnya masih 70%. ROI balik modal biasanya di batch pertama atau kedua. Saya bikinin simulasi detailnya ya?"

---

## OBJECTION LEGALITAS (4 Skenario)

### 6. "BPOM lama banget ya prosesnya..."
> "Proses BPOM emang makan waktu Bu/Pak, tapi team Blessindo yang handle semuanya — dari awal sampe terbit. Ibu/Bapak tinggal tunggu kabar. Timeline normal 3-6 bulan, tapi sambil nunggu BPOM, kita udah bisa produksi dan packaging. Begitu BPOM keluar, langsung siap jualan."

### 7. "Ini aman kan? Gak disita BPOM nanti?"
> "Justru ini keunggulan Blessindo Bu/Pak. Kita pabrik bersertifikasi CPKB — itu standar tertinggi Cara Pembuatan Kosmetik yang Baik. BPOM sendiri yang audit. Jadi InsyaAllah aman. Bedanya sama maklon 'abal-abal' yang suka bikin masalah itu di sini."

### 8. "Saya gak ngurus HAKI gapapa kan?"
> "Sayang banget Bu/Pak kalau gak didaftarin HAKI. Bayangin, brand Ibu/Bapak udah mulai terkenal, eh tiba-tiba ada yang niru merk-nya. Tanpa HAKI, kita gak bisa ngapa-ngapain. Blessindo bantu proses pendaftarannya kok, jadi sekalian aja."

### 9. "Sertifikasi Halal penting ya buat skincare?"
> "Sangat penting Bu/Pak, apalagi di Indonesia. Konsumen sekarang makin aware — mereka cek label halal sebelum beli. Produk skincare kan nempel di kulit, dipakai wudhu juga. Sertifikasi halal bikin brand Ibu/Bapak diterima di semua kalangan. Udah included di paket kita."

---

## OBJECTION TRUST (4 Skenario)

### 10. "Saya trauma sama vendor sebelumnya..."
> "Saya paham banget Bu/Pak. Makanya penting tau track record-nya. Blessindo udah 11 tahun, 70% klien kita brand private-label yang repeat order terus. Itu bukti mereka puas. Kita bisa kasih testimoni atau bahkan kenalin ke klien existing kita kalau perlu."

### 11. "Ini gimmick marketing doang ya?"
> "Hehe, boleh dicek langsung Bu/Pak 🤗 Kita ada virtual tour pabrik atau kalau mau, bisa visit langsung ke Bandung. Liat sendiri fasilitasnya, ketemu team R&D, liat proses produksi. Gak ada yang ditutup-tutupin."

### 12. "Saya coba dulu deh yang kecil-kecil..."
> "Justru itu! Maklon itu pernikahan jangka panjang Bu/Pak, bukan one night stand. Mulai dari yang kecil dulu, rasain kualitas dan pelayanan kita. Kalau cocok baru scale up. Kita sendiri prefer klien yang tumbuh bareng dari kecil."

### 13. "Ada sample gak? Saya mau coba dulu produknya."
> "Pasti ada dong Bu/Pak! (👉 kasih sample kit) Ini sample dari 5 kategori produk kita. Coba sendiri dulu 1-2 minggu, rasain tekstur dan hasilnya. Setelah itu kita ngobrol lagi. Saya yakin Ibu/Bapak bakal suka hasilnya."

---

## OBJECTION WAKTU & PROSES (4 Skenario)

### 14. "Prosesnya lama ya? Saya maunya cepet..."
> "Bisa kita percepat di beberapa tahap Bu/Pak, misalnya paralelin proses formulasi sama desain packaging. Tapi untuk legalitas memang ada timeline yang gak bisa dipaksa karena dari BPOM. Estimasi total 3-4 bulan udah termasuk produksi. Timeline detailnya saya kirim ya."

### 15. "Saya sibuk banget, gak bisa ngurusin ini-itu..."
> "Makanya pake Blessindo Bu/Pak! Kita literally handle everything — dari formulasi, BPOM, HALAL, produksi, sampai saran packaging. Ibu/Bapak cukup review dan approve. Gak perlu ngurusin teknis sama sekali."

### 16. "Mending saya cari yang instan aja deh..."
> "Produk instan itu ibarat beli baju di factory outlet Bu/Pak — ukuran dan modelnya gak bisa custom. Brand tetangga jualan produk yang sama persis. Maklon exclusive di Blessindo, produk Ibu/Bapak PUNYA formulasi sendiri. It's truly YOUR brand."

### 17. "Bisa gak saya meeting dulu sama tim ahli-nya?"
> "Bisa banget! Saya atur Zoom meeting sama team R&D kita. Ibu/Bapak bisa diskusi langsung tentang formula yang diinginkan, concern kulit, target market. Gratis, gak ada ikatan apa-apa."

---

## OBJECTION LAINNYA (3 Skenario)

### 18. "Saya masih riset-riset dulu..."
> "Saya bantu risetnya sekarang Bu/Pak! Nih, kita ada guide lengkap Cara Bikin Brand Skincare dari Nol — gratis. Bisa sambil Ibu/Bapak pelajari. Kalau ada pertanyaan, WhatsApp saya langsung ya. Saya gak maksa, tapi saya standby terus."

### 19. "Suami/istri saya yang putusin, bukan saya..."
> "Wah justru ajak beliau ngobrol bareng dong Bu/Pak! Saya bisa jelasin sekalian, dari sisi bisnis, keamanan, dan potensi pasarnya. Bisa by phone atau kopi darat. Lebih enak kalau berdua, bisa ambil keputusan bareng."

### 20. "Bagaimana kalau produknya gak laku?"
> "Itu concern yang valid Bu/Pak. Makanya di awal kita konsultasi dulu: target market, positioning, cara jualan. Kita gak cuma bikin produk, kita bantu strategi go-to-market-nya. Plus, risiko bisa diminimalkan dengan mulai dari MOQ kecil dulu buat test market."
