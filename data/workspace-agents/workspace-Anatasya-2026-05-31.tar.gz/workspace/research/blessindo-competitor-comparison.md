# Comparison Sheet — Blessindo vs Kompetitor
*(Internal use: untuk bekal sales rep)*

---

## OVERVIEW

| | Blessindo | Mash Moshem | Dreamlab | Sinon Aquif | Pillars |
|---|---|---|---|---|---|
| **Berdiri** | 2015 | - | - | - | - |
| **Lokasi** | Bandung | - | Surabaya | - | - |
| **Sertifikasi** | BPOM, HALAL, CPKB, Derm | BPOM, CPKB A | BPOM, HALAL | BPOM, HALAL, HAKI | BPOM |

---

## KEUNGGULAN BLESSINDO

### 1. Sertifikasi Terlengkap di Kelasnya 🏆
> Blessindo satu-satunya yang punya **BPOM + HALAL + CPKB + Dermatology-tested** dalam satu paket.
> 
> *Script:* "Ibu/Bapak gak perlu pusing urus legalitas di tempat berbeda-beda. Di Blessindo, semuanya satu atap."

### 2. 11 Tahun Melayani Dokter & Klinik 👨‍⚕️
> Basis klien utama adalah dokter dan klinik — segmen paling demanding dalam skincare.
> 
> *Script:* "Kalau dokter aja percaya sama Blessindo selama 11 tahun, artinya kualitas kita udah teruji."

### 3. Formula Eksklusif Bareng MBC Labs 🧪
> Bukan formula generik copy-paste. Setiap klien dapet formula unik.
> 
> *Script:* "Produk Ibu/Bapak gak bakal sama persis kayak brand lain. Karena formulanya dikembangin khusus buat Ibu/Bapak."

### 4. Full-Service dari A-Z 🎯
> Dari formulasi, legalitas, produksi, packaging, sampai saran go-to-market.
> 
> *Script:* "Ibu/Bapak fokus jualan dan branding. Urusan produksi & legalitas, serahin ke kita."

### 5. Di Bandung — Akses Mudah 🏔️
> Buat klien Jabodetabek & Jabar, visit pabrik gampang.
> 
> *Script:* "Kapan-kapan mampir ke Bandung Bu/Pak, kita tur pabrik sambil ngopi."

---

## CARA JAWAB PERTANYAAN KOMPETITOR

### Q: "Mash Moshem katanya CPKB Grade A, lebih bagus dong?"
> "CPKB itu standar, Bu/Pak — Grade A atau B sama-sama disetujui BPOM. Bedanya di kelengkapan. Blessindo selain CPKB juga punya uji Dermatologi yang mereka gak ada. Plus, kita 11 tahun, formula eksklusif bareng MBC Labs. Grade bukan satu-satunya ukuran kualitas."

### Q: "Dreamlab katanya MOQ fleksibel, lebih cocok buat pemula?"
> "MOQ kita juga fleksibel kok Bu/Pak — ada paket starter buat yang baru mulai. Tapi yang bikin beda: formula kita dikembangin khusus bareng MBC Labs, bukan formula siap pakai. Jadi produk Ibu/Bapak bener-bener orisinal. Dreamlab di Surabaya, kita di Bandung — lebih deket buat support."

### Q: "Sinon Aquif katanya bantuin HAKI juga?"
> "Blessindo juga bantu HAKI kok Bu/Pak — di paket premium dan growth. Tapi yang mereka gak punya: uji Dermatology-tested. Di industri skincare, klaim 'dermatology-tested' itu nilai jual yang powerful. Kita punya itu."

---

## YANG GAK BOLEH DILAKUKAN
- ❌ Ngejelekin kompetitor secara langsung
- ❌ Ngaku-ngaku hal yang gak ada buktinya
- ❌ Bandingin harga doang tanpa jelasin value
- ✅ Fokus di value & uniqueness Blessindo
- ✅ Kalau ditanya kompetitor, jawab objektif + arahkan balik ke keunggulan kita
- ✅ Akui kalau gak tau, bilang "Saya cek dulu ya" — jangan ngarang
