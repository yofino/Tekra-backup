# CV Blessindo Priority Abadi — Research

## Profil Perusahaan
- **Nama:** CV Blessindo Prioriti Abadi
- **Berdiri:** 2015
- **Alamat:** Jl. Batununggal Elok Raya No.9, Bandung, Jawa Barat 40267
- **GM:** Roni Fitriawan
- **Bisnis:** Private label / maklon (OEM) skincare — 70% pelanggan private-label
- **Sertifikasi:** BPOM, HALAL, CPKB, Dermatology-tested
- **Lab partner:** MBC Labs
- **Kantor:** +62 22 7509999 | Mobile: +62 878-2599-1199
- **Email marketing:** marketing@blessindo.co.id

## Brand Sendiri & Produk
- Brand skincare sendiri (selain OEM)
- 143+ produk — dari disinfectant, cleanroom equipment, sampai skincare
- Target market: dokter, klinik, brand owner, end consumer

## Digital Presence
- 🌐 Website: blessindo.co.id (tapi isinya B2B medical equipment, bukan skincare)
- 📸 IG: @blessindo_aesthetic — 1,644 followers | 497 posts
- 📘 Facebook: Blessindo Prioriti Abadi (Bandung)
- LinkedIn: CV. Blessindo

## Aktivitas Marketing Saat Ini
- Simposium kedokteran kulit & estetika
- Workshop/lokakarya kecil buat dokter
- Trade Expo Indonesia 2024 (dilirik buyer Malaysia & Afrika)
- Konten IG: edukasi maklon skincare, legalitas BPOM, kualitas produk

## Catatan
- Ada perusahaan saudara: PT Blessindo Mulia Abadi (est. 2007) — supplier alat medis/lab
- Website utama isinya B2B equipment — skincare belum punya website khusus
- IG engagement modest — peluang besar buat improve digital marketing
- Posisi bagus: one-stop maklon bersertifikasi lengkap, bisa jadi unique selling point
