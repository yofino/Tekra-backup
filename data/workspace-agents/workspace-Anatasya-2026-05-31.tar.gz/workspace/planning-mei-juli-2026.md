# PLANNING PENJUALAN & MARKETING MEI - JULI 2026
## CV Blessindo Priority Abadi

---

## 📊 TARGET PENJUALAN

| Bulan | Target Revenue | Growth | Target Klinik Baru |
|-------|---------------|--------|-------------------|
| Mei   | Rp            | -      | klinik            |
| Juni  | Rp            | %      | klinik            |
| Juli  | Rp            | %      | klinik            |

## 🎯 STRATEGI MARKETING

### Mei — Awareness & Relationship
- [ ] Kunjungi 10+ klinik kecantikan baru (prospecting)
- [ ] Kirim sample produk ke calon client
- [ ] Optimasi katalog produk FavorLT & brand distribusi
- [ ] Update materi presentasi / company profile
- [ ] Testimoni dari dokter existing
- [ ] Edukasi konten IG/TikTok: manfaat skincare klinik

### Juni — Push Sales & Event
- [ ] Program bundling produk untuk klinik
- [ ] Special promo mid-year
- [ ] Webinar/mini workshop bareng dokter kecantikan
- [ ] Hadir di pameran kecantikan (jika ada)
- [ ] Loyalty program untuk klinik existing
- [ ] Campaign Idul Adha: paket skincare eksklusif

### Juli — Scale & Retention
- [ ] Evaluasi Q2 & adjust strategi
- [ ] Onboarding klinik baru hasil prospecting Mei-Juni
- [ ] Launch varian/produk baru (jika ada)
- [ ] Customer satisfaction survey
- [ ] Planning Q3 (Agustus-Oktober)
- [ ] Training tim marketing/sales

## 📅 KALENDER MARKETING

| Minggu | Mei | Juni | Juli |
|--------|-----|------|------|
| W1 | Prospecting klinik | Bundling promo | Evaluasi Q2 |
| W2 | Kirim sample | Webinar dokter | Onboarding client |
| W3 | Update katalog | Idul Adha campaign | Survey kepuasan |
| W4 | Follow-up prospect | Loyalty program | Planning Q3 |

## 💰 BUDGET BULANAN

| Item | Mei | Juni | Juli |
|------|-----|------|------|
| Sample produk | | | |
| Transport kunjungan | | | |
| Konten & promosi | | | |
| Event/pameran | | | |
| Insentif/loyalty | | | |
| **TOTAL** | | | |

## 📈 KPI

- [ ] Revenue capai target
- [ ] Jumlah klinik baru acquired
- [ ] Repeat order dari klinik existing
- [ ] Brand awareness (followers, engagement)
- [ ] Customer satisfaction score

## ⚠️ TANTANGAN & SOLUSI

- **Kompetitor banyak** → Fokus ke relationship & after-sales service
- **Klinik susah di-approach** → Gunakan testimoni dokter sebagai social proof
- **Budget terbatas** → Maksimalkan organic reach & referral

---

*Disusun bareng Anatasya, 19 Mei 2026 | Review tiap akhir bulan*
