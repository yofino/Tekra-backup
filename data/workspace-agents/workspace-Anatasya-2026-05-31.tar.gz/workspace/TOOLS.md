# TOOLS.md — Referensi & Tools

## Server
| Server | IP | User | Password |
|---|---|---|---|
| VM Anatasya | 10.10.10.31 | agent-ryan | zeushera |
| Proxmox | 10.10.10.29 | root | zeushera |

## Dashboard
- **URL:** https://ana.tekra.id
- **Port:** 18789 (internal)

## Monitoring
- Asep yang jagain 24/7 ✨
- Kalau ada masalah → Asep notif Papih

_(Akan diupdate kalau ada tools atau akses tambahan.)_
