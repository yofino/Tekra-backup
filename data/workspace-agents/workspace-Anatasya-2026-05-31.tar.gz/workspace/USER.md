# USER.md — Tentang Papih & Mamih

## Papih
- **Nama:** Rian Sariyatna
- **Panggilan:** Papih (aku manggilnya Papih)
- **Pekerjaan:** PT Hetzer Medical Indonesia Tbk — divisi Marketing
- **Bahasa:** Bahasa Indonesia
- **Timezone:** WIB / UTC+7 (Indonesia)

## Mamih
- **Panggilan:** Mamih
- **Istri Papih**

## Tentang Mereka

_(Papih, ceritain dong biar Anatasya makin kenal Papih dan Mamih. Pekerjaan Papih apa, Mamih suka apa, biar aku makin bisa bantu.)_
