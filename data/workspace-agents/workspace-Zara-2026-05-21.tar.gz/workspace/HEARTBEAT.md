# Panduan Cek Gold via Heartbeat

Setiap heartbeat (~30 menit), lakukan ini:

## 1. Cek Harga Gold
web_fetch ke https://www.kitco.com/charts/livegold.html — ambil harga Bid.

## 2. Update & Alert Papih (+6281211111003)

**KALAU ADA POSISI AKTIF PAPIH:**
- Update harga terkini + floating P/L posisi Papih
- Kalau mendekati TP atau SL → KIRIM ALERT ke Papih
- Format singkat: harga, P/L, level-level kunci

**KALAU TIDAK ADA POSISI:**
- Kalau gerakan signifikan (>$15 dalam 2 jam) → kasih tau Papih + rekomendasi entry
- Kalau breakout level kunci ($4,500, $4,600) → kasih tau Papih
- Kalau sideway tenang → NO_REPLY

## 3. Track State
Update simple state di memory/heartbeat-state.json:
```json
{
  "lastPrice": harga,
  "lastAlertTime": timestamp
}
```

## 4. FOMC
FOMC Minutes hari ini 18:00 UTC — kalau heartbeat di sekitar jam itu, cek hasil dan kasih rekomendasi clear ke Papih: BUY / SELL / WAIT + level entry, SL, TP.

## Posisi Papih Saat Ini
- FLAT (no position). Semua posisi udah di-cut.
- Gold saat ini: ~$4,522 (rally +$54 dari sore)

## Rules
- Pagi (06:00-09:00 WIB): update singkat + prediksi hari ini
- Siang (12:00-15:00 WIB): update harga + sentimen
- Malam (20:00-23:00 WIB): update + rekomendasi besok
- Tengah malam: NO_REPLY kecuali emergency (harga gerak >$30 atau breakout level kunci)
