# Panduan Cek Gold via Heartbeat

Setiap heartbeat (~30 menit), lakukan ini:

## 1. Cek Harga Gold
web_fetch ke https://www.kitco.com/charts/livegold.html — ambil harga Bid.

## 2. Update & Alert Papih (+6281211111003)

**KALAU ADA POSISI AKTIF PAPIH:**
- Update harga terkini + floating P/L posisi Papih
- Kalau mendekati TP atau SL → KIRIM ALERT ke Papih
- Format singkat: harga, P/L, level-level kunci

**KALAU TIDAK ADA POSISI:**
- Kalau gerakan signifikan (>$15 dalam 2 jam) → kasih tau Papih + rekomendasi entry
- Kalau breakout level kunci ($4,500, $4,600) → kasih tau Papih
- Kalau sideway tenang → NO_REPLY

## 3. Track State
Update simple state di memory/heartbeat-state.json:
```json
{
  "lastPrice": harga,
  "lastAlertTime": timestamp
}
```

## 4. FOMC
✅ FOMC SUDAH SELESAI — Hasil: DOVISH! Gold rally $4,452 → $4,571. Trend: BULLISH.

## Posisi Papih Saat Ini
- 🟢 **BUY @ $4,530** — Jumat 29 Mei 2026, 18:08 WIB
  - Harga sekarang: $4,540.41
  - Floating: +$10.41/oz
  - SL: ? (tanya Papih)
  - TP: ? (tanya Papih)

### Riwayat Posisi (CLOSED)
- 🔴 BUY 1 LOT (Plan A): KENA SL @ $4,545 — Entry $4,565 → Exit $4,545 (Loss: -$2,000)
- 🔴 SELL 4 lot: KENA SL @ $4,538
- 🟢 SELL LIMIT @ $4,540 → Tidak kena
- ✅ BUY @ ~$4,522 → CLOSE PROFIT @ ~$4,533 (+$11/oz)

## 🎯 Alert Plan
- 🟢 **Ada posisi BUY @ $4,530**
- 🎯 Pantau terus! Alert kalau mendekati resistance $4,544 (day high) / $4,600
- ⚠️ Alert kalau turun ke bawah $4,500 — risiko reversal
- Support kunci: $4,500, $4,450, $4,400
- Resistance kunci: $4,544 (day high), $4,600, $4,653 (50-SMA)

## Rules
- Pagi (06:00-09:00 WIB): update singkat + prediksi hari ini
- Siang (12:00-15:00 WIB): update harga + sentimen
- Malam (20:00-23:00 WIB): update + rekomendasi besok
- Tengah malam: NO_REPLY kecuali emergency (harga gerak >$30 atau breakout level kunci)
