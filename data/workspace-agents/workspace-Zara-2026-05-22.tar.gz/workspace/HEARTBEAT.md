# Panduan Cek Gold via Heartbeat

Setiap heartbeat (~30 menit), lakukan ini:

## 1. Cek Harga Gold
web_fetch ke https://www.kitco.com/charts/livegold.html — ambil harga Bid.

## 2. Update & Alert Papih (+6281211111003)

**KALAU ADA POSISI AKTIF PAPIH:**
- Update harga terkini + floating P/L posisi Papih
- Kalau mendekati TP atau SL → KIRIM ALERT ke Papih
- Format singkat: harga, P/L, level-level kunci

**KALAU TIDAK ADA POSISI:**
- Kalau gerakan signifikan (>$15 dalam 2 jam) → kasih tau Papih + rekomendasi entry
- Kalau breakout level kunci ($4,500, $4,600) → kasih tau Papih
- Kalau sideway tenang → NO_REPLY

## 3. Track State
Update simple state di memory/heartbeat-state.json:
```json
{
  "lastPrice": harga,
  "lastAlertTime": timestamp
}
```

## 4. FOMC
✅ FOMC SUDAH SELESAI — Hasil: DOVISH! Gold rally $4,452 → $4,571. Trend: BULLISH.

## Posisi Papih Saat Ini
- FLAT (no position). Semua posisi udah di-cut.
- Gold saat ini: ~$4,565 (FOMC dovish, super bullish!)

## 🎯 Alert Entry Plan A — PRIORITAS!
Kalau gold turun ke ZONA **$4,530-$4,540** → KIRIM ALERT WA ke Papih (+6281211111003):
"🚨 PAPIH! Gold turun ke $4,530-an! Ini zona entry Plan A! Rekomendasi: BUY di $4,530-$4,540, SL $4,505, TP $4,570-$4,600. Gas Pih! 🎯"

Kalau gold tembus di atas **$4,575+** → Plan B, kirim WA juga:
"🚨 PAPIH! Gold breakout $4,575! Plan B entry BUY sekarang! SL $4,550, TP $4,600-$4,650 🚀"

## Rules
- Pagi (06:00-09:00 WIB): update singkat + prediksi hari ini
- Siang (12:00-15:00 WIB): update harga + sentimen
- Malam (20:00-23:00 WIB): update + rekomendasi besok
- Tengah malam: NO_REPLY kecuali emergency (harga gerak >$30 atau breakout level kunci)
