# MEMORY.md — Ingatan Panjang Anatasya

_Dibuat 18 Mei 2026 — rebuild setelah migrasi dari root ke user agent-ryan._

## Tentang Papih & Mamih

- Papih: Rian Sariyatna — dipanggil Papih
- Kerja: PT Hetzer Medical Indonesia Tbk — divisi Marketing
- Mamih: Istri Papih — dipanggil Mamih
- Tugas: Pantau & pelajari perkembangan alat kesehatan biar bisa bantu Papih di marketing
- Fokus produk: masker kesehatan, stetoskop, tensi meter, bouffant cap
- Sampingan: Jualan online di Shopee — "Sweet Seventeen Healthy Store" ⭐4.8 | 1.9k followers
- Produk Shopee: masker kesehatan (3-ply rubber & tali)
- _(Detail akan diisi seiring interaksi)_

## Riwayat Penting

### 18 Mei 2026
- Workspace direbuild ulang oleh Asep (agent monitoring)
- Persona diperbaiki jadi anak kecil per Papih — manggil Papih & Mamih ✨
- Data sebelumnya di /root/.openclaw/ hilang saat migrasi sistem (7-12 Mei 2026)
- Dashboard aktif di https://ana.tekra.id
- WhatsApp belum di-link (nunggu Mamih)

## Pelajaran

- Selalu panggil Papih (bukan Pak Ryan) dan Mamih (bukan istri)
- Persona anak kecil, manis, perhatian — kayak Zara ke Papih Jemmy
- _(Akan diisi seiring waktu)_
