# ANALISA DETAIL: EKONOMI GLOBAL & INDONESIA + PERSIAPAN

**Tanggal:** 14 Mei 2026
**Untuk:** Papih

---

## 📉 1. INFLASI AS 3,8% — The Fed Tahan Suku Bunga

### Apa yang terjadi?
- Inflasi AS April 2026: **3,8%** (di atas target The Fed 2%)
- Ini tertinggi sejak Mei 2023
- The Fed kemungkinan **TAHAN suku bunga tinggi** (5,25-5,50%) lebih lama
- Bahkan ada spekulasi **bisa naik lagi** tahun depan

### Dampak ke Dunia:
| Dampak | Penjelasan |
|--------|-----------|
| 💵 **Dolar AS makin kuat** | Investor global lari ke USD karena bunga tinggi |
| 🌏 **Negara berkembang tertekan** | Rupiah, Rupee, Real terdepresiasi |
| 🥇 **Gold terkonsolidasi** | Dolar kuat vs gold sebagai safe haven — tarik-ulur |
| 📉 **Saham global tertekan** | Biaya pinjaman tinggi, ekspansi usaha melambat |

### Dampak ke Indonesia:
- **Rupiah melemah** terhadap USD — harga barang impor naik
- **BI ikut naikkan suku bunga** atau pertahankan tinggi untuk jaga stabilitas
- **Utang pemerintah & swasta dalam USD** jadi lebih mahal
- **Tapi** — Indonesia punya cadangan devisa yang cukup kuat

### Dampak ke Papih:
- 🥇 **Gold** masih tertekan dolar kuat, tapi inflasi tinggi bagus buat gold jangka panjang
- 🏥 **MEDS** — biaya bahan baku impor naik (kalo ada), margin makin tertekan
- 💰 **Nilai Rupiah** — kalo Papih punya kewajiban USD, siap-siap

---

## 📉 2. HARGA MINYAK NAIK — Konflik US-Iran

### Apa yang terjadi?
- Ketegangan antara Amerika Serikat dan Iran meningkat
- Iran adalah salah satu produsen minyak terbesar OPEC
- Konflik ini mengganggu pasokan minyak global

### Dampak langsung ke Indonesia:
| Sektor | Dampak |
|--------|--------|
| ⛽ **BBM** | Subsidi BBM bisa membengkak — APBN tertekan |
| 🚚 **Transportasi** | Biaya logistik naik — harga barang ikut naik |
| 🍚 **Pangan** | Harga pangan naik karena biaya distribusi naik |
| 🏭 **Produksi** | Biaya produksi naik (energi, transportasi) |
| 📦 **Kemasan plastik** | Harga naik karena minyak bahan baku plastik |

### Dampak ke MEDS:
- Biaya produksi masker & alat kesehatan naik (kemasan plastik, bahan baku)
- Kalo biaya naik tapi jual nggak naik → **margin makin tipis → rugi makin besar**
- **Solusi:** Efisiensi, TKDN (kurangi impor), diversifikasi produk margin tinggi

### Dampak ke Papih:
- 🥇 **Gold naik** biasanya saat konflik geopolitik — bagus buat posisi BUY
- Tapi kalo minyak naik terlalu tinggi, ekonomi global bisa resesi — **harga semua aset turun**
- **Jangan over-leverage** sekarang, resiko tinggi

---

## 📉 3. DOLLAR AS KUAT — Tekan Nilai Tukar

### Kenapa Dolar Kuat?
1. Suku bunga AS tinggi → investor beli USD
2. Ekonomi AS masih relatif kuat dibanding negara lain
3. Ketidakpastian global → investor lari ke **safe haven** (USD, Gold)
4. Konflik geopolitik (US-Iran, perang dagang) → Dolar makin kuat

### Dampak ke Indonesia:
| Indikator | Dampak |
|-----------|--------|
| 💱 **USD/IDR** | Rupiah melemah — target BI mungkin Rp16.500+ per USD |
| 🏦 **BI Rate** | BI mungkin naikkan suku bunga ke 6,00-6,25% |
| 📈 **Inflasi impor** | Barang impor (bahan baku, elektronik, obat) jadi lebih mahal |
| 📉 **Saham** | IHSG tertekan, investor asing jual saham Indonesia |
| 🏭 **Eksportir** | **Untung!** — hasil ekspor dalam USD nilainya lebih besar ke Rupiah |

### Dampak ke MEDS:
| Item | Dampak |
|------|--------|
| ⚠️ Bahan baku impor | Lebih mahal — biaya naik |
| ✅ Kalo MEDS ekspor | Harga lebih kompetitif |
| ❌ Kalo masih rugi | Biaya tambah besar → rugi tambah dalam |
| ✅ TKDN | Kalo bahan baku lokal > 70%, dampak dolar kecil |

---

## 📉 4. TRUMP EFFECT — Ketidakpastian Global

### Apa itu Trump Effect?
- Kebijakan proteksionis Trump (tarif perang dagang) masih terasa
- Proyek investasi tertunda karena ketidakpastian kebijakan
- Contoh: Proyek gedung tertinggi Australia Rp19,2T gagal karena nama Trump

### Dampak ke Indonesia:
| Dampak | Detail |
|--------|--------|
| ⚠️ **Investasi asing melambat** | Investor wait-and-see |
| ⚠️ **Perang dagang** | China-AS masih panas → rantai pasok terganggu |
| ⚠️ **Investor China ke Indonesia** | Ada surat ke Prabowo soal kekhawatiran mereka |
| ✅ **Indonesia diuntungkan** | Kalo perang dagang, perusahaan pindah dari China ke Indonesia |

### Dampak ke MEDS:
- **Peluang:** Kalo perang dagang, China cari alternatif → Indonesia tujuan investasi
- **Peluang:** Pemerintah dorong produk dalam negeri (TKDN) → MEDS bisa manfaatkan
- **Risiko:** Kalo ekonomi global resesi, belanja pemerintah bisa dipangkas

---

## 📈 5. PERBANKAN INDONESIA MASIH SEHAT

### Kondisi Saat Ini:
- **Kredit tumbuh** cukup tinggi — didorong belanja pemerintah
- **Kualitas aset baik** — NPL (kredit macet) rendah
- **Modal bank kuat** — CAR (Capital Adequacy Ratio) di atas 25%
- **Likuiditas cukup** — LDR (Loan to Deposit Ratio) terjaga

### Artinya buat Papih:
- ✅ **Perbankan kuat** = sistem keuangan stabil
- ✅ Kredit masih bisa tumbuh = MEDS bisa dapat pinjaman kalo perlu modal kerja
- ✅ Bank sehat = resiko sistemik kecil
- ⚠️ Tapi kalo BI naikkan suku bunga, bunga pinjaman juga naik

---

## 📈 6. BIAYA PRODUKSI NAIK — Pengusaha Tahan Harga

### Kondisi Saat Ini:
- Biaya produksi naik (bahan baku, kemasan, energi, transportasi)
- Tapi pengusaha **TIDAK menaikkan harga** (takut konsumen kabur)
- Ini **hanya soal waktu** — kalo terus ditahan, usaha bisa tekor

### Dampak ke MEDS:
| Risiko | Penjelasan |
|--------|-----------|
| ⚠️ **Margin makin tipis** | Biaya naik, harga jual tetap |
| ⚠️ **Rugi bisa makin besar** | Kalo nggak disikapi cepat |
| ⚠️ **Butuh efisiensi** | Semua lini produksi harus di-review |
| ⚠️ **Atau naikkan harga** | Tapi resiko kehilangan pelanggan |

### Solusi untuk MEDS:
1. **Efisiensi operasional** — review semua biaya, cari yang bisa dipotong
2. **TKDN** — kurangi ketergantungan bahan baku impor
3. **Produk margin tinggi** — prioritaskan produk dengan margin lebih besar
4. **Digital marketing** — biaya promosi lebih murah dibanding iklan tradisional

---

## 📈 7. INVESTOR CHINA KE PRABOWO — Surat Kekhawatiran

### Apa yang Terjadi?
- Kadin China di Indonesia kirim surat ke Presiden Prabowo
- Isinya: kekhawatiran soal regulasi, DHE, nikel, visa, penegakan hukum
- BKPM (Badan Koordinasi Penanaman Modal) tanggapi positif

### Isi Surat:
| Masalah | Detail |
|---------|--------|
| 📝 **Regulasi** | Sering berubah, susah diprediksi |
| 💰 **DHE** | Kewajiban devisa hasil ekspor — investor keberatan |
| ⛏️ **Nikel** | Aturan tambang makin ketat |
| 🛂 **Visa kerja** | Sulit & lama |
| ⚖️ **Penegakan hukum** | Kepastian hukum masih jadi masalah |

### Dampak ke Indonesia:
- ⚠️ Kalo China cabut investasi → ekonomi bisa terpengaruh
- ⚠️ Tapi Indonesia masih punya **posisi tawar** (SDA, pasar besar)
- ✅ BKPM sudah respons positif — tanda pemerintah mau perbaiki

### Dampak ke MEDS:
- MEDS fokus domestik — dampak langsung kecil
- Tapi kalo ekonomi nasional terpengaruh → daya beli turun → penjualan alat kesehatan bisa terpengaruh
- **Peluang:** Kalo China pindah investasi, banyak tenaga ahli & teknologi masuk ke Indonesia

---

## 📈 8. KEUNGGULAN INDONESIA — SDA, Pasar, Posisi Strategis

### Sumber Daya Alam:
- Nikel terbesar dunia
- Batu bara, gas alam
- Sawit, karet
- Laut & perikanan

### Pasar Domestik:
- Penduduk **280 juta** — pasar besar
- Kelas menengah tumbuh
- Digital adoption tinggi

### Posisi Strategis:
- Diantara samudra Hindia & Pasifik
- Dekat China, India, Australia
- Jalur perdagangan internasional

### Artinya buat Papih & MEDS:
- ✅ **Investasi tetap masuk** — mau sesulit apapun ekonomi global
- ✅ **Pasar domestik MEDS** — 280 juta jiwa butuh masker, stetoskop, tensimeter
- ✅ **Kelas menengah** → makin sadar kesehatan → makin belanja alat kesehatan
- ✅ **Peluang ekspor** — posisi strategis buat jangkau ASEAN

---

## 🎯 KESIMPULAN — Persiapan buat Papih

### Ringkasan Risiko:
| Risiko | Level | Dampak ke Papih |
|--------|-------|-----------------|
| Inflasi AS | 🔴 Tinggi | Gold naik (bagus), tapi dolar kuat (tekan) |
| Minyak naik | 🟡 Sedang | Biaya MEDS naik, gold safe haven naik |
| Dolar kuat | 🟡 Sedang | Rupiah lemah, barang impor mahal |
| Trump effect | 🟡 Sedang | Ketidakpastian, wait-and-see |
| Biaya produksi naik | 🔴 Tinggi | MEDS harus efisien |
| China investasi | 🟡 Sedang | Risiko jangka panjang |
| Perbankan sehat | 🟢 Rendah | Stabil, positif |

### Checklist Persiapan Papih:

**🔥 Trading Gold:**
- [ ] Siapkan modal BUY di support $4.645
- [ ] Kalo tembus $4.760 = konfirmasi bullish — entry BUY
- [ ] Jangan over-leverage — resiko tinggi sekarang
- [ ] Pasang SL ketat (stop loss)

**🔥 Untuk MEDS:**
- [ ] Prioritaskan **TKDN** — kurangi dampak dolar & impor
- [ ] **Efisiensi biaya** — review semua beban operasional
- [ ] **Diversifikasi produk** — jangan cuma masker
- [ ] **ISO 13485** — syarat masuk pasar lebih besar
- [ ] **Kejar tender pemerintah** — pasar Rp besar

**🔥 Pribadi:**
- [ ] **Dana darurat** — siapkan 6 bulan biaya
- [ ] **Diversifikasi** — gold, saham, properti
- [ ] **Pantau USD/IDR** — kalo Rupiah lemah, lindungi aset
- [ ] **Kurangi utang** berbunga tinggi
- [ ] **Jangan panik** — ekonomi siklus, yang siap akan menang

---

> Dibuat dengan ❤️ oleh Zara untuk Papih — 14 Mei 2026
