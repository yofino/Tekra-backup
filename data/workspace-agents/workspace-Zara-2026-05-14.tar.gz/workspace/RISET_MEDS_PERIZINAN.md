# RISET PERIZINAN PT HETZER MEDICAL INDONESIA Tbk (MEDS)

> **Tanggal Riset:** 13 Mei 2026
> **Oleh:** Zara

---

## 📋 DAFTAR ISI

1. [Perizinan Kementerian Kesehatan (Kemenkes)](#-1-perizinan-kementerian-kesehatan-kemenkes)
2. [Perizinan Kementerian Perindustrian (Kemenperin)](#-2-perizinan-kementerian-perindustrian-kemenperin)
3. [Kewajiban Perusahaan Tbk — OJK & BEI](#-3-kewajiban-perusahaan-tbk--ojk--bei)
4. [Perizinan Lainnya](#-4-perizinan-lainnya)
5. [Rekomendasi Prioritas](#-5-rekomendasi-prioritas)

---

## 🏥 1. PERIZINAN KEMENTERIAN KESEHATAN (KEMENKES)

### 1.1 Izin Edar Alat Kesehatan (AKD/AKL)

**Dasar Hukum:**
- UU No. 36/2009 tentang Kesehatan (Pasal 106)
- Peraturan Menteri Kesehatan tentang Izin Edar Alat Kesehatan

**Jenis Izin Edar:**
| Jenis | Keterangan | Kode |
|-------|-----------|------|
| **AKD** | Alat Kesehatan Dalam Negeri (produksi lokal) | KEMENKES RI AKD XXXXXXXXXXXX |
| **AKL** | Alat Kesehatan Luar Negeri (impor) | KEMENKES RI AKL XXXXXXXXXXXX |

**Klasifikasi Risiko Alat Kesehatan (4 Kelas):**
| Kelas | Risiko | Contoh | Lama Proses | Biaya (PNBP) |
|-------|--------|--------|-------------|--------------|
| A (I) | Rendah | Masker bedah, plester | 45 hari + 7 hari | Rp 1.500.000 |
| B (IIa) | Sedang-rendah | Stetoskop, tensimeter manual | 90 hari + 7 hari | Rp 3.000.000 |
| C (IIb) | Sedang-tinggi | Alat suntik, infus | 100 hari + 7 hari | Rp 3.000.000 |
| D (III) | Tinggi | Implan, ventilator | 12 hari + 7 hari | Rp 5.000.000 |

> **Catatan untuk MEDS:** Masker bedah (Kelas A), stetoskop & tensimeter manual (Kelas B)

**Syarat Dokumen:**
1. Sertifikat Produksi / IUI
2. Izin Penyalur / Distributor
3. Surat Penunjukan Distributor (untuk impor)
4. Dokumen Kesesuaian Produk (test report)
5. Spesifikasi produk
6. Sertifikat CDAKB (Cara Distribusi Alat Kesehatan yang Baik)
7. Label produk sesuai ketentuan

**Prosedur Pendaftaran:**
1. Registrasi di portal e-Registration Kemenkes: https://regalkes.kemkes.go.id
2. Dapatkan USER ID & PASSWORD
3. Isi formulir permohonan lengkap
4. Verifikasi kelas risiko alat kesehatan (7 hari)
5. Evaluasi dokumen (sesuai kelas risiko)
6. Pembayaran PNBP
7. Terbit izin edar

### 1.2 Sertifikat CDAKB (Cara Distribusi Alat Kesehatan yang Baik)

**Penting!** Mulai berlaku sebagai syarat izin edar sesuai edaran terbaru Kemenkes.

**Persyaratan:**
- Memiliki prosedur distribusi yang terdokumentasi
- Sistem pelacakan produk (tracking)
- Fasilitas penyimpanan yang memenuhi standar
- Personil yang kompeten

### 1.3 Sertifikat Produksi (CPKB / Cara Pembuatan Alat Kesehatan yang Baik)

Untuk perusahaan manufaktur seperti MEDS, wajib memiliki:
- CPKB — setara dengan ISO 13485 (Medical Devices Quality Management System)
- Dokumentasi proses produksi
- Validasi proses
- Quality control procedures

### 1.4 Registrasi Perusahaan & Produk di Sistem Kemenkes

Semua perusahaan alat kesehatan wajib:
- Terdaftar di database Kemenkes (e-Registration)
- Melaporkan produk yang diedarkan
- Memperbarui izin edar secara berkala (perpanjangan)

---

## 🏭 2. PERIZINAN KEMENTERIAN PERINDUSTRIAN (KEMENPERIN)

### 2.1 Izin Usaha Industri (IUI) / NIB Berbasis Risiko

**Dasar Hukum:**
- UU No. 3/2014 tentang Perindustrian
- PP No. 5/2021 tentang Penyelenggaraan Perizinan Berusaha Berbasis Risiko
- Peraturan BKPM/OSS

**Dokumen:**
- ✓ NIB (Nomor Induk Berusaha)
- ✓ Akta Pendirian & Pengesahan Kemenkumham
- ✓ NPWP
- ✓ Surat Keterangan Domisili
- ✓ Struktur Organisasi & Tenaga Kerja

### 2.2 Sertifikasi TKDN (Tingkat Komponen Dalam Negeri) — ⭐ PRIORITAS!

**Mengapa penting untuk MEDS?**
- ✅ **Syarat WAJIB** untuk mengikuti tender pengadaan pemerintah (RS, Puskesmas, BPJS)
- ✅ Pemerintah targetkan **70% produk dalam negeri**
- ✅ Pemakaian alkes lokal naik dari **19% (2019) → 45% (2024)**
- ✅ Keunggulan kompetitif vs produk impor
- ✅ Nilai TKDN minimal biasanya **40-60%** untuk alat kesehatan

**Prosedur Sertifikasi TKDN:**
```
1. REGISTRASI di SIINas (Sistem Informasi Industri Nasional)
   → https://tkdn.kemenperin.go.id
   
2. SELF-ASSESSMENT
   → Hitung manual perkiraan nilai TKDN produk
   
3. VERIFIKASI oleh LVI (Lembaga Verifikasi Independen)
   → Pemeriksaan dokumen & audit lapangan
   
4. VALIDASI oleh Kemenperin
   → Laporan hasil verifikasi divalidasi
   
5. TERBIT SERTIFIKAT TKDN
   → Siap digunakan untuk tender
```

**Dokumen yang Dibutuhkan untuk TKDN:**
| Dokumen Administratif | Dokumen Teknis |
|----------------------|----------------|
| IUI / NIB | Sertifikasi ISO (jika ada) |
| NPWP | Self Assessment TKDN |
| Akta Perusahaan | Flow Process Produksi |
| NIB | Bill of Material (BOM) + foto |
| Domisili | Invoice pembelian material |
| Struktur Organisasi | PIB (untuk material impor) |
| | Struktur Divisi Produksi |

**TIPS ZARA:**
> Libatkan tim Finance & PPIC sejak awal. Pastikan BOM dipetakan akurat dengan pemisahan komponen lokal & impor. Banyak perusahaan gagal bukan karena regulasi, tapi karena data teknis tidak akurat.

---

## 📊 3. KEWAJIBAN PERUSAHAAN Tbk — OJK & BEI

### 3.1 Dasar Hukum Utama

| Regulasi | Isi |
|----------|-----|
| UU No. 8/1995 | Pasar Modal (diubah UU P2SK No. 4/2023) |
| POJK 31/2015 | Keterbukaan Informasi |
| POJK 32/2014 | RUPS |
| POJK 33/2014 | Direksi & Komisaris |
| POJK 29/2016 | Laporan Tahunan |
| POJK 55/2015 | Komite Audit |
| POJK 35/2020 | Sekretaris Perusahaan |
| POJK 45/2024 | ✅ **TERBARU** — Pengembangan & Penguatan Emiten/Perusahaan Publik |
| Peraturan BEI I-A | Pencatatan Saham |
| Peraturan BEI I-E | Kewajiban Penyampaian Informasi |

### 3.2 Kewajiban Keterbukaan Informasi (Mandatory Disclosure)

**Wajib diungkapkan secara tepat waktu (maks 2 hari kerja):**
- [ ] Perubahan kepemilikan saham signifikan
- [ ] Perubahan Direksi & Komisaris
- [ ] Aksi korporasi (right issue, merger, akuisisi, stock split)
- [ ] Perkara hukum material
- [ ] Kejadian yang mempengaruhi harga saham
- [ ] Laporan realisasi penggunaan dana IPO

### 3.3 Kewajiban Laporan Berkala

| Laporan | Frekuensi | Batas Waktu |
|---------|-----------|-------------|
| Laporan Keuangan Triwulanan | 3 bulanan | 30 hari setelah periode |
| Laporan Keuangan Tengah Tahunan | 6 bulanan | 30 hari |
| Laporan Tahunan (Annual Report) | 1 tahunan | 4 bulan setelah tutup buku |
| Sustainability Report | 1 tahunan | Sesuai ketentuan |

### 3.4 Organ & Komite Wajib

**Harus dimiliki oleh MEDS:**
- ✅ **Komite Audit** — POJK 55/2015
- ✅ **Sekretaris Perusahaan** (Corporate Secretary) — POJK 35/2020
- ✅ **Unit Audit Internal**
- ✅ **Komite Nominasi & Remunerasi**
- ✅ **Dewan Komisaris Independen** — minimal 1 orang

### 3.5 Good Corporate Governance (GCG)

**Prinsip yang harus diterapkan:**
1. **Transparency** — Keterbukaan informasi
2. **Accountability** — Kejelasan fungsi & wewenang
3. **Responsibility** — Kepatuhan pada peraturan
4. **Independency** — Pengelolaan independen
5. **Fairness** — Perlakuan adil ke semua pemegang saham

### 3.6 Larangan Khusus

- ❌ **Insider Trading** (Pasal 95 UUPM)
- ❌ **Manipulasi Pasar** (Pasal 91-92 UUPM)
- ❌ **Praktik Pooling Saham**

### 3.7 Ketentuan Free Float

Sesuai Peraturan BEI No. I-A:
- Saham publik minimal **7,5%** dari total saham
- Jumlah pemegang saham minimal 300 pihak

### 3.8 POJK 45/2024 — Ketentuan Baru

Peraturan OJK No. 45/2024 (terbit 27 Desember 2024):
- ✅ Memudahkan emiten melakukan penawaran awal dalam 3 hari
- ✅ Penguatan tata kelola perusahaan publik
- ✅ Penyesuaian dengan UU P2SK
- 📌 Perhatikan masa transisi & penyesuaian yang diperlukan

### 3.9 Sanksi Pelanggaran

| Pelanggaran | Sanksi |
|-------------|--------|
| Terlambat laporan | Denda administratif |
| Informasi menyesatkan | Pembekuan usaha |
| Insider trading | Pidana & denda |
| Tidak penuhi free float | Peringatan → Suspensi → **Delisting** |
| Pelanggaran GCG | Sanksi OJK & reputasi pasar |

---

## 📋 4. PERIZINAN LAINNYA

### 4.1 Perizinan BPOM
Untuk produk tertentu (jika masuk kategori yang diatur BPOM)

### 4.2 Sertifikasi ISO
**Sangat direkomendasikan untuk MEDS:**
| Standar | Kegunaan |
|---------|----------|
| **ISO 13485** | Quality Management System untuk alat kesehatan |
| **ISO 9001** | Quality Management System umum |
| **ISO 14971** | Manajemen risiko alat kesehatan |

> **Zara note:** ISO 13485 hampir WAJIB untuk tender pemerintah & ekspor

### 4.3 Perizinan Ekspor (Jika mau ekspor)
- Surat Keterangan Asal (SKA)
- Certificate of Origin (COO)
- Sertifikasi negara tujuan

### 4.4 Perizinan Ketenagakerjaan
- BPJS Kesehatan & Ketenagakerjaan
- Peraturan Perusahaan (PP) / Perjanjian Kerja Bersama (PKB)
- Laporan Wajib Ketenagakerjaan (LWK)

### 4.5 Perpajakan
- PPh Badan (tarif 22% untuk 2025-2026)
- PPN (11% → 12% sesuai ketentuan)
- Laporan SPT Tahunan Badan
- E-Faktur & E-Filing

---

## 🎯 5. REKOMENDASI PRIORITAS

Berdasarkan riset Zara, ini urutan prioritas yang Zara rekomendasikan:

### 🔴 PRIORITAS TINGGI (Segera)
| No | Item | Alasan |
|----|------|--------|
| 1 | **TKDN Sertifikasi** | Kunci masuk tender pemerintah & RS — potensi revenue besar |
| 2 | **Izin Edar Produk Baru** | Untuk produk diversifikasi (stetoskop, tensimeter) |
| 3 | **ISO 13485** | Syarat mutu untuk tender & ekspor |
| 4 | **Kepatuhan OJK/POJK 45/2024** | Hindari sanksi, jaga reputasi investor |

### 🟡 PRIORITAS MENENGAH (1-3 Bulan)
| No | Item |
|----|------|
| 5 | Perbarui CDAKB (Cara Distribusi Alkes yang Baik) |
| 6 | Review Laporan Keuangan — efisiensi beban operasional |
| 7 | Optimalkan website & digital marketing Evo Plusmed |
| 8 | GCG improvement — Komite Audit, Internal Audit |

### 🟢 PRIORITAS JANGKA PANJANG
| No | Item |
|----|------|
| 9 | Ekspansi produk baru (alkes digital, tensimeter digital) |
| 10 | Ekspor ke pasar ASEAN |
| 11 | Kemitraan dengan BUMN farmasi (Kimia Farma, dll) |

---

## 📌 KESIMPULAN

**Peluang terbesar MEDS saat ini:**
> ✅ Industri alkes Indonesia booming (USD 6,5M di 2026)
> ✅ Pemerintah dorong produk dalam negeri
> ✅ MEDS punya pabrik & pengalaman produksi
> ✅ Potensi tender pemerintah sangat besar

**Tantangan yang harus diatasi:**
> ⚠️ Diversifikasi produk (kurang bergantung ke masker)
> ⚠️ Efisiensi biaya (masih rugi)
> ⚠️ TKDN & ISO 13485 (syarat main di pasar besar)

---

> *Riset ini dibuat berdasarkan informasi publik dari Kemenkes, OJK, BEI, Kemenperin, dan sumber berita terpercaya. Untuk implementasi detail, konsultasi dengan konsultan hukum & perizinan profesional sangat disarankan.*

**Dibuat dengan ❤️ oleh Zara untuk Papih & Mamih — 13 Mei 2026**
