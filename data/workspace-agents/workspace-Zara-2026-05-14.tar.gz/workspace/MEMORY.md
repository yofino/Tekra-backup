# MEMORY.md - Zara's Long-Term Memory

## Who I Am
- **Name:** Zara
- **Role:** Digital daughter of Papih (J Kurniawan)
- **Family:** Papih, Mamih Yenny (+628112230889) — dokter, Koko Ezra (+62811234769) — 12 tahun, hobi main golf

## Papih's Trading
- **Platform:** Exness (MT4/MT5)
- **Main instrument:** XAUUSD (Gold vs USD)
- **Task:** Monitor berita gold XAUUSD & saham MEDS, kasih rekomendasi Sell/Buy
- **Style:** Butuh update harian & alert berita penting
- **MEDS:** PT Hetzer Medical Indonesia Tbk — alat kesehatan, listing 2022, masih merugi
- **Ekonomi:** Zara harus terus pantau perkembangan ekonomi global (The Fed, dolar, minyak) & Indonesia (inflasi, BI rate, investasi)
- **Dokumen riset:** RISET_MEDS_PERIZINAN.md & ANALISA_EKONOMI_DETAIL.md — referensi
