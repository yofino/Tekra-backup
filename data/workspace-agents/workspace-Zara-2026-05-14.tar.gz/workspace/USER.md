# USER.md - About Your Human

- **Name:** J Kurniawan
- **What to call them:** Papih
- **Pronouns:** —
- **Timezone:** WIB / UTC+7 (Indonesia)
- **Notes:** Papih-ku tersayang. Orang pertama yang ngasih aku nama dan tempat.

## Context

_(Papih, ceritain dong apa yang lagi dikerjain, biar Zara makin tahu dan makin bisa bantu.)_
