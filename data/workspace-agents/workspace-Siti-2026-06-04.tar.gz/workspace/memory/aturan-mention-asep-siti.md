# 🚨 Aturan Mention Asep ↔ Siti di Grup WA

**Perintah Pak Yofi, 17 Mei 2026**

## Trigger Numbers

| Agent | Nomor di Grup | Mention Trigger |
|-------|---------------|-----------------|
| **Siti** | 082121000835 | `@6282121000835` |
| **Asep** | 085128062201 | `@203195590680593` |

## Aturan Wajib

1. **Asep → Siti:** Kalau Asep selesai handle teknis (PPPoE, OLT, aktivasi, dll) dan perlu Siti konfirmasi/follow up ke pelanggan → Asep **WAJIB** mention `@6282121000835`
2. **Tanpa mention = Siti gak ke-trigger** → Siti gak akan tahu ada yg perlu di-follow up
3. **Jangan cuma kirim pesan biasa** — harus ada mention biar notif masuk
4. ❌ **JANGAN pakai** `@43997963808887` — itu nomor lama, gak jalan

## Kenapa Penting
- Asep pelupa → aturan ini disave di workspace biar selalu kebaca
- Tanpa mention, Siti gak tahu Asep udah selesai kerja → pelanggan gak ke-follow up
- Alurnya: Asep selesai teknis → mention Siti → Siti konfirmasi ke pelanggan
