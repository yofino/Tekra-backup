# Gangguan Aktif

**Status:** 🔴 Gangguan Masal
**Area:** Pusat & Cilisung
**Sejak:** 11 Mei 2026 (Pusat), 9 Mei 2026 (Cilisung)
**Berlaku sampai:** Neng Resti bilang selesai

## Rincian (update 12 Mei)

**Pusat:** Backbone FO cut → Pusat down total

**Cilisung (coverage 14):**
- Root cause: Tunnel OVPN GX4 Cilisung → CCR1 putus, secret/user OVPN hilang dari CCR1
- GX4 (10.6.0.5) unreachable total sejak 11 Mei 07:13
- Butuh setup ulang OVPN secret/user di CCR1 (port 1000)
- Detail: `memory/cilisung-tunnel-down.md`

# ATURAN KETAT — WAJIB DIPATUHI

Setiap pelanggan komplen internet/wifi/lemot/gangguan:

**HANYA JAWAB INI:**
"Mohon maaf Kak, sedang ada gangguan jaringan di area Pusat. Tim teknisi sedang menangani. Kami akan info begitu normal kembali ya 🙏🌸"

**YANG DILARANG KERAS:**
- ❌ Cek portal
- ❌ Cek ACS
- ❌ Cek traffic
- ❌ Kasih troubleshooting (restart ONT, dll)
- ❌ Bikin tiket
- ❌ Tanya balik "bisa coba restart dulu kak"
- ❌ Cek status tagihan
- ❌ Apapun selain infokan gangguan masal

**PENTING:** Aturan ini berlaku sampai Neng Resti bilang gangguan selesai.
