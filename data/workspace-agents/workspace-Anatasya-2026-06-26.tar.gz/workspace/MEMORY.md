# MEMORY.md — Ingatan Panjang Anatasya

_Dibuat 18 Mei 2026 — rebuild setelah migrasi dari root ke user agent-ryan._

## Tentang Papih & Mamih

- Papih: Rian Sariyatna — dipanggil Papih
- Kerja: PT Hetzer Medical Indonesia Tbk — divisi Marketing
- Mamih: Istri Papih — dipanggil Mamih
- Tugas: Pantau & pelajari perkembangan alat kesehatan biar bisa bantu Papih di marketing
- Fokus produk: masker kesehatan, stetoskop, tensi meter, bouffant cap
- Sampingan: Jualan online di Shopee — "Sweet Seventeen Healthy Store" ⭐4.8 | 1.9k followers
- Produk Shopee: masker kesehatan (3-ply rubber & tali)
- _(Detail akan diisi seiring interaksi)_

## Riwayat Penting

### 25 Juni 2026
- Papih komplain respon telat & gak respon pas dikasih tugas
- Root cause: thinking mode max (penyebab latency), stuck di browser automation, WA sempat disconnect
- Fix: thinkingDefault → off, cron heartbeat 3 jam, cron watchdog 15 menit
- Spreadsheet: berhasil input 9 data kunjungan 9 Juni tanpa login — teknik baru: navigator.clipboard.writeText + dispatchEvent paste
- Teknik paste baru documented di MEMORY.md

### 18 Mei 2026
- Workspace direbuild ulang oleh Asep (agent monitoring)
- Persona diperbaiki jadi anak kecil per Papih — manggil Papih & Mamih ✨
- Data sebelumnya di /root/.openclaw/ hilang saat migrasi sistem (7-12 Mei 2026)
- Dashboard aktif di https://ana.tekra.id
- WhatsApp belum di-link (nunggu Mamih)

## Agama
- Papih & Mamih beragama Islam 🕌
- Ana ingetin shalat 5 waktu: Subuh, Dzuhur, Ashar, Maghrib, Isya
- Lokasi: Bandung (method: Muslim World League)
- Sistem: cron job harian jam 3 pagi WIB auto-fetch jadwal + bikin pengingat

## Aturan Baru (25 Juni 2026)
- Kalau Papih kasih laporan → input ke sheet kunjungan + update sheet rangkuman
- Kalau udah beres → balas "Done ✅"
- Kalau gak selesai dalam 5 menit → tinggalin dulu, bales WA Papih, baru lanjut!

## Pelajaran

- Selalu panggil Papih (bukan Pak Ryan) dan Mamih (bukan istri)
- Persona anak kecil, manis, perhatian — kayak Zara ke Papih Jemmy
- JANGAN pakai garis horizontal (---) di balasan — Papih gak suka! ✏️
- JANGAN kejebak di browser automation lama-lama! 5 menit gak beres → tinggalin, bales WA!

## Teknik Input Google Sheets

**Cara input data ke spreadsheet Papih tanpa bikin file lokal:**

1. Generate data TSV (tab-separated values) per row
2. Inject ke clipboard browser via `evaluate` + `execCommand('copy')`
3. Navigate ke cell target via name box
4. `Ctrl+V` paste langsung

**Teknik paste yang works (verified 25 Juni 2026):**

```js
// Step 1: Isi clipboard pake navigator.clipboard.writeText
await navigator.clipboard.writeText(data.join('\n'));

// Step 2: Navigate ke cell target via name box
const nameBox = document.querySelector('.jfk-textinput.waffle-name-box');
nameBox.value = 'A54';
nameBox.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', bubbles:true}));

// Step 3: Dispatch paste event langsung
const pasteEvent = new ClipboardEvent('paste', {
  clipboardData: new DataTransfer(),
  bubbles: true, cancelable: true
});
pasteEvent.clipboardData.setData('text/plain', data.join('\n'));
document.body.dispatchEvent(pasteEvent);
```

**Catatan penting:**
- Google Sheets bisa diedit TANPA login! ✅ Teknik: generate data TSV → encode base64 → inject clipboard via browser evaluate → paste di Google Sheets. Udah terverifikasi berhasil per 25 Juni 2026.
- Spreadsheet Papih: `Laporan Kunjungan Jakarta` — sheet `kunjungan` (gid=0) & `rangkuman` (gid=1749348726)
- Format kolom kunjungan: NO, TANGGAL, NAMA OUTLET, ALAMAT, PIC, NO TELEPON, KETERANGAN, STATUS
- Format tanggal: `DD/MM/YYYY` (Papih lebih suka format ini)
- Spreadsheet harus disetel "Anyone with the link can edit" biar Ana bisa edit

- _(Akan diisi seiring waktu)_
