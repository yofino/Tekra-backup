# HEARTBEAT.md

## Cek Model Aktif
Setiap heartbeat, panggil `session_status` dan cek model yang sedang aktif.
- Kalau model **bukan** `openai-codex/gpt-5.4` (misal sudah fallback ke Claude atau DeepSeek), kirim notif WhatsApp ke Yofi (+6282115448084) dengan pesan singkat: model GPT-5.4 sudah limit, sekarang pakai [nama model aktif].
- Kalau masih GPT-5.4, tidak perlu notif — lanjut HEARTBEAT_OK.
- Jangan spam: kalau sudah pernah notif fallback di session yang sama, skip (cukup sekali per transisi).
