# OLT Monitoring — Zabbix + Cron

**Dibuat:** 13 Mei 2026
**Tujuan:** Monitoring ONU online/offline per PON di Zabbix, biar teknisi & Yofi bisa langsung lihat tanpa perlu telnet manual.

## Kenapa Dibuat
- Sebelumnya teknisi gak tau kalo PON port udah penuh (EPON max 64, GPON max 128)
- ONU offline gak kedetect, makan slot
- Perlu monitoring biar bisa hapus ONU offline sebelum PON penuh

## Cara Kerja
1. Script `/opt/tekra-backup/olt_onu_monitor.py`
2. Cron tiap 6 jam (00:00, 06:00, 12:00, 18:00)
3. Telnet ke OLT → `show onu-info all` (EPON) atau `show ont-info` per ONU (GPON)
4. Hitung Online/Offline per PON → push ke Zabbix via trapper
5. Data tersimpan di Zabbix host `OLT-EPON-PUSAT-SNMP` & `OLT-GPON-PUSAT-SNMP`

## Cara Cek Data
Tinggal buka Zabbix → host:
- **OLT EPON Pusat (HSGQ)** — ID 10713
- **OLT GPON Pusat (HSGQ-G008ID)** — ID 10714

Item key per PON:
- `olt.onu.online.pon{N}` — jumlah online
- `olt.onu.offline.pon{N}` — jumlah offline
- `olt.onu.total.pon{N}` — total
- `olt.onu.capacity.pct.pon{N}` — persentase kapasitas

## OLT Credentials
| OLT | IP | User | Pass | Akses |
|---|---|---|---|---|
| EPON Pusat (HSGQ-E04) | 10.10.10.203 | root | admin | Telnet 23 |
| GPON Pusat (HSGQ-G008ID) | 10.10.10.204 | root | k34Nu335577 | Telnet 23 |
| EPON Cilisung (HSGQ-E04ID) | 192.168.101.10 | root | admin | Telnet 23 |

## Status Awal (13 Mei 2026)
```
EPON Pusat:
  PON1: Online=17  Offline=0   Total=17 (26.6%)
  PON2: Online=61  Offline=2   Total=63 (98.4%) ⚠️
  PON3: Online=59  Offline=2   Total=61 (95.3%) ⚠️
  PON4: Online=57  Offline=2   Total=59 (92.2%)

GPON Pusat:
  PON1: Online=23  Offline=0  Total=23 (18.0%)
  PON2: Online=20  Offline=0  Total=20 (15.6%)
  PON3: Online=17  Offline=0  Total=17 (13.3%)
```

## Related Files
- `tools/ref-pusat.md` — Referensi perangkat POP Pusat
- `tools/ref-cilisung.md` — Referensi perangkat POP Cilisung
- `tools/ref-topology.md` — Diagram topologi TekraNet
