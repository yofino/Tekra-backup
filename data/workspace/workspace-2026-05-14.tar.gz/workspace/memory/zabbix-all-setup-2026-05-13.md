# Zabbix Monitoring — All-in-One Setup

**Dibuat:** 13 Mei 2026  
**Tujuan:** Semua infrastruktur TekraNet termonitor di Zabbix — tinggal buka dashboard, keliatan semua status.

## Daftar Host Zabbix

### MikroTik (SNMP)
| Host | IP | ID | ROS | Board |
|---|---|---|---|---|
| CCR1 | 10.10.10.1 | 10675 | - | Hotspot |
| CCR2 | 10.10.10.x | 10674 | - | PPPoE cadangan |
| DAGO | 10.6.0.2 | 10676 | 6.48.6 | CCR1009 |
| CILISUNG | 10.7.0.8 | 10677 | 7.16.1 | RB4011iGS+ |
| KATAPANG | 10.7.0.9 | 10678 | 7.19.4 | RB450Gx4 |

### pfSense
| Host | IP | ID |
|---|---|---|
| pfSense Pusat | 192.168.123.1 | 10681 |
| pfSense Gateway | - | 10682 |

### OLT
| Host | IP | ID | Model | Monitor |
|---|---|---|---|---|
| OLT EPON Pusat | 10.10.10.203 | 10713 | HSGQ-E04 | SNMP + ONU count (trapper) |
| OLT GPON Pusat | 10.10.10.204 | 10714 | HSGQ-G008ID | SNMP + ONU count (trapper) |

### Server & VPS
| Host | IP | ID | Monitor |
|---|---|---|---|
| VPS Nocita | 103.129.148.97 | 10715 | Ping + HTTPS:443 + aaPanel:888 + SSH:22 |
| VPS TekraApp | 103.197.191.8 | 10716 | Ping + HTTPS:443 + aaPanel:30521 + SSH:22 |
| Proxmox Pusat | 10.10.10.4 | 10717 | Ping + Web:8006 + SSH:22 |
| Proxmox AI | 10.10.10.29 | 10718 | Ping + Web:8006 + SSH:22 |
| Zara VM | 10.10.10.30 | 10719 | Ping + SSH:22 + Gateway:18789 |
| Anatasya VM | 10.10.10.31 | 10720 | Ping + SSH:22 + Gateway:18789 |

### Lainnya
- ISP-CORE (10694)
- Content monitoring: Facebook, Instagram, WhatsApp, Google, YouTube, TikTok, Shopee, dll
- Power: UPS-NUT-LOCAL, PZEM-Gardu-A

## ONU Monitoring (khusus)
- Script: `/opt/tekra-backup/olt_onu_monitor.py`
- Cron: tiap 5 menit (with lock file)
- Data live: Zabbix (online/offline/total/capacity per PON)
- Offline detail: `/opt/tekra-backup/data/olt_onu_offline.json` (include portal match)
- Kalau ditanya ONU offline → baca JSON file langsung

## Cara Cepat Cek Status
Tinggal buka Zabbix → dashboard, atau bilang:
- "sep cek OLT" → liat Zabbix host 10713/10714
- "sep ONU offline apa aja" → baca `/opt/tekra-backup/data/olt_onu_offline.json`
- "sep cek server" → liat Zabbix host 10715-10720
- "sep cek mikrotik cil" → liat Zabbix host 10677

## Related Files
- `memory/olt-monitoring-setup-2026-05-13.md`
- `tools/ref-pusat.md`, `ref-dago.md`, `ref-cilisung.md`, `ref-katapang.md`
- `tools/ref-topology.md`
