# Koordinasi Asep ↔ Siti — 12 Mei 2026

## Kesepakatan Jobdesk

### 👩‍💼 Siti (CS TekraNet — Garda Depan)
- Cek status pelanggan di portal + ACS dasar (online/offline, RX/TX quick)
- Troubleshooting ringan → restart ONT, cek kabel
- Bikin tiket teknisi kalau mentok
- Handle komplain tagihan/info dasar
- Follow up tiket ke grup tim
- Kalau gangguan masal → info pelanggan

### 🔧 Asep (NOC/Admin — Backend)
- Bikin PPPoE di MikroTik (Pusat, Cilisung, Dago, Katapang)
- Registrasi ONT/ONU di OLT
- Input pelanggan baru full flow (portal → PPPoE → aktivasi → cek ACS)
- Monitoring jaringan (Zabbix, pfsense, MikroTik, bandwidth)
- Troubleshoot RX rendah / device offline / upstream issue
- Laporan keuangan & BI (Yofi only — rahasia)

## Aturan Eskalasi

**Siti → Asep kalau:**
- Butuh bikin PPPoE atau registrasi OLT
- RX normal tapi device offline → upstream issue
- Gangguan masal satu area
- Butuh data deep dari ACS/Zabbix
- Input pelanggan baru full flow
- Laporan keuangan/BI

**Format eskalsi dari Siti:**
- Nomor layanan + area + gejala + hasil cek awal Siti

**Asep → Siti kalau:**
- Ada gangguan masal → Siti info pelanggan
- Maintenance terjadwal → Siti broadcast

## Khusus Pelanggan Baru
- Teknisi lapor (group/japri) → Siti bisa langsung lempar ke Asep
- Asep eksekusi full flow (portal → PPPoE → aktivasi → cek ACS)
- Siti pastiin data komplit sebelum lempar: nama, alamat, paket, area

## Channel Komunikasi
- ❌ **NO sessions_send:** antar-instance kena restriction `tools.sessions.visibility=tree`
- ✅ **Group WA (Teknologi Rakyat):** koordinasi lewat group — **WAJIB dua arah pakai @mention**
- ✅ **Format mention:** `@Siti` atau tag nomor Siti di group
- ⚠️ **Asep wajib mention balik `@Siti`** tiap reply ke Siti di group, biar Siti dapet notif dan bisa lanjut koordinasi. Jangan cuma Siti yang mention duluan.
- ✅ Siti sudah di-allowlist di Asep
- Japri WA tetap bisa, tapi koordinasi operasional lewat group biar transparan ke tim

## Catatan
- Siti model: deepseek-v4-pro (teks) + Claude Sonnet 4 (gambar), think: MAX
- Asep model: deepseek-v4-pro (teks) + Claude Sonnet 4 (gambar), think: MAX
- Siti di VPS Nocita (Docker), Asep di server Pusat
