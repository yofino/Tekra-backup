# POP Katapang - Reference

## Ringkasan
- **PIC:** Ahkam (+6287722867602)
- **Portal:** southnet.my.id
- **ISP:** Primacom (PBR only), MyRep (250M)
- **Total Kapasitas:** 350M | **LB Aktif:** 250M

## MikroTik Katapang
- **IP:** 10.7.0.9
- **SSH:** asep / asep$888 port 18
- **Route:** failover recursive → MyRep (d=1) → Primacom (d=2)

## Catatan Operasional
- Paket pelanggan baru Katapang → samakan rule/profil dengan Pusat
- Portal Katapang: southnet.my.id

## TODO
- [ ] Dokumentasi OLT Katapang
- [ ] Dokumentasi perangkat lain
