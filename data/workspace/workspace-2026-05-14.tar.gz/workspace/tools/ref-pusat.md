# POP Pusat - Reference

## Ringkasan
- **Portal:** portal.tekra.id
- **ISP:** Simaya (PBR), MyRep ×3 (250M), Sunmory ×2 (250M), Cilisung via VLAN (600M), Indibiz (300M)
- **Total Kapasitas:** 2.250M | **LB Aktif:** 2.150M

## MikroTik Pusat (x86/CCR2116-12G-4S+)
- **IP:** 172.80.10.100 (PPPoE server Pusat)
- **SSH:** asep / asep$888 port 18
- **API:** keanu / asep$888 port 8728
- **RouterOS:** 7.11.3 (stable)
- **CPU:** ARM64 16-core, load ~17%
- **RAM:** 16GB
- **Board:** CCR2116-12G-4S+

### Interface Utama
| Interface | Fungsi |
|---|---|
| SFP1-WAN-1 | Uplink utama |
| SFP3-OLT-GPON | OLT GPON |
| SFP4-OLT-EPON | OLT EPON |
| ether1-SIMAYA | Simaya PBR |
| ether2-SWITCH | Switch lokal |
| ether10 | OLT / LAN |
| ether11 | OLT / LAN |

### Bridge
| Bridge | Fungsi |
|---|---|
| BRIDGE-BACKBONE-CILISUNG | Backhaul VLAN ke Cilisung |
| BRIDGE-HOTSPOT | Hotspot CCR1 |
| BRIDGE-HOTSPOT-GX4 | Hotspot GX4 |
| BRIDGE-TR069 | TR-069 ACS |

### VLAN PPPoE
| VLAN | Area |
|---|---|
| vlan3 | BOJONG SEUREUH |
| vlan4 | BOJONG SUREN |
| vlan5 | BOJONG SUREN GIRANG |
| vlan7 | SUKALUYU |
| vlan8 | CIBURUY |
| vlan9 | PPPoE GPON |

### Tunnel
| Tunnel | Type | Connect To | Note |
|---|---|---|---|
| tunnel-31729 | OVPN client | id-24.tunnel.web.id:1194 | OVPN cloud (sering bermasalah) |

### VLAN Backhaul Cilisung
- VLAN-FROM-CILISUNG (vlan41)
- VLAN-TO-CILISUNG (vlan40)
- Bridge: BRIDGE-BACKBONE-CILISUNG

## pfSense Pusat
- **URL:** https://192.168.123.1
- **Login:** admin / k34Nu335577

### WAN
| WAN | Gateway |
|---|---|
| WAN1 | 192.168.50.1 |
| WAN2 | 192.168.60.1 |
| WAN3 | 192.168.70.1 |
| WAN4 | 192.168.80.1 |
| WAN5 | 192.168.90.1 |
| WAN6 | 192.168.124.1 (Cilisung) |
| WAN7 | 192.168.110.1 |

## OLT EPON Pusat
- **IP:** 10.10.10.203
- **Akses:** Telnet port 23
- **Login:** root / admin
- **PON:** 4 port × 64 ONU = 256 max

## OLT GPON Pusat
- **IP:** 10.10.10.204
- **Login:** admin / k34Nu335577

## ACS (TR-069)
- **UI:** http://acs.tekra.id / http://10.10.10.230:3000
- **API:** http://10.10.10.230:7557
- **Auth:** admin / admin

## Zabbix Monitoring
- **URL:** http://10.10.10.18/zabbix
- **API:** http://10.10.10.18/zabbix/api_jsonrpc.php
- **Login:** Admin / zabbix
- **Grafana:** http://10.10.10.18:3000

## Proxmox VE
- **IP:** 10.10.10.4
- **SSH:** root / k34Nu335577
- **Web:** https://10.10.10.4:8006
- VM 118 (Monitoring, 4GB), CT103 (LXC, 2GB)

## Server Lain di Pusat
| Perangkat | IP |
|---|---|
| OpenClaw (Asep) | 10.10.10.18 |
| NVR Dahua | 10.10.10.10 |
| Hikvision Access Control | 10.10.10.207 |

## MikroTik CCR1 (Hotspot)
- **IP:** 10.10.10.1
- **Fungsi:** Hotspot server

## MikroTik CCR2 (PPPoE - Cadangan)
- **Fungsi:** PPPoE cadangan
