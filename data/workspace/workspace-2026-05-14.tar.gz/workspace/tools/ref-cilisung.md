# POP Cilisung - Reference

## Akses
- Backhaul VLAN dari Pusat (VLAN 40/41)
- Gak perlu tunnel OVPN untuk akses

## MikroTik Cilisung (GX4)
- **IP:** 10.7.0.8
- **SSH:** asep / asep$888 port 18

## pfSense Cilisung
- **IP:** 192.168.124.1
- **Web UI:** https://192.168.124.1
- **Login:** admin / k34Nu335577 (asumsi sama dengan pfSense lain)
- **Catatan:** Terhubung via VLAN backhaul, bisa diakses langsung dari server Pusat

## OLT EPON Cilisung
- **IP:** 192.168.101.10 (VLAN 144)
- **Model:** HSGQ-E04ID
- **Software:** HSGQ-E04ID_IR_V3.5.3 (2024-10-29)
- **Hardware:** V3.0
- **Serial:** 202412180106
- **Akses:** Telnet port 23
- **Login:** root / admin
- **CLI:** Cisco-like (enable → configure mode)

### Management IPs
| Interface | IP |
|---|---|
| Management | 192.168.100.1/24 |
| VLAN 1 | 192.168.99.1/24, sub 192.168.124.2/24 |
| VLAN 144 | 192.168.101.10/24 |
| Gateway | 192.168.101.1 |

### VLAN Tagging
- VLAN 100, 143-145 tagged di semua port (EPON 1-4 + GE 1-8)

### PON Ports
- **PON 1:** 52 ONU terdaftar (semua tipe 1ge3fe)
- **PON 2-4:** Belum ada ONU

### Perintah Penting
```
# Login & enable
root / admin
enable

# Lihat info
show version
show startup-config

# Konfigurasi
configure
interface epon 1-4
```
