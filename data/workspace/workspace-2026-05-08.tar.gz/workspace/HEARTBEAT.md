# HEARTBEAT.md

## Cek Model Aktif
Setiap heartbeat, panggil `session_status` dan cek model yang sedang aktif.
- Model primary sekarang **DeepSeek V4 Pro** (bukan GPT-5.4). Jangan spam Yofi soal ini — dia yang minta ganti.
- Kalau fallback dari DeepSeek ke GPT atau Claude baru notif.
- Jangan spam: kalau sudah pernah notif fallback di session yang sama, skip (cukup sekali per transisi).
