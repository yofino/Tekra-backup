# HEARTBEAT.md

## Cek Model Aktif
Setiap heartbeat, panggil `session_status` dan cek model yang sedang aktif.
- Kalau model **bukan** `deepseek/deepseek-v4-pro` (misal sudah fallback ke model lain), kirim notif WhatsApp ke Yofi (+6282115448084) dengan pesan singkat: model DeepSeek V4 Pro sudah limit, sekarang pakai [nama model aktif].
- Kalau masih DeepSeek V4 Pro, tidak perlu notif — lanjut HEARTBEAT_OK.
- Jangan spam: kalau sudah pernah notif fallback di session yang sama, skip (cukup sekali per transisi).

## PR / Todo List
- [ ] Inventarisir perangkat per POP (MikroTik, OLT, switch, modem, UPS, dll)
- [ ] OLT Monitoring per POP (EPON Pusat, GPON Pusat, Cilisung, Dago)
- [ ] pfSense Katapang — jika ada
- [ ] Alert Zabbix → WhatsApp
- [ ] Google Postmaster Tools untuk mail.tekra.id

## 🤖 AI Trading Bot Monitor
- Pantau AI bot di Windows VPS: SSH ke 103.187.147.126 (Administrator / As3pGanteng123!)
- Cek log AI tiap heartbeat: `type C:\TradingBot\bot_ai.log | findstr /C:"AI" | tail -3`
- Kalau bot mati → restart via `schtasks /Run /TN TradingBot`
- Kalau >30 menit gak ada sinyal baru → notif ke Yofi
- Kalau RAM >85% → warning ke Yofi
- Bot harusnya logging setiap menit
