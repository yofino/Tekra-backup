# MEMORY.md — Long-term Memory

## AI Trading Bot (XAUUSD)
- **Started:** 25 Mei 2026
- **Windows VPS:** 103.187.147.126 | Administrator / As3pGanteng123! | SSH port 22
- **Broker:** Exness demo — login 433666770, server Exness-MT5Trial7
- **Symbol:** XAUUSDm (perhatikan "m" di belakang!)
- **Bot:** C:\TradingBot\bot_v2.py — loop per menit, deteksi MA cross + RSI + MACD
- **Data:** CSV tersimpan di C:\TradingBot\data\ untuk training XGBoost nanti
- **Status:** AI LIVE sejak 27 Mei 2026 14:52 — bot_v3_ai.py dengan XGBoost V2
- **Accuracy:** 59.7% (vs 41% manual) | Backtest: +13.4% profit | Win rate backtest: 39.7%
- **Dashboard:** http://103.187.147.126:8501 | Login: yofi/tekra2026, client/tekraXAU
- **Risk:** 0.5%/trade, SL 1.5x ATR, TP 3.0x ATR (R:R 2:1)
- **RAM:** 4GB (upgraded from 2GB — perlu minimal 4GB)
- **Repo code di workspace:** /root/.openclaw/workspace/trading_bot/
