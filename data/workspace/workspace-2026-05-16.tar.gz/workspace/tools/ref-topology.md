# Topologi Infrastruktur TekraNet

```
                                    ┌─────────────────────┐
                                    │    CLOUD / VPS       │
                                    ├─────────────────────┤
                                    │ Nocita (103.129.148) │
                                    │ • Portal ERP/Billing │
                                    │ • Siti (AI CS Agent) │
                                    │ • aaPanel / Webmail  │
                                    │ • Mail Server        │
                                    ├─────────────────────┤
                                    │ TekraApp (103.197)   │
                                    │ • aaPanel / Apps     │
                                    └──────────┬──────────┘
                                               │
            ════════════════════════════════════╪════════════════════════════════════
                                               │
┌──────────────────────────────────────────────┴──────────────────────────────────────────────┐
│                                      POP PUSAT (HQ)                                         │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│  │                              ISP / WAN (Total: 2.250M)                               │   │
│  ├─────────────────────────────────────────────────────────────────────────────────────┤   │
│  │ Simaya (PBR)  │  MyRep ×3 (250M)  │  Sunmory ×2 (250M)  │  Indibiz (300M)           │   │
│  └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                          │                                                  │
│  ┌───────────────────────────────────────┴──────────────────────────────────────────────┐   │
│  │                        pfSense Pusat (192.168.123.1)                                 │   │
│  │                  WAN1 .50 │ WAN2 .60 │ WAN3 .70 │ WAN4 .80 │ WAN5 .90 │ WAN7 .110   │   │
│  │                                                   WAN6 .124 ←── VLAN Cilisung 600M   │   │
│  └───────────────────────────────────────┬──────────────────────────────────────────────┘   │
│                                          │                                                  │
│  ┌───────────────────────────────────────┴──────────────────────────────────────────────┐   │
│  │                      MikroTik x86 Pusat (CCR2116-12G-4S+)                           │   │
│  │                        IP: 172.80.10.100  |  ROS 7.11.3                              │   │
│  │                        PPPoE Server  |  DHCP  |  VLAN Backbone                       │   │
│  └───┬──────────┬──────────┬──────────┬──────────┬──────────┬──────────┬───────────────┘   │
│      │          │          │          │          │          │          │                    │
│  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──────────┐          │
│  │CCR1  │  │CCR2  │  │OLT   │  │OLT   │  │ACS   │  │Zabbix│  │Server Room    │          │
│  │Hotsp │  │PPPoE │  │EPON  │  │GPON  │  │TR069 │  │Monit │  │Proxmox,NVR,.. │          │
│  │.10.1 │  │(cad.)│  │.10. │  │.10.  │  │.10.  │  │.10.18│  │.10.4,.10,.207│          │
│  └──────┘  └──────┘  │203   │  │204   │  │230   │  └──────┘  └───────────────┘          │
│                       └──────┘  └──────┘  └──────┘                                        │
│                                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│  │                           VLAN PPPoE Area                                            │   │
│  ├─────────────────────────────────────────────────────────────────────────────────────┤   │
│  │ vlan3 Bojong Seureuh │ vlan4 Bojong Suren │ vlan5 Bojong Suren Girang               │   │
│  │ vlan7 Sukaluyu       │ vlan8 Ciburuy      │ vlan9 PPPoE GPON                        │   │
│  └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
          │                         │                         │
          │ VLAN (40/41)            │ OVPN                    │ Tunnel
          │ 600M Backhaul           │                         │
          ▼                         ▼                         ▼
┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐
│   POP CILISUNG      │  │     POP DAGO        │  │   POP KATAPANG      │
├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤
│ ISP: MyRep (250M)   │  │ ISP: Simaya (PBR)   │  │ ISP: MyRep (250M)   │
│      MyRep (500M)   │  │      MyRep ×3 (250) │  │      Primacom (PBR) │
│ Total: 750M         │  │      Sunmory (300)  │  │ Total: 350M         │
│ LB Aktif: 600M→Pusat│  │ Total: 1.150M       │  │ LB Aktif: 250M      │
│                     │  │ LB Aktif: 1.050M    │  │                     │
│ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │ ┌─────────────────┐ │
│ │ GX4 (10.7.0.8)  │ │  │ │CCR1009(10.6.0.2)│ │  │ │RB450Gx4(10.7.0.9│ │
│ │ RB4011iGS+      │ │  │ │ROS 6.48.6 CPU82%│ │  │ │ROS 7.19 CPU 55% │ │
│ │ ROS 7.16 CPU 40%│ │  │ │PPPoE + Hotspot  │ │  │ │PPPoE            │ │
│ └─────────────────┘ │  │ └─────────────────┘ │  │ └─────────────────┘ │
│                     │  │                     │  │                     │
│ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │                     │
│ │pfSense(192.168.  │ │  │ │pfSense(115.178. │ │  │                     │
│ │124.1)            │ │  │ │49.186:1042)     │ │  │                     │
│ │WAN6 backhaul     │ │  │ │WAN1-4 41-44.1   │ │  │                     │
│ │                  │ │  │ │Celeron J1900     │ │  │                     │
│ └─────────────────┘ │  │ └─────────────────┘ │  │                     │
│                     │  │                     │  │                     │
│ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │                     │
│ │OLT HSGQ-E04ID   │ │  │ │OLT HSGQ (ether5)│ │  │                     │
│ │(192.168.101.10) │ │  │ │OLT HIOSO(ether6)│ │  │                     │
│ │EPON 52 ONU(PON1)│ │  │ │                  │ │  │                     │
│ └─────────────────┘ │  │ └─────────────────┘ │  │                     │
└─────────────────────┘  └─────────────────────┘  └─────────────────────┘
```

## Ringkasan Per POP

| POP | MikroTik | pfSense | OLT | ISP |
|---|---|---|---|---|
| **PUSAT** | CCR2116 (172.80.10.100) | 192.168.123.1 | EPON (.203) + GPON (.204) | Simaya, MyRep×3, Sunmory×2, Indibiz |
| **CILISUNG** | RB4011 (10.7.0.8) | 192.168.124.1 | HSGQ-E04ID (.101.10) | MyRep ×2 |
| **DAGO** | CCR1009 (10.6.0.2) | 115.178.49.186:1042 | HSGQ + HIOSO | Simaya, MyRep×3, Sunmory |
| **KATAPANG** | RB450Gx4 (10.7.0.9) | — | — | MyRep, Primacom |

## Konektivitas Antar POP
- **Pusat ↔ Cilisung:** VLAN Backhaul (40/41, 600M) + OVPN backup
- **Pusat ↔ Dago:** OVPN ethernet via pfSense + OVPN cloud
- **Pusat ↔ Katapang:** Tunnel (detail perlu dicek)

## Server & Infrastruktur
| Server | IP | Fungsi |
|---|---|---|
| Zabbix + Grafana | 10.10.10.18 | Monitoring (grafana:3000, zabbix:3000) |
| ACS GenieACS | 10.10.10.230 | TR-069 ONT Management |
| Proxmox VE | 10.10.10.4 | Virtualisasi |
| NVR Dahua | 10.10.10.10 | CCTV |
| Hikvision | 10.10.10.207 | Access Control |
| OpenClaw Asep | 10.10.10.18 | AI NOC Agent |
| VPS Nocita | 103.129.148.97 | Portal + Mail + Siti AI |
| VPS TekraApp | 103.197.191.8 | Apps |

## Monitoring (Zabbix + Grafana)
- **Grafana**: http://10.10.10.18:3000 (admin / admin123)
- **Dashboard WAN**: http://10.10.10.18:3000/d/24a45def (42 panels)
- **Zabbix**: http://10.10.10.18:3000 (Admin / k34Nu335577 — blocked sementara)
- **Gateway script**: `/opt/scripts/pf_gateway.sh` (HTTPS scrape)
- **SNMP proxy**: `/opt/scripts/pf_dago_snmp.sh`, `/opt/scripts/pf_cilisung_snmp.sh`

## DNS Cache (updated 14 Mei 2026)
- cache-max-ttl: 1d | cache-size: 4096KB
- Berlaku di: PUSAT X86, CCR1, CILISUNG, KATAPANG, DAGO
- Baseline PUSAT X86: 16.6K records, 83% kapasitas
- Threshold upgrade: >85% → 8192KB

## Portal Billing
| Area | URL |
|---|---|
| Pusat | portal.tekra.id |
| Dago | north.my.id |
| Katapang | southnet.my.id |

## Total Kapasitas ISP
- **Beli:** ~4.500 Mbps
- **LB Aktif:** ~3.450 Mbps
