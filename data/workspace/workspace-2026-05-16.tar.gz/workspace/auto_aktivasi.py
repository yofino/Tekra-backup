#!/usr/bin/env python3
"""
TekraNet Auto Activation v3.0
Flow: Generate clean no → PPPoE via portal API → Aktivasi → Report
"""

import requests, re, sys, argparse
from datetime import datetime
import urllib3; urllib3.disable_warnings()

PORTAL = "https://portal.tekra.id"
AUTH = {"email": "asep@tekra.id", "password": "12345"}
COV_ROUTER = {'1': 2, '2': 1, '3': 3, '4': 4}
PROFILES = {
    '119000':'PAKET HEMAT','150000':'PAKET1','165000':'PAKET3',
    '159000':'PAKET MANTAP','199000':'PAKET PUAS','200000':'PAKET2',
    '275000':'PAKET PUAS','300000':'PAKET3',
}

def log(msg): print(f"  {msg}", file=sys.stderr)

def parse_name(text):
    m = re.search(r'(?:aktifasi|aktivasi|aktipasi)\s+([A-Za-z0-9\s]+)', text, re.I)
    return m.group(1).strip() if m else None

def generate_no(): 
    n = datetime.now()
    return f"{n.year%100:02d}{n.month:02d}{n.day:02d}{n.hour:02d}{n.minute:02d}{n.second:02d}"

def activate(nama_or_no):
    s = requests.Session()
    today = datetime.now().strftime("%Y-%m-%d")
    due_day = str(datetime.now().day)
    
    # 1. Login
    r = s.post(f"{PORTAL}/auth", data=AUTH, verify=False, timeout=15)
    if r.status_code != 200: return {"success": False, "error": "Login gagal"}
    log("Login OK")
    
    # 2. Find Menunggu customer
    r = s.post(f"{PORTAL}/customer/getfiltercoverage/", data={'search': nama_or_no}, verify=False, timeout=10)
    cust = None
    for row in r.json().get('data', []):
        if (nama_or_no.upper() in row[2].upper() or nama_or_no.replace('R-','') in row[3]) and 'Menunggu' in row[7]:
            cust = {'id': row[0], 'name': row[2]}; break
    if not cust: return {"success": False, "error": f"'{nama_or_no}' tidak ditemukan / bukan Menunggu"}
    log(f"Found: {cust['name']} (ID={cust['id']})")
    
    # 3. Get detail
    r = s.post(f"{PORTAL}/customer/getdata", data={'draw':'1','start':'0','length':'5','search[value]': cust['name']}, verify=False, timeout=10)
    detail = next((row for row in r.json().get('data',[]) if row['name'] == cust['name']), None)
    if not detail: return {"success": False, "error": "Gagal ambil detail"}
    
    coverage = str(detail.get('coverage','1'))
    amount = str(detail.get('amount','165000'))
    cid = detail.get('id')
    rid = COV_ROUTER.get(coverage, 2)
    profile = PROFILES.get(amount, 'PAKET1')
    clean_no = generate_no()
    nama_depan = cust['name'].strip().upper().split()[0]
    username = f"{clean_no}-{nama_depan}"
    log(f"Gen: {clean_no} | R{rid} | {profile} | {username}")
    
    # 4. Create PPPoE on MikroTik via portal
    pppoe_synced = False
    try:
        r = s.post(f"{PORTAL}/mikrotik/createuser",
                   data={'router':str(rid),'mode':'PPPOE','username':username,
                         'password':username,'profile':profile,'customer_id':str(cid)},
                   verify=False, timeout=30)
        if 'success' in r.text and 'error' not in r.text.lower():
            pppoe_synced = True; log("PPPoE synced to MikroTik ✅")
        else: log(f"PPPoE: {r.text[:120]}")
    except Exception as e: log(f"PPPoE timeout: router unreachable")
    
    # 5. Get edit form (CSRF)
    r = s.get(f"{PORTAL}/customer/edit/{cid}", verify=False, timeout=10)
    hiddens = dict(re.findall(r'<input[^>]*type="hidden"[^>]*name="([^"]+)"[^>]*value="([^"]*)"', r.text))
    
    # 6. Update customer: clean no + aktivasi + jatuh tempo
    form = {
        **hiddens,
        'id': str(cid), 'customer_id': str(cid),
        'name': cust['name'], 'no_services': clean_no,
        'no_wa': detail.get('phone','6281234567890'),
        'email': detail.get('email', f"{cust['name'].lower().replace(' ','')}@tekra.id"),
        'phonecode': str(detail.get('phonecode','62')),
        'no_ktp': detail.get('no_id_card','1234567890123456'),
        'address': detail.get('address',''),
        'coverage': coverage,
        'status': 'Aktif', 'ganti_koneksi': '1',
        'mode_user': 'PPPOE', 'router': str(rid),
        'user_mikrotik': username, 'profile': profile, 'user_profile': profile,
        'register_date': today, 'mediaconnection': today,
        'due_date': due_day,
        'type_payment': '0', 'ppn': '0', 'auto_isolir': '1', 'send_bill': '0',
        'month_due_date': '0', 'dynamic_due_date': '0', 'codeunique': '0',
        'type_id': detail.get('id_card','KTP'), 'connection': '0', 'create_by': '1051',
    }
    r = s.post(f"{PORTAL}/customer/edit/{cid}", data=form, verify=False, timeout=10, allow_redirects=True)
    
    # 7. Verify
    r = s.post(f"{PORTAL}/customer/getdata", data={'draw':'1','start':'0','length':'5','search[value]': cust['name']}, verify=False, timeout=10)
    final = next((row for row in r.json().get('data',[]) if row['name'] == cust['name']), {})
    ok = final.get('status') == 'Aktif' and 'R-' not in final.get('no_services','R-')
    log(f"Status: {final.get('status')} | No: {final.get('no_services')} | {'✅' if ok else 'REVIEW'}")
    
    return {
        "success": ok, "nama": cust['name'], "no_services": clean_no,
        "pppoe_username": username, "pppoe_password": username,
        "pppoe_synced": pppoe_synced, "profile": profile,
    }

def report(r):
    if not r.get('success'): return f"❌ AKTIVASI GAGAL — {r.get('error','')}"
    sync = "✅" if r.get('pppoe_synced') else "⚠️ Perlu sync manual"
    return (f"✅ AKTIVASI BERHASIL\n"
            f"📋 {r['nama']}\n"
            f"🔢 {r['no_services']}\n"
            f"🔌 PPPoE: {r['pppoe_username']} {sync}\n"
            f"🔑 Pass: {r['pppoe_password']}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--nama"); p.add_argument("--raw")
    a = p.parse_args()
    nama = a.nama or (parse_name(a.raw) if a.raw else None)
    if not nama: print("Usage: --nama <NAMA>"); sys.exit(1)
    print(report(activate(nama)))
