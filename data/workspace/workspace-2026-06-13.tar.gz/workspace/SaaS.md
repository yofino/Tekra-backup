# SaaS Applications — Yofi's Portfolio
# ⚠️ PRIVATE — DO NOT COMMIT TO GITHUB

## Published on taskora.id

### Website & Sistem Manajemen Salon
- URL: salon.taskora.id
- Admin: owner@example.com / password

### Aplikasi Pinjaman Online
- URL: pinjaman.taskora.id
- Admin: admin@taskora.id / superadmin

### Aplikasi PPOB Taskora
- URL: ppob.taskora.id
- Admin: admin@taskora.id / superadmin
- Demo: demoakun@taskora.id / demoakun

### Aplikasi Bank & Koperasi
- URL: bank.taskora.id
- Admin: admin@taskora.id / superadmin

### Aplikasi ERP Taskora
- URL: app.taskora.id
- Admin: admin@taskora.id / superadmin

### Aplikasi Manajemen Kost Saas - KostManager
- URL: kost.taskora.id
- Admin: admin@taskora.id / superadmin

### Toko Online Taskora PHP Native
- URL: toko.taskora.id
- Admin: admin@taskora.id / superadmin

### Toko Online Taskora React + Laravel
- URL: toko2.taskora.id
- Admin: admin@taskora.id / superadmin

### Restaurant POS & Management System (Single)
- URL: resto.taskora.id
- Admin: owner / password

### Saas - Restaurant POS & Management System
- URL: saasresto.taskora.id
- Admin: superadmin / superadmin | owner / password
- APK: https://drive.google.com/file/d/1kiqMK3w_otgW2j8WS5yNitcPbaWJXcGY/view

## Unpublished / Private

### GiziNow Management MBG
- URL: gizinow.com
- Admin: admin@gizinow.com / superadmin
- Dapur: denny@gizinow.com / demodapur

### Koperasi Syariah (Demo)
- URL: demokoperasi.taskora.id
- Admin: admin / superadmin

### Film Taskora
- URL: film.taskora.id
- Admin: admin@taskora.id / superadmin

### Bayar Taskora
- URL: bayar.taskora.id

### Nusa Emas Store
- URL: nusaemas.store
- Admin: admin@nusaemas.com / password

### Aplikasi RT RW Net
- (web)

### Kopiroda
- URL: kopiroda.id

### Aplikasi Cek Mutasi
- Admin: admin@taskora.id / superadmin

## Notes
- Taskora ID main site: taskora.id
- Most apps use: admin@taskora.id / superadmin
- Tech stack: PHP Native, Laravel, React, MySQL
