#!/bin/bash
# Monitor AI Agents - Zara (Pak Jemmy) & Anatasya (Pak Ryan)
# Proxmox: 10.10.10.29, VMs: 10.10.10.30 (Zara), 10.10.10.31 (Anatasya)

PROXMOX="10.10.10.29"
ZARA_IP="10.10.10.30"
ANATASYA_IP="10.10.10.31"
PASS="zeushera"
REPORT=""

check_vm() {
    local NAME="$1"
    local IP="$2"
    local USER="$3"
    
    # Check SSH & uptime
    UP=$(sshpass -p "$PASS" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$IP" "uptime -p" 2>/dev/null)
    if [ $? -ne 0 ]; then
        REPORT="${REPORT}🔴 ${NAME} (${IP}): SSH GAGAL\n"
        return 1
    fi
    
    # OpenClaw status
    OC=$(sshpass -p "$PASS" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$IP" "openclaw status 2>/dev/null | head -20" 2>/dev/null)
    if echo "$OC" | grep -q "not running\|error\|failed"; then
        REPORT="${REPORT}🔴 ${NAME} (${IP}): OpenClaw DOWN\n"
        return 1
    fi
    
    # RAM
    RAM=$(sshpass -p "$PASS" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$IP" "free -h | grep Mem | awk '{print \$3\"/\"\$2}'" 2>/dev/null)
    
    # Disk
    DISK=$(sshpass -p "$PASS" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$IP" "df -h / | tail -1 | awk '{print \$3\"/\"\$2\" (\"\$5\")\"}'" 2>/dev/null)
    
    REPORT="${REPORT}🟢 ${NAME} (${IP}): UP ${UP} | RAM ${RAM} | Disk ${DISK}\n"
}

check_vm "Zara" "$ZARA_IP" "agent-bos"
check_vm "Anatasya" "$ANATASYA_IP" "agent-ryan"

echo -e "$REPORT"
