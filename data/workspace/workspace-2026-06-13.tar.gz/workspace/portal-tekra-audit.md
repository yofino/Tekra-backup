# Portal Tekra — Full Audit Reference

> **Untuk rebuild ulang pakai vibe coding / Claude Code**
> Audit: 1 Juni 2026 oleh Ujang
> **Codebase SAMA untuk 3 domain**: portal.tekra.id, north.my.id, southnet.my.id

---

## 🏗️ Tech Stack

| Layer | Teknologi |
|-------|-----------|
| **Framework** | CodeIgniter 3 (PHP 7.4+) |
| **Database** | MySQL / MariaDB |
| **Frontend** | SB Admin 2 (Bootstrap 4), DataTables, jQuery, Leaflet.js, Select2 |
| **Server** | Nginx, aaPanel |
| **Libraries** | PHPExcel, DomPDF, QR Code, REST Server |
| **Hosting** | VPS Nocita 103.129.148.97 |

---

## 📂 Struktur Folder

```
portal.tekra.id/
├── application/
│   ├── config/          # database.php, routes.php, rest.php, autoload.php
│   ├── controllers/     # 80+ controller
│   │   └── api/         # REST API controllers (Auth, Bill, Customer, Coverage, Income, Package, Router, Key)
│   ├── models/          # 36 model (CI3 Query Builder)
│   ├── views/
│   │   ├── backend/     # Admin panel views
│   │   │   ├── auth/        # Login
│   │   │   ├── bill/        # Tagihan
│   │   │   ├── customer/    # Pelanggan (+ services/)
│   │   │   ├── coverage/    # Area
│   │   │   ├── dashboard/   # Dashboard (+ mikrotik/)
│   │   │   ├── expenditure/ # Pengeluaran
│   │   │   ├── finance/     # Keuangan (+ income/, commission/)
│   │   │   ├── genieacs/    # TR-069 ACS
│   │   │   ├── help/        # Tiket
│   │   │   ├── income/      # Pemasukan
│   │   │   ├── integration/ # Integrasi (ai/, cdata/, managerio/, ollama/, rest-api/, va/)
│   │   │   ├── mikrotik/    # MikroTik (customer/, hotspot/, ppp/, setting/)
│   │   │   ├── olt/         # OLT (+ smartolt/)
│   │   │   ├── package/     # Paket
│   │   │   ├── payment/     # Payment gateway
│   │   │   ├── sales/       # Sales
│   │   │   ├── schedule/    # Jadwal
│   │   │   ├── setting/     # Pengaturan
│   │   │   ├── user/        # User
│   │   │   ├── website/     # CMS
│   │   │   └── whatsapp/    # WhatsApp
│   │   ├── frontend/    # Website publik
│   │   ├── member/      # Halaman member/pelanggan
│   │   └── mobile/      # Mobile view
│   ├── helpers/         # db, genieacs, login, mgdb, mywifi, olt, va, update
│   ├── libraries/       # Custom libraries (+ QR Code)
│   ├── third_party/     # PHPExcel
│   ├── migrations/      # DB migrations
│   ├── language/        # english, indonesia
│   └── cache/           # Cache files (+ dompdf)
├── assets/              # CSS, JS, images
├── system/              # CI3 core
├── vendor/              # Composer deps
├── .env                 # DB credentials
└── index.php
```

---

## 🎛️ 22 Modul Admin

### 1. Dashboard
- **Controller**: Dashboard.php (47 methods, 1117 lines)
- **Fitur**: 
  - Ringkasan pelanggan (Total, Isolir, Baru Bulan Ini)
  - Grafik pelanggan baru (Chart.js)
  - MikroTik dashboard monitoring
  - 5 Tab: Customer, Finance, Help, Bill, MikroTik
  - Broadcast WhatsApp
  - Jam real-time, notifikasi

### 2. Shortcut
- **Path**: `/dashboard/shortcut`
- Menu akses cepat kustom

### 3. Package (Paket)
- **Controller**: Package.php (22 methods)
- **Model**: Package_m.php, Product_m.php
- **Fitur**: CRUD paket internet, mapping ke profil MikroTik, kategori paket
- **REST API**: `api/package`

### 4. Customer (Pelanggan)
- **Controller**: Customer.php (127 methods, 5529 lines) ← **TERBESAR**
- **Model**: Customer_m.php (73K)
- **Fitur**:
  - CRUD pelanggan (add, edit, delete, detail)
  - Filter: Coverage Area, Status, Media Koneksi, Router
  - Status: Aktif, Isolir, Menunggu, Non-Aktif
  - Generate no_services otomatis
  - Service management (PPPoE, Hotspot, Static)
  - Export Excel, Import Excel
  - Bulk actions
- **REST API**: `api/customer` (GET, POST), `api/customer/getpackage`

### 5. Sales
- **Controller**: Sales.php (16 methods)
- **Model**: Sales_m.php
- Transaksi penjualan, revenue tracking

### 6. Coverage (Area)
- **Controller**: Coverage.php (36 methods)
- **Model**: Coverage_m.php
- **Fitur**: CRUD area, kode area, ODC/ODP, koordinat peta, jangkauan
- **REST API**: `api/coverage`

### 7. Bill (Tagihan) ⭐
- **Controller**: Bill.php (134 methods, 5803 lines) ← **TERBESAR #2**
- **Model**: Bill_m.php (68K)
- **Fitur**:
  - Generate invoice otomatis (cron job)
  - Filter: Coverage, Status, Metode, Bulan/Tahun
  - Status: BELUM BAYAR, SUDAH BAYAR, TERKIRIM
  - Reminder due date (WhatsApp)
  - Payment confirmation
  - Invoice download/print (PDF)
  - Payment gateway integration
  - Rekening listrik, BPJS
- **REST API**: `api/bill` (GET, detail, unpaid, mark_as_paid)

### 8. Finance (Keuangan)
- **Controllers**: Finance.php, Income.php (41 methods), Expenditure.php (19 methods)
- **Models**: Income_m.php, Expenditure_m.php
- **Fitur**:
  - **Pemasukan**: CRUD + Report, filter by date/category/coverage
  - **Pengeluaran**: CRUD
  - Kategori pemasukan/pengeluaran
  - Report bulanan & tahunan
  - Komisi
  - Bank management
- **REST API**: `api/income`

### 9. Integration (Integrasi)
- **Controller**: Integration.php (41 methods, 2127 lines)
- **Sub-modul**:
  - Email server
  - Payment gateway (Duitku, iPaymu, Tripay, Xendit, Midtrans, Flip)
  - Maps / geolocation
  - WhatsApp API
  - Telegram Bot
  - SMS (Indosat)
  - MikroTik connection
  - OLT connection
  - GenieACS connection
  - Virtual Account (VA)
  - Manager.io
  - **AI Chat** (ollama + settings)

### 10. Help (Bantuan / Tiket)
- **Controller**: Help.php (46 methods)
- **Model**: Help_m.php
- **Fitur**:
  - CRUD tiket pelanggan
  - Status: Open, Process, Pending, Close
  - Assign teknisi
  - Timeline tiket
  - Notifikasi teknisi
- **API Endpoint**: `POST /help/serverhelp` (DataTables JSON)

### 11. Maps (Peta)
- **Controller**: Maps.php (11 methods)
- Visualisasi peta pelanggan (Leaflet.js)
- Mapping coverage geografis

### 12. Master
- **Controller**: Master.php (27 methods)
- Data referensi: vendor, metode pembayaran, tipe koneksi

### 13. Schedule (Jadwal)
- **Controller**: Schedule.php (66 methods, 3562 lines)
- **Model**: Schedule_m.php
- Penjadwalan tugas/pekerjaan teknisi
- **REST API**: `api/schedule` (GET, POST)

### 14. User (Pengguna)
- **Controller**: User.php (19 methods)
- **Model**: User_m.php
- Manajemen user admin portal

### 15. Setting (Pengaturan)
- **Controller**: Setting.php (38 methods)
- **Model**: Setting_m.php
- Konfigurasi sistem, tema, logo, nama

### 16. Role Management
- **Controller**: Role.php (23 methods)
- Role & permission (role_management, role_menu tables)

### 17. Website (CMS)
- **Controller**: Website.php
- Kelola konten website publik
- Slide, halaman, artikel

### 18. Logs
- **Controller**: Logs.php (10 methods)
- Activity log, audit trail

### 19. Version
- **Path**: `/about/changelog`
- Changelog sistem

### 20. Licence
- Info lisensi

### 21. REST-API
- Dokumentasi API endpoint
- API key management

### 22. Broadcast WhatsApp
- Kirim broadcast ke pelanggan via WhatsApp

---

## 🔌 Integrasi Eksternal

### MikroTik
- **Controller**: Mikrotik.php (63 methods)
- **Koneksi**: SSH + API (port 8728)
- **Fitur**:
  - PPPoE: user management, active sessions, enable/disable, reset
  - Hotspot: user, active, profile, binding, host
  - Traffic monitoring (per interface, per client)
  - Profile management (sync DB ↔ MikroTik)
  - Backup config
  - Dashboard per router
  - Isolir / open isolir
  - Standalone management

### OLT
- **Controllers**: Olt.php (40 methods), Hioso.php, Vsol.php, Cdata.php
- **Vendor**: HSGQ, HIOSO, VSOL, CData
- **Fitur**: ONT/ONU registration, status, reboot, VLAN

### GenieACS (TR-069)
- **Helper**: genieacs_helper.php
- **View**: backend/genieacs/
- Auto-provision ONT, monitoring RX Power, firmware

### Payment Gateway
- Duitku, iPaymu, Tripay, Xendit, Midtrans (Snap), Flip
- Moota (mutasi bank otomatis)

### WhatsApp
- **Controller**: Whatsapp.php (44 methods)
- Send message, reminder, broadcast, auto-reply

### Telegram
- **Controller**: Telegram.php (27 methods)
- Bot integration

### SMS
- **Controller**: Sms.php
- Provider: Indosat

---

## 🔗 REST API

### Format
- REST Server (ci3-rest-server)
- API Key authentication (`X-API-KEY` header)
- Response: JSON (default), XML, CSV, HTML, PHP

### Endpoints
| Endpoint | Method | Fungsi |
|----------|--------|--------|
| `api/auth` | POST/GET | Login API |
| `api/customer` | GET | List pelanggan |
| `api/customer` | POST | Tambah pelanggan |
| `api/customer/getpackage` | GET | List paket |
| `api/bill` | GET | List tagihan |
| `api/bill/detail` | GET | Detail tagihan |
| `api/bill/unpaid` | GET | Tagihan belum bayar |
| `api/bill/mark_as_paid` | POST | Tandai sudah bayar |
| `api/coverage` | GET | List area |
| `api/income` | GET | Data pemasukan |
| `api/package` | GET | List paket |
| `api/router` | GET | List router |
| `api/router/mode` | GET | Mode koneksi |
| `api/key` | PUT/DELETE/POST | API key management |

---

## 🗄️ Database (Structure from Models)

### Tabel Utama
```
customer        — Pelanggan (no_services PK, name, email, no_wa, coverage, router,
                  mode_user, c_status, active_bill, user_mikrotik, address, 
                  code_area, vendor, type_payment, paket, biaya, auto_isolir, ...)
customer_status — Status pelanggan (Aktif, Isolir, Menunggu, Non-Aktif)
invoice         — Tagihan (invoice PK, no_services FK, inv_due_date, amount, 
                  status, month, created, method, ...)
invoice_detail  — Detail item tagihan
income          — Pemasukan (date_payment, amount, category, coverage, 
                  create_by, bank_id, remark, mode_payment, ...)
income_pending  — Pemasukan pending
expenditure     — Pengeluaran
bill_rekening   — Tagihan listrik/BPJS
help            — Tiket bantuan
help_timeline   — Timeline tiket
schedule        — Jadwal pekerjaan
whatsapp_schedule — Jadwal WhatsApp
package_item    — Item paket
package_category — Kategori paket
coverage        — Area coverage (kode_area, nama, alamat, koordinat)
router          — Router MikroTik
m_odc           — ODC management
m_odp           — ODP management
services        — Layanan tambahan
sales           — Transaksi sales
partner         — Partner/teknisi
user            — User admin
role_management — Role
role_menu       — Permission menu
bank            — Data bank
va              — Virtual Account
logs            — Activity logs
report_transaction — Laporan transaksi
post            — CMS post/artikel
```

### Relasi Kunci
- `customer.no_services` ↔ `invoice.no_services`
- `customer.c_status` ↔ `customer_status.status`
- `customer.coverage` ↔ `coverage.kode_area`
- `customer.router` ↔ `router.id`
- `income.bank_id` ↔ `bank.bank_id`
- `user.role_id` ↔ `role_management.role_id`
- `help` ↔ `customer` (via no_services)
- `schedule` ↔ `partner` (teknisi)

---

## 🔄 Cron Jobs (di `routes.php`)

```php
/donasi                    → bill/donation
/backup                    → setting/backup
/expired                   → setting/expired
/isolir                    → front/expired
/createbill/{token}        → front/createbill
/reminderduedate/{token}   → whatsapp/sendreminder
/countpppoe/{token}        → front/countpppoe
/backupdb/{token}          → front/backup
```

---

## 📊 Key Controller Sizes

| Controller | Lines | Methods |
|------------|-------|---------|
| **Bill** | 5,803 | 134 |
| **Customer** | 5,529 | 127 |
| **Schedule** | 3,562 | 66 |
| **Mikrotik** | 2,266 | 63 |
| **Integration** | 2,127 | 41 |
| **Whatsapp** | 2,091 | 44 |
| **Front** | 1,741 | 60 |
| **Telegram** | 1,868 | 27 |
| **Help** | 1,839 | 46 |
| **Income** | 1,274 | 41 |
| **Olt** | 1,225 | 40 |
| **Dashboard** | 1,117 | 47 |

---

## 🛠️ Helpers Khusus

| Helper | Fungsi |
|--------|--------|
| `db_helper` | Database utilities |
| `genieacs_helper` | GenieACS API connection |
| `login_helper` | Auth & session management |
| `mgdb_helper` | Additional DB functions |
| `mywifi_helper` | Core business logic |
| `olt_helper` | OLT abstraction |
| `update_helper` | System update |
| `va_helper` | Virtual Account |

---

## 📝 Notes untuk Rebuild

1. **CI3 Query Builder** → bisa diganti Laravel Eloquent / model modern
2. **SSH ke MikroTik** pakai `ssh2_connect()` atau `phpseclib`
3. **Banyak hardcoded logic** di controller, bisa di-refactor ke service layer
4. **DataTables server-side** di banyak halaman
5. **No ORM** — query builder mentah, bisa upgrade ke ORM
6. **3 instance identik** — design multi-tenant atau single codebase dengan config per domain
7. **Payment gateway** masing-masing implementasi sendiri — bisa diseragamkan
8. **WhatsApp API** kemungkinan pakai library pihak ketiga / API gateway
