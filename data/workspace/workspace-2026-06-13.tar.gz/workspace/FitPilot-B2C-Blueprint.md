# FitPilot B2C — Personal Health & Fitness Tracker

> **Produk**: FitPilot (by Pilot Digital)
> **Tagline B2C**: *"Your fitness co-pilot. Every rep, every meal, every gain."*
> **Dibuat**: 1 Juni 2026 | Ujang

---

## 🎯 Dual Market Strategy

```
┌─────────────────────────────────────────────┐
│                 FITPILOT                     │
│                                             │
│  ┌──────────────┐    ┌──────────────────┐   │
│  │    B2B       │    │      B2C         │   │
│  │  Gym Owners  │    │  End Users       │   │
│  │  (SaaS)      │◄──►│  (App Gratis)    │   │
│  └──────────────┘    └──────────────────┘   │
│        │                      │             │
│  Revenue: Gym         Revenue: Premium      │
│  $18-90/bln/gym       $3-7/bln/user         │
│        │                      │             │
│        └────────┬─────────────┘             │
│                 │                           │
│        Network Effects:                     │
│        User gym X → discover gym Y          │
│        Gym Z pakai FitPilot → user join     │
└─────────────────────────────────────────────┘
```

---

## 📊 B2C Target User Persona

| Persona | Umur | Goals | Pain Points |
|---------|------|-------|-------------|
| **Gym Bro** 🏋️ | 18-30 | Get big, PR every lift, track macros | Males catet manual, bingung progres |
| **Weight Loss Warrior** ⚖️ | 25-45 | Turun 10-20kg, healthier lifestyle | Gak konsisten, gak tau harus ngapain |
| **Fitness Girl** 🧘 | 20-35 | Tone up, pilates/yoga, meal prep | Ribet ganti apps, pengen all-in-one |
| **Health Conscious** 💚 | 30-55 | Stay healthy, track vitals, step count | Banyak device, data tersebar dimana-mana |
| **Beginner** 🌱 | 16-25 | Mulai nge-gym, bingung alat apa | Intimidasi di gym, gak ada guide |

---

## 📱 FitPilot B2C — Complete Feature Spec

### ═══════════════════════════════════
### MODUL 1: PERSONAL DASHBOARD
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **Health Score** | Skor 1-100 gabungan dari: workout consistency, nutrition quality, sleep, recovery, body metrics |
| **Today View** | Ringkasan hari ini: kalori in/out, workout done?, steps, water intake, sleep hours |
| **Weekly Summary** | Recap mingguan: total workout, total volume, avg calories, weight trend, streak |
| **Widgets** | Customizable homescreen widgets: steps, streak, next workout, macros progress |
| **Streak Calendar** | GitHub-style heatmap: hijau = workout day, merah = skip day |
| **Quick Actions** | Floating button: "Start Workout", "Log Meal", "Log Weight", "Take Progress Photo" |

### ═══════════════════════════════════
### MODUL 2: WORKOUT TRACKER (Bintang Utama)
### ═══════════════════════════════════

**Contek + Improve dari: Hevy, Strong, Fitbod, JEFIT**

| Fitur | Deskripsi |
|-------|-----------|
| **Workout Logger** | Log sets, reps, weight, RPE, rest timer auto-start |
| **Exercise Library** | 1000+ exercises dengan: animasi 3D, video demo, instructions, muscle group map |
| **Custom Routine Builder** | Bikin workout plan: drag-drop exercises, set rest timer, notes per exercise |
| **AI Routine Generator** | "Bikin program push/pull/legs 4x seminggu fokus hypertrophy" → AI bikin otomatis |
| **AI Adaptive Progression** | AI auto-naikin beban/reps/volume based on progress + recovery |
| **PR Detection** | Auto-detect personal record → celebration animation + share ke feed |
| **Rest Timer** | Auto-start rest timer antar set, notifikasi getar pas waktunya |
| **Superset / Circuit** | Log superset, circuit, AMRAP, EMOM, Tabata — semua format workout |
| **Templates** | Simpan workout sebagai template buat dipake lagi |
| **Body Map** | Visual heatmap: otot mana yg dilatih minggu ini, recovery status per muscle group |
| **Volume Tracker** | Total volume (sets × reps × weight) overtime per muscle group |
| **1RM Calculator** | Auto-calculate estimated 1RM dari reps, chart overtime |
| **Workout Notes** | Foto form check, notes tentang form, pain, energy level |

#### AI Computer Vision (ON-DEVICE ML)

| Fitur | Deskripsi |
|-------|-----------|
| **Auto Rep Counting** | Arahin kamera HP → auto hitung reps. Works offline. |
| **Form Feedback** | Real-time audio: "jongkok lebih dalam", "punggung jangan bungkuk", "lutut inward — perbaiki" |
| **Exercise Auto-Detect** | Kamera deteksi lo lagi ngapain (bench, squat, deadlift, curl) — langsung log |
| **Range of Motion** | Ukur ROM per rep, skor kualitas gerakan 1-100 |
| **Barbell Path Tracking** | Track bar path buat squat/bench/deadlift — deteksi form breakdown |
| **Side-by-Side Comparison** | Bandingin form lo vs pro athlete / coach demo |

### ═══════════════════════════════════
### MODUL 3: NUTRITION TRACKER
### ═══════════════════════════════════

**Contek + Improve dari: MyFitnessPal, MacroFactor, SnapCalorie**

| Fitur | Deskripsi |
|-------|-----------|
| **Food Diary** | Log makanan per meal (breakfast, lunch, dinner, snacks) |
| **Barcode Scanner** | Scan barcode produk Indonesia (Indomie, Ultra Milk, dll) + global |
| **Indonesian Food Database** | Nasi padang, sate ayam, gado-gado, rendang, soto, bakso — DATABASE LOKAL |
| **AI Photo Logging** | Foto makanan → AI deteksi makanan + estimasi kalori + makro |
| **Voice Logging** | "Sarapan nasi goreng 1 piring, telor 2, es teh manis" → auto-log |
| **Custom Foods** | Tambah makanan custom, resep, meal |
| **Macro Goals** | Set target protein, carbs, fat — progress bar visual |
| **Calorie Budget** | Kalori target harian, auto-adjust based on goal (cut/maintain/bulk) |
| **Nutrition Score** | Grade A-F based on: kalori on target?, protein cukup?, gula gak berlebih?, serat? |
| **Micronutrient Tracking** | Vitamin, mineral, fiber, sodium — flag deficiency |
| **Water Tracker** | Log air putih (ml), visual glass counter, reminder tiap 2 jam |
| **Meal Planning** | AI bikin meal plan mingguan sesuai goal + preferensi + budget Indonesia |
| **Pre/Post Workout Tips** | Notif: "30 menit lagi workout — makan banana + whey sekarang" |
| **Eating Out Guide** | Database menu restoran Indonesia: HokBen, Solaria, McD, Warteg, Padang |

### ═══════════════════════════════════
### MODUL 4: BODY & PROGRESS TRACKER
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **Weight Tracker** | Log berat badan harian, chart trendline, moving average 7 hari |
| **Body Measurements** | Lingkar: pinggang, dada, lengan, paha, betis, leher, pinggul — chart overtime |
| **Body Fat %** | Manual input atau sync dari smart scale (Mi Scale, Withings, etc) |
| **BMI Calculator** | Auto-calculate, tapi de-emphasize (fokus ke BF%) |
| **Progress Photos** | Grid foto: depan, samping, belakang — side-by-side comparison |
| **Photo Timeline** | Scrollable timeline foto progress mingguan/bulanan |
| **AI Body Composition** | Dari foto doang → AI estimasi BF% + muscle mass (future) |
| **Goal Setting** | "Turun 10kg dalam 3 bulan" → AI bikin milestone + reminder |
| **Goal Progress** | Visual progress bar, "on track" / "behind" indicator |
| **Transformation Story** | Auto-generate "before → after" video dari semua foto progres |

### ═══════════════════════════════════
### MODUL 5: HEALTH VITALS DASHBOARD
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **Heart Rate** | Resting HR, HRV, workout HR zones — sync dari wearable |
| **Blood Pressure** | Manual log systolic/diastolic, chart overtime, alert kalau tinggi |
| **Blood Sugar** | Log gula darah puasa/post-meal (buat user diabetes/prediabetes) |
| **Sleep** | Sleep duration, stages (deep/REM/light), sleep score — sync wearable |
| **Steps** | Daily step count, weekly average, goal (10K steps) |
| **SpO2** | Blood oxygen — sync dari wearable |
| **Body Temperature** | Basal body temp (buat yg tracking siklus menstruasi) |
| **Menstrual Cycle** | Period tracker, fertile window, symptom logging, cycle predictions |
| **Lab Results** | Upload PDF hasil lab → AI ekstrak data + chart cholesterol, blood sugar, etc |
| **Medication Reminder** | Set reminder minum obat/vitamin, log kepatuhan |
| **Family Health** | Dashboard buat pantau health anggota keluarga (ortu, anak) |

### ═══════════════════════════════════
### MODUL 6: WEARABLE INTEGRATION
### ═══════════════════════════════════

| Device | Data Synced |
|--------|-------------|
| **Apple Watch** | HR, HRV, SpO2, steps, sleep, workout, ECG, blood oxygen |
| **Garmin** | HR, body battery, VO2 max, training status, stress, sleep |
| **Fitbit** | HR, sleep, steps, SpO2, readiness score |
| **Samsung Galaxy Watch** | HR, body composition (BIA), sleep, stress, steps |
| **WHOOP** | Strain, recovery, sleep performance (via Apple Health bridge) |
| **Oura Ring** | Readiness, sleep score, HRV, body temp (via Apple Health bridge) |
| **Mi Band / Amazfit** | Steps, HR, sleep |
| **Smart Scale** | Withings, Mi Body Composition Scale, Fitbit Aria |
| **CGM (Diabetes)** | Dexcom, Freestyle Libre — real-time blood glucose |
| **Apple Health / Health Connect** | Central bridge — semua data aggregator |

### ═══════════════════════════════════
### MODUL 7: AI PERSONAL COACH
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **AI Chat Coach** | Chat kayak WhatsApp sama AI coach: "Gue capek banget hari ini, mending rest atau tetep workout?" |
| **Daily Briefing** | Tiap pagi: "Pagi bro! Skor recovery lo 78 — oke buat workout. Program hari ini: Upper Body Push. Target kalori: 2,200." |
| **Weekly Review** | "Minggu ini: workout 4/5 ✅, kalori avg on target, BB turun 0.5kg. PR baru di bench! 💪" |
| **AI Form Check** | Upload video → AI analisa form + kasih tips perbaikan |
| **AI Program Design** | "Bikinin program cutting 12 minggu, equipment: dumbell + barbell + cable" |
| **AI Troubleshooting** | "Kenapa bench gue stuck di 60kg?" → AI analisa data + saran |
| **Motivation Engine** | AI deteksi lo hampir quit → kirim pesan semangat + adjust goal |
| **Voice Coach** | AI voice guide lo selama workout: "Rest 30 detik lagi... mulai set 3... jaga tempo 2-0-2" |

### ═══════════════════════════════════
### MODUL 8: GAMIFICATION
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **XP System** | XP dari: workout selesai, PR baru, streak, nutrition on point, steps goal |
| **Level Tiers** | Lv 1-10 (Beginner) → 11-25 (Intermediate) → 26-50 (Advanced) → 51-75 (Elite) → 76-100 (Legend) |
| **Badges** | 100+ achievement badges: pamer di profil |
| **Streak System** | 🔥 Workout streak, 🥗 Nutrition streak, 💧 Water streak, 👣 Steps streak |
| **Streak Shield** | Earn shield tiap 7 hari streak, protect 1 missed day |
| **Daily Challenges** | "Complete 30 push-ups", "Hit protein target", "Walk 10K steps" |
| **Seasonal Leagues** | 3-month ranked season — siapa paling konsisten? Promotion/relegation |
| **Leaderboards** | Global & friends: most workouts, heaviest total, most consistent |
| **Level-Up Rewards** | Unlock: dark mode exclusive, custom app icon, coaching session gratis |
| **Versus Mode** | Tantang temen: "Siapa lebih banyak workout bulan ini?" |

### ═══════════════════════════════════
### MODUL 9: SOCIAL & COMMUNITY
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **Activity Feed** | Timeline: workout selesai, PR baru, badge unlock, milestone — like & comment |
| **Workout Sharing** | Share workout ke feed atau IG Story — branded graphic keren |
| **PR Celebration** | Auto-post pas dapet PR, temen bisa kasih 🎉🔥💪 |
| **Follow System** | Follow temen, liat progress mereka, high-five |
| **Groups** | Join group: "Deadlift Gang Indonesia", "Keto Warriors", "Yoga Bandung" |
| **Group Challenges** | Admin bikin challenge, member join, leaderboard |
| **Workout Together** | Sync workout real-time sama temen, liat live progress |
| **Coach Discovery** | Cari personal trainer/coach, booking sesi, progress tracker bareng coach |
| **Gym Discovery** | Liat gym terdekat yg pake FitPilot B2B — "300m dari lo, free trial 3 hari" |
| **Events** | Gym event, running event, competition — discover & join |

### ═══════════════════════════════════
### MODUL 10: ADDITIONAL WELLNESS
### ═══════════════════════════════════

| Fitur | Deskripsi |
|-------|-----------|
| **Meditation** | Guided meditation 5-15 menit, sleep stories, breathing exercise |
| **Yoga** | Video yoga class: beginner → advanced, 10-60 menit |
| **Stretching** | Pre/post workout stretching routine, mobility drills |
| **Running** | GPS run tracker (kayak Strava/Nike Run Club), pace, elevation, splits |
| **Cycling** | GPS cycling tracker, cadence, power (sync dari sensor) |
| **Swimming** | Manual log: distance, stroke, time, SWOLF (sync dari Garmin) |
| **Hiking** | GPS hike tracker, elevation gain, trail map |

---

## 💰 B2C Monetization

### Freemium Model

| Tier | Harga | Fitur |
|------|-------|-------|
| **FREE** | Rp 0 | Workout logger, basic nutrition, weight tracker, steps, 3 routines, basic badges |
| **PRO** | **Rp 49K/bln** (~$3) | AI coach, AI rep counting, AI form check, unlimited routines, nutrition photo logging, all badges, groups, challenges, export data |
| **FAMILY** | **Rp 79K/bln** (~$5) | Semua PRO untuk 5 anggota keluarga, family dashboard, family challenges |

### Kenapa Rp 49K?

- MyFitnessPal Premium: Rp 120K/bln → kita 60% lebih murah
- Strava Premium: Rp 89K/bln → kita 45% lebih murah
- Fitbod: $12.99/bln (~Rp 200K) → kita 75% lebih murah
- **Rp 49K** = harga 1 bungkus rokok = 1 gelas kopi kekinian

---

## 🔄 B2C ↔ B2B Network Effect

```
┌──────────────────────────────────────────┐
│                                          │
│  User B2C workout di Gym X              │
│       │                                  │
│       ▼                                  │
│  Gym X belum pake FitPilot B2B          │
│       │                                  │
│       ▼                                  │
│  FitPilot: "Gym X punya 50 member       │
│  aktif di app kita. Mau cobain          │
│  FitPilot B2B gratis 30 hari?"          │
│       │                                  │
│       ▼                                  │
│  Gym X join B2B ← Win!                  │
│                                          │
│  ────────────────────────────────────    │
│                                          │
│  Gym Y join FitPilot B2B               │
│       │                                  │
│       ▼                                  │
│  FitPilot: "300 member Gym Y.           │
│  Install FitPilot app gratis —          │
│  track workout + join community!"       │
│       │                                  │
│       ▼                                  │
│  300 user B2C baru ← Win!               │
│                                          │
└──────────────────────────────────────────┘
```

---

## 📊 FitPilot vs App Kompetitor (B2C)

| Fitur | FitPilot | MyFitnessPal | Strava | Hevy | Fitbod | Freeletics |
|-------|:---:|:---:|:---:|:---:|:---:|:---:|
| **Workout Logger** | ✅ | ❌ | 🤏 | ✅ | ✅ | ✅ |
| **AI Coaching** | ⚡ | ❌ | ❌ | ❌ | ✅ | ✅ |
| **AI Rep Counting (CV)** | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Nutrition Tracker** | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| **Makanan Indonesia DB** | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Body Measurements** | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| **Progress Photos** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Wearable Sync** | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ |
| **Health Vitals** | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Sleep Tracking** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **GPS Run/Cycle** | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ |
| **Gamification** | ⚡ | ❌ | ✅ | ✅ | ❌ | ✅ |
| **Social Feed** | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| **Gym Discovery** | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Bilingual ID/EN** | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Price (IDR)** | **Rp 0-49K** | Rp 120K | Rp 89K | Gratis | Rp 200K | Rp 150K |

> **⚡ = FitPilot EKSKLUSIF — gak ada di app manapun**

---

## 🗺️ FitPilot B2C Roadmap

| Fase | Timeline | Deliverables |
|------|----------|-------------|
| **Fase 1: Core MVP** | Bulan 1-2 | Workout logger, exercise library, basic nutrition, weight tracker, profile |
| **Fase 2: AI + CV** | Bulan 3-4 | AI coach chat, AI rep counting, AI form feedback, AI routine generator |
| **Fase 3: Wearable** | Bulan 5 | Apple Watch sync, HealthKit, Health Connect, Garmin |
| **Fase 4: Social** | Bulan 6 | Feed, follow, PR sharing, groups, challenges |
| **Fase 5: Gamification** | Bulan 7 | XP system, badges, leagues, leaderboards |
| **Fase 6: Wellness** | Bulan 8 | Sleep, meditation, yoga, running GPS |
| **Fase 7: Family** | Bulan 9 | Family plan, family dashboard, health vitals for elderly |

---

## 🎯 Go-to-Market Strategy (B2C)

### 1. Viral Loop
> "Install FitPilot gratis. Track workout lo. Share PR ke IG → temen lo install."

### 2. Influencer Fitness Indo
> Collab fitness influencer Indonesia (100K-1M followers) — "Ini app gue pake buat tracking..."

### 3. Pre-Installed di Gym Partner
> Gym yg pake FitPilot B2B → semua member dapat QR code download app gratis + PRO 1 bulan

### 4. Campus Ambassadors
> Mahasiswa olahraga/fitness jadi ambassador di kampus, bikin challenge antar kampus

### 5. "Indonesia's Fittest" Challenge
> Annual competition: most consistent, most transformed, strongest — hadiah + sertifikat

---

## 💵 Revenue Projection (B2C)

| Year | Users | % PRO | Revenue/Month |
|------|-------|-------|---------------|
| Y1 | 50K | 5% (2,500) | Rp 122M/bln |
| Y2 | 500K | 5% (25,000) | Rp 1.2M/bln |
| Y3 | 2M | 5% (100,000) | Rp 4.9M/bln |

---

*FitPilot B2C = Fitbod + MyFitnessPal + Strava + Hevy dalam 1 app. Made in Indonesia, for the world. ✈️*
