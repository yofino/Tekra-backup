# PRD — FitPilot: SaaS Gym Management + Progress Tracker

> **Product Name**: FitPilot (by **Tekra** — PT Teknologi Rakyat)
> **Brand Family**: Pilot Series — NetPilot / FitPilot / WorkPilot
> **Version**: 1.0 MVP
> **Author**: Ujang
> **Date**: 1 Juni 2026
> **Status**: Draft — Siap Eksekusi Claude Code
> **Blueprint dari**: NetPilot ISP Billing (60% reuse codebase)
> **Philosophy**: *"Pilot your fitness journey."*

---

## 1. Executive Summary

FitPilot adalah SaaS multi-tenant untuk gym, fitness center, studio yoga, dan crossfit box di Indonesia. Menggabungkan membership management, check-in, billing, class scheduling, PT booking, dan **progress tracker with goals & gamification** dalam satu platform. Produk kedua dari **Pilot Series by Tekra**.

Target market: 5.000+ gym di Indonesia yang 90% masih manual.

**Killer Feature**: Progress + Goals Tracker yang bikin member engaged & gak mau cabut — langsung nurunin churn rate gym.

---

## 2. Kenapa Sekarang?

| Fakta | Angka |
|-------|-------|
| Gym di Indonesia | 5.000+ (Fitness, Yoga, CrossFit, Muay Thai, Pilates) |
| Yang pakai sistem | < 10% (Excel / WA / buku) |
| FitHub (kompetitor besar) | Punya app bagus tp gak dijual sebagai SaaS |
| Kompetitor SaaS gym | Hanya 2-3, mahal, fitur kaku |
| **Ini blue ocean** | Market kosong, tinggal eksekusi |

---

## 3. Tech Stack

| Layer | Teknologi | Alasan |
|-------|-----------|--------|
| **Backend** | Laravel 11 | Sama dengan NetPilot — 60% code reuse |
| **Frontend** | Livewire 3 + Alpine.js + Tailwind | Sama |
| **Database** | MySQL 8 (multi-schema) | Sama |
| **Cache/Queue** | Redis + Horizon | Sama |
| **Mobile App** | Flutter 3.x (Android + iOS) | Sama |
| **Payment** | Midtrans | Sama |
| **WhatsApp** | WhatsApp Cloud API | Sama |
| **AI** | DeepSeek / OpenAI | Sama |
| **Charts** | Chart.js / ApexCharts | Progress visualization |

---

## 4. Modules Detail

---

### MODUL A: Multi-Tenant Core (Reuse 100%)

| Feature | Priority | Description |
|---------|----------|-------------|
| Tenant Registration | P0 | Daftar gym baru, trial 14 hari |
| Tenant Database | P0 | Auto-create schema per gym |
| Subscription Plan | P0 | Starter/Pro/Enterprise |
| White-label | P1 | Logo, nama, warna, custom domain |
| Super Admin | P0 | Kelola semua tenant |

---

### MODUL B: Member Management

| Feature | Priority | Description |
|---------|----------|-------------|
| Member CRUD | P0 | Nama, foto, no WA, email, alamat, tanggal lahir |
| Member ID Card | P0 | Digital member card + QR code |
| Medical Waiver | P1 | Form kesehatan, emergency contact |
| Member Portal | P0 | Self-service (lihat progress, bayar, booking) |
| Status | P0 | Aktif, Freeze, Expired, Blacklist |
| Bulk Import | P1 | Import dari Excel |
| Member Notes | P2 | Catatan internal staff |

---

### MODUL C: Membership Plans

| Feature | Priority | Description |
|---------|----------|-------------|
| Plan CRUD | P0 | Nama, durasi, harga, deskripsi |
| Durasi | P0 | Harian, mingguan, 1/3/6/12/18/24 bulan |
| Multi-type | P1 | Reguler, Family, Couple, Student, Corporate |
| Add-on | P2 | Locker, handuk, parkir |
| Freeze/Cuti | P1 | Syarat: medis / pindah tugas, max 2 minggu |
| Renewal Discount | P2 | Early renewal discount |

---

### MODUL D: QR Check-in System

| Feature | Priority | Description |
|---------|----------|-------------|
| QR Code Member | P0 | Tiap member punya QR unik di digital card |
| Scan Check-in | P0 | Staff scan QR lewat app/web |
| Auto Attendance | P0 | Log check-in date + time |
| Check-in Streak | P1 | 🔥 Hitung streak berturut-turut |
| Daily Count | P1 | Dashboard: check-in hari ini |
| Peak Hour Analytics | P2 | Jam tersibuk |

---

### MODUL E: Billing + Payment (Reuse 80%)

| Feature | Priority | Description |
|---------|----------|-------------|
| Auto Invoice | P0 | Generate invoice per periode membership |
| Payment Gateway | P0 | Midtrans (QRIS, VA, GoPay, ShopeePay, Kartu) |
| Manual Payment | P1 | Cash, transfer, upload bukti |
| Payment History | P1 | Riwayat pembayaran member |
| Auto Suspend | P0 | Member overdue → nonaktif check-in |
| WhatsApp Reminder | P1 | H-7, H-3, H-1, expired |
| Invoice PDF | P1 | Generate + kirim email/WA |

---

### MODUL F: 🏆 PROGRESS TRACKER (Killer Feature) ⭐

#### F1 — Onboarding + Goal Setting

| Feature | Priority | Description |
|---------|----------|-------------|
| Body Assessment | P0 | Input berat, tinggi, body fat %, lingkar tubuh (dada, pinggang, pinggul, lengan, paha) |
| Progress Photos | P0 | Upload foto depan/samping/belakang saat daftar |
| Goal Setting | P0 | Pilih: Lose Weight / Build Muscle / Body Recomp / Endurance / Strength |
| Target | P0 | Target berat & body fat %, deadline timeline |
| Fitness Level | P0 | Beginner / Intermediate / Advanced |
| Preferences | P1 | Cardio / Weights / Classes / Mix |
| Medical Notes | P1 | Cedera, kondisi khusus |

#### F2 — Measurement Log (Berkala)

| Feature | Priority | Description |
|---------|----------|-------------|
| Weight Log | P0 | Input manual atau integrasi smart scale (Withings/Fitbit API) |
| Body Fat % | P0 | Input manual |
| Body Measurements | P0 | Dada, pinggang, pinggul, lengan (kiri/kanan), paha (kiri/kanan), betis |
| Progress Photos | P0 | Foto depan/samping/belakang — perbandingan side-by-side |
| Measurement Reminder | P1 | Auto-notif: "Sudah 2 minggu! Waktunya cek progress 📏" |
| Log History | P0 | Timeline semua measurement |

#### F3 — Workout Logger

| Feature | Priority | Description |
|---------|----------|-------------|
| Template Workout | P1 | Full Body, Push/Pull/Legs, Upper/Lower, Bro Split |
| Custom Workout | P1 | Buat sendiri, simpan template |
| Exercise Database | P1 | 200+ latihan (gambar + instruksi) |
| Log Set | P1 | Latihan → berat × repetisi × set |
| Rest Timer | P2 | Otomatis antar set |
| Volume Calculator | P2 | Total kg diangkat per sesi |
| Personal Records | P1 | 🏆 Auto-detect PR, celebration notif |
| Workout History | P1 | Riwayat semua sesi |

#### F4 — Charts & Visualization

| Chart | Priority | Data |
|-------|----------|------|
| Weight Timeline | P0 | Line chart berat badan vs target |
| Body Fat % | P1 | Line chart body fat % vs target |
| Measurements | P1 | Bar chart per tanggal ukur |
| Strength Progress | P1 | Line chart per latihan kunci (bench, squat, deadlift) |
| Attendance Heatmap | P2 | Grid kalender kayak GitHub |
| Before/After Photos | P0 | Slider perbandingan foto |
| Body Composition | P2 | Pie chart (fat vs muscle vs bone vs water) |

#### F5 — Gamification & Achievements

| Badge | Trigger | Priority |
|-------|---------|----------|
| 🥉 First Timer | Check-in pertama | P0 |
| 🔥 7-Day Streak | 7 hari check-in berturut-turut | P1 |
| 🔥🔥 30-Day Streak | 30 hari | P1 |
| 💪 -5kg | Turun 5kg dari berat awal | P1 |
| 💪💪 -10kg | Turun 10kg | P1 |
| 🏋️ 500kg | Total angkat 500kg dalam 1 sesi | P2 |
| 🏋️ 1 Ton | Total angkat 1000kg | P2 |
| 🎯 Goal Smasher | Tercapai target | P0 |
| ⏱️ 3 Bulan | 3 bulan membership aktif | P1 |
| 🥇 PT Finisher | Selesai paket PT | P2 |

---

### MODUL G: Class Scheduling

| Feature | Priority | Description |
|---------|----------|-------------|
| Class CRUD | P1 | Nama, deskripsi, instruktur, durasi, kapasitas |
| Schedule | P1 | Jadwal mingguan, kalender |
| Booking System | P1 | Member book kelas, max kapasitas |
| Waitlist | P2 | Auto waitlist kalau penuh |
| Cancel Booking | P1 | Batal H-2 jam |
| Reminder | P1 | WA reminder 1 jam sebelum kelas |
| Attendance | P1 | Check-in peserta kelas |

---

### MODUL H: PT Booking + Management

| Feature | Priority | Description |
|---------|----------|-------------|
| PT Profile | P1 | Nama, spesialisasi, sertifikasi, foto, rating |
| PT Packages | P1 | 4/8/12/24/48/96 sesi, harga |
| Booking Calendar | P1 | Lihat slot kosong, book sesi |
| Session Notes | P1 | PT catat progress setelah sesi |
| Session History | P1 | Member lihat catatan + progress |
| Remaining Sessions | P1 | Counter sisa sesi |
| PT Payroll | P2 | Komisi per sesi, report |

---

### MODUL I: Multi-Branch

| Feature | Priority | Description |
|---------|----------|-------------|
| Branch CRUD | P1 | Tambah cabang (alamat, jam operasional, kapasitas) |
| Cross-branch Access | P2 | Member bisa check-in di cabang manapun |
| Branch Dashboard | P2 | Per cabang analytics |
| Branch Staff | P2 | Assign staff per cabang |

---

### MODUL J: Member Portal (Web + App)

#### Dashboard
```
┌──────────────────────────────┐
│ 👋 Halo, Ervan!              │
│ Member sejak: 1 Jan 2026     │
│ Membership: Aktif ✅ (6 bln) │
├──────────────────────────────┤
│ 📊 MY PROGRESS               │
│ Awal: 82kg → Sekarang: 78kg │
│ Target: 70kg — 4kg lagi! 💪 │
│ [=======------] 65% progress │
├──────────────────────────────┤
│ 🔥 12-Day Streak! 🔥         │
├──────────────────────────────┤
│ 📅 Today's Classes           │
│ 07:00 Yoga        [Book]     │
│ 18:00 Muay Thai   [Book]     │
├──────────────────────────────┤
│ ⚡ QUICK ACTIONS             │
│ [QR Check-in] [Book PT]      │
│ [Log Workout] [Cek Progress] │
└──────────────────────────────┘
```

#### Progress Page
```
🏁 GOALS
Target: 70kg (dari 82kg) | Target: 6 bulan
Progress: 78kg (65%)

📈 CHARTS
[Weight Chart] [Body Fat %]
[Measurements] [Strength]

📸 PHOTOS
[1 Jun] vs [1 Jul] vs [1 Aug]
(Slider perbandingan)

📋 WORKOUT LOG
[Latest workouts...]

🏆 ACHIEVEMENTS
🥇 🥈 🥉  (badge collection)
```

---

### MODUL K: AI Features

| Feature | Priority | Description |
|---------|----------|-------------|
| AI Coach | P2 | Chatbot fitness: rekomendasi workout, tips nutrisi |
| AI Retention Predictor | P2 | Prediksi member yg mau churn (gak check-in >2 minggu, gak log progress) |
| AI Goal Adjuster | P2 | "Target lo agresif, saran gue: turunin 0.5kg/minggu" |
| AI Class Recommender | P2 | Rekomendasi kelas berdasarkan preference + history |

---

### MODUL L: Admin Dashboard

| Feature | Priority | Description |
|---------|----------|-------------|
| Revenue Dashboard | P0 | Monthly revenue, by branch |
| Member Stats | P0 | Total, baru, churn, retention rate |
| Peak Hours | P1 | Jam & hari tersibuk |
| PT Performance | P1 | Sesi, revenue, rating |
| Class Popularity | P1 | Kelas terfavorit |
| Expiring Members | P1 | Member yg mau expired, target renew |

---

## 5. Data Model (Key Tables)

```
tenants              — Tenant gym (id, name, domain, plan, status)

members              — Member (id, name, photo, wa, email, address, 
                       birth_date, medical_notes, emergency_contact,
                       join_date, status, branch_id)

memberships          — Jenis membership (name, duration_days, price, type)
member_plans         — Membership member (member_id, membership_id,
                       start_date, end_date, status, freeze_start, freeze_end)

checkins             — Check-in log (member_id, datetime, branch_id, method)

progress_goals       — Goal member (member_id, goal_type, target_weight, 
                       target_bf, target_date, start_weight, start_bf)

body_measurements    — (member_id, date, weight, body_fat, chest, waist,
                       hips, left_arm, right_arm, left_thigh, right_thigh, ...)

progress_photos      — (member_id, date, photo_front, photo_side, photo_back)

workouts             — (member_id, date, name, duration, notes, calories)

workout_exercises    — (workout_id, exercise_id, sets, reps, weight)

workout_templates    — Template workout plan

exercises            — Exercise database (name, category, muscle_group, 
                       image, instructions)

pt_packages          — Paket PT (name, sessions, price)
pt_bookings          — (member_id, pt_id, datetime, status, notes)
pt_sessions          — (booking_id, notes, exercises_done, member_feedback)

classes              — Kelas (name, description, duration, capacity, instructor)
class_schedules      — Jadwal (class_id, day_of_week, time, branch_id)
class_bookings       — (member_id, schedule_id, date, status)

invoices             — Tagihan (member_id, amount, due_date, status)
payments             — Pembayaran (invoice_id, method, amount, date)

achievements         — Master data achievement
member_achievements  — (member_id, achievement_id, achieved_at)

branches             — Cabang gym (name, address, phone, capacity)
```

---

## 6. Mobile App (Flutter)

### Member App
- Dashboard + Quick QR Check-in
- Progress Tracker (charts, photos, measurements)
- Workout Logger (log latihan langsung di gym)
- Book Classes + PT
- Billing + Payment
- Achievements Badge

### Staff App
- Scan QR Member (check-in)
- Booking Management
- Quick Member Lookup

---

## 7. Revenue Model

| Plan | Harga/Bulan | Member Max | Fitur |
|------|------------|------------|-------|
| **Starter** | Rp 199K | 200 member | Core: Member, Check-in, Billing |
| **Pro** | Rp 399K | 1.000 | + Progress Tracker, Classes, PT |
| **Enterprise** | Rp 799K | Unlimited | + AI Coach, Multi-branch, White-label |

**Target**: 100 gym tenant × Rp 399K avg = **Rp 39.9jt MRR** dalam 12 bulan

---

## 8. Development Roadmap

### Phase 1: MVP (4-5 minggu)
- [ ] Multi-tenant core + auth
- [ ] Member + Membership management
- [ ] QR Check-in
- [ ] Billing + Payment
- [ ] Admin dashboard

### Phase 2: Progress Tracker (3-4 minggu) ⭐
- [ ] Goal Setting + Body Assessment
- [ ] Body Measurements + Photos
- [ ] Workout Logger
- [ ] Charts & Visualization
- [ ] Achievements & Gamification
- [ ] Member dashboard (progress view)

### Phase 3: Premium (4-5 minggu)
- [ ] Class Scheduling + Booking
- [ ] PT Booking + Management
- [ ] Multi-branch
- [ ] WhatsApp notification

### Phase 4: Mobile App (6-8 minggu)
- [ ] Flutter Member App (QR check-in, progress tracker, workout log)
- [ ] Flutter Staff App (scan QR, quick lookup)

### Phase 5: AI (3-4 minggu)
- [ ] AI Coach (chatbot)
- [ ] AI Retention Predictor
- [ ] AI Class Recommender

---

## 9. Competitor Comparison

| Fitur | FitHub (Own App) | Glofox | Mindbody | **FitPilot (Tekra)** |
|-------|-----------------|--------|----------|-------------------|
| SaaS (dijual ke gym) | ❌ | ✅ | ✅ | ✅ |
| Progress Tracker | ✅ | ❌ | ❌ | ✅ |
| Goals + Gamification | ✅ | ❌ | ❌ | ✅ |
| Workout Logger | ✅ | ❌ | ❌ | ✅ |
| QR Check-in | ✅ | ✅ | ✅ | ✅ |
| Class Booking | ✅ | ✅ | ✅ | ✅ |
| PT Management | ✅ | ✅ | ✅ | ✅ |
| AI Coach | ❌ | ❌ | ❌ | ✅ |
| Harga (untuk gym) | N/A | $200+/bln | $300+/bln | **Rp 199K/bln** |
| Bahasa Indonesia | ✅ | ❌ | ❌ | ✅ |

---

*Blueprint dari ISP SaaS — 60% codebase reusable. Build Gym SaaS paralel atau setelah ISP.*
