#!/usr/bin/env python3
"""
Network Quality Report Template
Usage: python3 network_report.py [pop]
  pop: pusat (default), dago, cilisung

Dipanggil manual atau via mention "asep cek jaringan [pop]"
"""

import sys, json, subprocess, os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

ZBX_URL = "http://10.10.10.18/zabbix/api_jsonrpc.php"
ZBX_USER = "Admin"; ZBX_PASS = "zabbix"
POP = sys.argv[1] if len(sys.argv) > 1 else "pusat"

# ── POP Config ──────────────────────────────
POPS = {
    "pusat": {
        "pfsense_host": "10681",
        "gw_host": "10084",
        "gw_prefix": "pusat",
        "wans": {
            "WAN1": "ix0.10",
            "WAN2": "igc1",
            "WAN3": "ix0.30",
            "WAN4": "ix0.40",
            "WAN5": "ix0.50",
            "WAN6": "ix0.60",
            "WAN7GW": "ix0.70",
        },
        "title": "pfSense Pusat"
    },
    "dago": {
        "pfsense_host": "10721",
        "gw_host": "10084",
        "gw_prefix": "dago",
        "wans": {"WAN1":"WAN1","WAN2":"WAN2","WAN3":"WAN3","WAN4":"WAN4"},
        "title": "pfSense Dago"
    },
    "cilisung": {
        "pfsense_host": "10722",
        "gw_host": "10084",
        "gw_prefix": "cilisung",
        "wans": {"WAN1":"WAN1","WAN2":"WAN2"},
        "title": "pfSense Cilisung"
    }
}

if POP not in POPS:
    print(f"❌ POP tidak dikenal: {POP} (pakai: pusat, dago, cilisung)")
    sys.exit(1)

CFG = POPS[POP]

# ── Zabbix Helpers ───────────────────────────
def zabbix(method, params):
    """Single Zabbix API call"""
    import requests
    r = requests.post(ZBX_URL, json={
        "jsonrpc": "2.0", "method": method,
        "params": params, "auth": token, "id": 1
    }, timeout=10)
    return r.json().get("result", [])

# Login
import requests
r = requests.post(ZBX_URL, json={
    "jsonrpc": "2.0", "method": "user.login",
    "params": {"username": ZBX_USER, "password": ZBX_PASS}, "id": 1
}, timeout=10)
token = r.json().get("result", "")
if not token:
    print("❌ Gagal login Zabbix")
    sys.exit(1)

# ── 1. Gateway Status ────────────────────────
gw_keys = []
for wan in CFG["wans"]:
    for metric in ["status","loss","rtt"]:
        gw_keys.append(f"pf.gateway[{CFG['gw_prefix']},{wan},{metric}]")

gw_data = zabbix("item.get", {
    "hostids": CFG["gw_host"],
    "search": {"key_": "pf.gateway"},
    "output": ["name","lastvalue"]
})
gw_map = {i["name"]: i["lastvalue"] for i in gw_data}

# ── 2. Bandwidth (Pusat only) ──────────────
bw_data = {}
if POP == "pusat":
    bw_items = zabbix("item.get", {
        "hostids": CFG["pfsense_host"],
        "search": {"name": "Bits received"},
        "output": ["name","lastvalue"]
    })
    for item in bw_items:
        for wan, iface in CFG["wans"].items():
            if iface in item["name"] and "Bits received" in item["name"]:
                bw_data[wan] = float(item["lastvalue"]) / 1e6

# ── 3. Ping Tests ───────────────────────────
PING_TARGETS = {
    "Content": [
        ("YouTube", "youtube.com", "icmp"),
        ("TikTok", "www.tiktok.com", "http"),  # HTTP check (ICMP blocked)
        ("Facebook", "facebook.com", "icmp"),
        ("Instagram", "instagram.com", "icmp"),
        ("Twitter/X", "twitter.com", "icmp"),
        ("Google", "google.com", "icmp"),
        ("WhatsApp", "www.whatsapp.com", "http"),  # HTTP check (ICMP kadang diblok)
        ("Spotify", "open.spotify.com", "icmp"),
        ("Shopee", "shopee.co.id", "icmp"),
        ("Netflix", "www.netflix.com", "http"),  # HTTP check (ICMP blocked)
        ("Cloudflare", "1.1.1.1", "icmp"),
        ("Google DNS", "8.8.8.8", "icmp"),
    ],
    "Gaming": [
        ("Valve/Steam", "valve.com", "icmp"),
        ("Riot Games", "riotgames.com", "icmp"),
        ("Steam CDN", "steamcommunity.com", "icmp"),
        ("Epic Games", "epicgames.com", "http"),  # HTTP check
        ("Moonton ML", "moonton.com", "http"),  # HTTP check
        ("Garena", "garena.com", "icmp"),
        ("Blizzard", "blizzard.com", "icmp"),
        ("Ubisoft", "ubisoft.com", "icmp"),
    ],
    "DNS Resolve": [
        ("youtube.com", "youtube.com"),
        ("tiktok.com", "tiktok.com"),
        ("google.com", "google.com"),
        ("facebook.com", "facebook.com"),
    ]
}

def ping_one(host):
    """Ping host, return (label, loss%, avg_ms, ok)"""
    try:
        r = subprocess.run(
            ["ping", "-c", "4", "-W", "2", host],
            capture_output=True, text=True, timeout=12
        )
        stdout = r.stdout
        if "statistics" not in stdout:
            return (host, None, None, "blocked")
        # Parse loss
        import re
        loss_match = re.search(r'(\d+)% packet loss', stdout)
        loss = int(loss_match.group(1)) if loss_match else 100
        # Parse avg rtt
        avg_match = re.search(r'rtt min/avg/max/mdev = [\d.]+/([\d.]+)/', stdout)
        if not avg_match:
            avg_match = re.search(r'= [\d.]+/([\d.]+)/', stdout)
        avg = float(avg_match.group(1)) if avg_match else 0.0
        if loss == 100:
            return (host, 100, 0, "blocked")  # 100% loss = likely ICMP blocked
        return (host, loss, avg, "ok")
    except:
        return (host, None, None, "timeout")

def check_target(target):
    """Check a target - ICMP or HTTP based on type"""
    label, host, check_type = target
    if check_type == "http":
        code, ttl_time, status = http_check(host)
        if status == "ok":
            return (host, f"{label} (HTTP)", 0, ttl_time * 1000, status)
        else:
            return (host, f"{label} (HTTP)", 100, ttl_time * 1000, status)
    else:
        h, loss, avg, status = ping_one(host)
        # If ICMP blocked, try HTTP as fallback
        if status == "blocked" or (status == "timeout" and loss == 100):
            code, ttl_time, http_status = http_check(host)
            if http_status == "ok":
                return (host, f"{label} (ICMP→HTTP)", 0, ttl_time * 1000, http_status)
        return (host, label, loss, avg, status)

def ping_all(targets):
    """Parallel check all targets"""
    results = {}
    with ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(check_target, t): t for t in targets}
        for f in as_completed(futures):
            target = futures[f]
            host, label, loss, avg, status = f.result()
            results[host] = (label, loss, avg, status)
    return results


def http_check(host, url=None):
    """HTTP response time check for targets that block ICMP"""
    if url is None:
        url = f"https://{host}"
    try:
        r = subprocess.run([
            "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}|%{time_total}",
            "--connect-timeout", "5", "--max-time", "10", "-L", url
        ], capture_output=True, text=True, timeout=12)
        parts = r.stdout.strip().split("|")
        code = int(parts[0]) if parts[0].isdigit() else 0
        ttl_time = float(parts[1]) if len(parts) > 1 else 10
        if code >= 200 and code < 500:
            return (code, ttl_time, "ok")
        else:
            return (code, ttl_time, "error")
    except:
        return (0, 10, "timeout")

# Run pings
ping_results = {}
for category, targets in PING_TARGETS.items():
    if category == "DNS Resolve":
        continue
    # Convert to list of tuples with target name
    targets_list = [(t[0], t[1], t[2]) if len(t) > 2 else (t[0], t[1], "icmp") for t in targets]
    ping_results[category] = ping_all(targets_list)

# ── 4. DNS Resolution ────────────────────────
dns_results = {}
for label, domain in PING_TARGETS["DNS Resolve"]:
    try:
        r = subprocess.run(["dig", "+short", domain], capture_output=True, text=True, timeout=5)
        if r.stdout.strip():
            ips = r.stdout.strip().split("\n")[:2]
            dns_results[label] = ", ".join(ips)
        else:
            dns_results[label] = "GAGAL"
    except:
        dns_results[label] = "GAGAL"

# ── OUTPUT ───────────────────────────────────
now = datetime.now().strftime("%d %b %Y %H:%M WIB")
print(f"📡 {CFG['title']} — {now}")
print()

# Gateway
print("🔗 Gateway Status")
for wan in CFG["wans"]:
    prefix = f"pfSense Gateway {wan}:"
    status = gw_map.get(f"{prefix} status", "?")
    loss = gw_map.get(f"{prefix} loss", "?")
    rtt = gw_map.get(f"{prefix} rtt", "?")
    icon = "🟢" if status == "0" else "🔴"
    print(f"  {icon} {wan}: {loss}% loss | {rtt}ms")

# Bandwidth
if bw_data:
    print()
    print("📊 Bandwidth Download")
    total = 0
    for wan in ["WAN1","WAN2","WAN3","WAN4","WAN5","WAN6","WAN7GW"]:
        mbps = bw_data.get(wan, 0)
        total += mbps
        flag = " ⚠️" if mbps == 0 and wan not in ("WAN2",) else ""
        print(f"  {wan}: {mbps:.0f} Mbps ↓{flag}")
    print(f"  Total: ~{total:.0f} Mbps")

# Ping results
for category in ["Content", "Gaming"]:
    print()
    emoji = "🌐" if category == "Content" else "🎮"
    print(f"{emoji} Latency {category}")
    for host, (label, loss, avg, status) in ping_results[category].items():
        if status == "blocked" or ("HTTP" in label and avg and avg >= 4000):
            print(f"  ⬜ {label}: blocked")
        elif "HTTP" in label:
            if status == "ok":
                print(f"  ✅ {label}: {avg:.0f}ms")
            else:
                print(f"  🔴 {label}: GAGAL")
        elif status == "blocked":
            print(f"  ⬜ {label}: ICMP blocked")
        elif status == "timeout" or avg is None:
            print(f"  🔴 {label}: TIMEOUT")
        elif loss == 0:
            print(f"  ✅ {label}: {avg:.1f}ms | 0% loss")
        elif loss < 10:
            print(f"  ⚠️ {label}: {avg:.1f}ms | {loss}% loss")
        else:
            print(f"  🔴 {label}: {avg:.1f}ms | {loss}% loss")

# DNS
print()
print("🔍 DNS Resolution")
for domain, ips in dns_results.items():
    if ips == "GAGAL":
        print(f"  ❌ {domain}: GAGAL")
    else:
        print(f"  ✅ {domain} → {ips}")

# Summary
print()
print("---")
print("📋 Ringkasan")
gw_issues = sum(1 for k, v in gw_map.items() if "status" in k and v != "0" and v != "?")
ping_issues = 0
ping_blocked = 0
for cat_results in ping_results.values():
    for host, (label, loss, avg, status) in cat_results.items():
        if "HTTP" in label and status == "timeout":
            ping_issues += 1
        elif status == "blocked":
            ping_blocked += 1
        elif status == "timeout" or (loss is not None and loss > 0):
            ping_issues += 1

if gw_issues == 0 and ping_issues == 0:
    print("  ✅ Semua gateway UP, latensi normal, 0% packet loss")
    if bw_data:
        peak_wans = [w for w, mbps in bw_data.items() if mbps > 200]
        if peak_wans:
            print(f"  ⚠️ Load tinggi di: {', '.join(peak_wans)} — possible congestion")
else:
    if gw_issues:
        print(f"  🔴 {gw_issues} gateway bermasalah")
    if ping_issues:
        print(f"  🔴 {ping_issues} target latency/packet loss issue")
    if ping_blocked:
        print(f"  ⬜ {ping_blocked} target ICMP blocked (normal)")
