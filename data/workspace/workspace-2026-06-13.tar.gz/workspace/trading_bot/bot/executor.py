"""
TRADING BOT EXECUTOR
Module untuk eksekusi order berdasarkan sinyal AI
"""
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
import json, os, time
from datetime import datetime, timedelta

SYMBOL = "XAUUSDm"
MAGIC = 20260610
STATE_FILE = r"C:\TradingBot\executor_state.json"

# ──── RISK CONFIG ────
RISK_PCT = 0.5         # 0.5% risk per trade
SL_ATR = 1.5           # Stop Loss = 1.5x ATR
TP_ATR = 3.0           # Take Profit = 3.0x ATR (R:R = 2:1)
MAX_POSITIONS = 1       # Max concurrent positions
DAILY_LOSS_LIMIT_PCT = 3.0  # Stop trading if daily loss > 3%
MIN_CONFIDENCE = 65     # Minimum confidence % to execute (default)
MIN_CONFIDENCE_HIGH = 75  # Minimum for high-confidence tier
LOT_SIZES = {'LOW': 0.01, 'MED': 0.02, 'HIGH': 0.05}

# ──── STATE ────
def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except:
        return {"daily_pnl": 0.0, "trades_today": 0, "last_trade_date": "", "mode": "demo"}

def save_state(s):
    with open(STATE_FILE, "w") as f:
        json.dump(s, f, indent=2)

# ──── CONNECT ────
def log_func(msg):
    pass  # Will be replaced by actual log function
    if not mt5.initialize():
        print(f"MT5 init failed: {mt5.last_error()}")
        return False
    info = mt5.account_info()
    if info is None:
        print("MT5 login failed")
        return False
    print(f"Connected: {info.login} | Balance: ${info.balance:.0f} | Equity: ${info.equity:.0f}")
    return True

# ──── GET ATR ────
def get_atr():
    rates = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M1, 0, 100)
    if rates is None:
        return None
    df = pd.DataFrame(rates)
    hl = df['high'] - df['low']
    hc = np.abs(df['high'] - df['close'].shift())
    lc = np.abs(df['low'] - df['close'].shift())
    tr = np.maximum(hl, np.maximum(hc, lc))
    atr = tr.ewm(span=14, adjust=False).mean().iloc[-1]
    return atr

# ──── POSITION SIZING ────
def calc_lot_size(signal_price, atr, confidence):
    """Calculate lot size based on risk % and SL distance"""
    account = mt5.account_info()
    if account is None:
        return 0.01
    
    balance = account.balance
    risk_amount = balance * (RISK_PCT / 100)
    
    # SL distance in points (ATR * multiplier)
    sl_distance = atr * SL_ATR
    
    # Get symbol info for pip value
    symbol_info = mt5.symbol_info(SYMBOL)
    if symbol_info is None:
        return 0.01
    
    point = symbol_info.point
    sl_points = sl_distance / point
    
    # Calculate lot
    tick_value = symbol_info.trade_tick_value
    tick_size = symbol_info.trade_tick_size
    
    if tick_value and tick_size and tick_size > 0:
        lot = risk_amount / (sl_points * tick_value / tick_size)
    else:
        # Fallback: estimate
        lot = risk_amount / (sl_distance * 100)
    
    # Round to valid lot step
    lot_step = symbol_info.volume_step
    lot = round(lot / lot_step) * lot_step
    
    # Clamp
    lot_min = symbol_info.volume_min
    lot_max = symbol_info.volume_max
    lot = max(lot_min, min(lot_max, lot))
    
    # Round to 2 decimals
    lot = round(lot, 2)
    
    return max(lot, 0.01)

# ──── CHECK EXISTING POSITIONS ────
def count_positions():
    positions = mt5.positions_get(symbol=SYMBOL)
    if positions is None:
        return 0
    return len([p for p in positions if p.magic == MAGIC])

def get_open_positions():
    positions = mt5.positions_get(symbol=SYMBOL)
    if positions is None:
        return []
    return [p for p in positions if p.magic == MAGIC]

# ──── DAILY P&L CHECK ────
def check_daily_loss():
    state = load_state()
    today = datetime.now().strftime("%Y-%m-%d")
    
    if state["last_trade_date"] != today:
        state["daily_pnl"] = 0.0
        state["trades_today"] = 0
        state["last_trade_date"] = today
        save_state(state)
    
    account = mt5.account_info()
    if account is None:
        return False
    
    if account.balance > 0:
        daily_loss_pct = abs(state["daily_pnl"]) / account.balance * 100
        if state["daily_pnl"] < 0 and daily_loss_pct >= DAILY_LOSS_LIMIT_PCT:
            return True  # Hit daily loss limit
    
    return False

# ──── EXECUTE ORDER ────
def execute_signal(signal_type, signal_price, confidence, atr, log_func=print):
    """Execute a trade based on AI signal"""
    
    # 1. Check mode
    state = load_state()
    mode = state.get("mode", "demo")
    
    # 2. Check daily loss limit
    if check_daily_loss():
        log_func(f"⛔ Daily loss limit ({DAILY_LOSS_LIMIT_PCT}%) hit — skipping trade")
        return None
    
    # 3. Check existing positions
    open_pos = count_positions()
    if open_pos >= MAX_POSITIONS:
        log_func(f"⏭️ Already {open_pos} position(s) open — skip")
        return None
    
    # 4. Check confidence
    if confidence < MIN_CONFIDENCE:
        log_func(f"⏭️ Confidence {confidence:.1f}% below min {MIN_CONFIDENCE}% — skip")
        return None
    
    # 5. Calculate lot size
    lot = calc_lot_size(signal_price, atr, confidence)
    
    # 6. Calculate SL/TP
    sl_distance = atr * SL_ATR
    tp_distance = atr * TP_ATR
    
    if signal_type == "BUY":
        order_type = mt5.ORDER_TYPE_BUY
        sl = signal_price - sl_distance
        tp = signal_price + tp_distance
    else:
        order_type = mt5.ORDER_TYPE_SELL
        sl = signal_price + sl_distance
        tp = signal_price - tp_distance
    
    # Round prices to symbol digits
    symbol_info = mt5.symbol_info(SYMBOL)
    digits = symbol_info.digits if symbol_info else 2
    price = mt5.symbol_info_tick(SYMBOL).ask if signal_type == "BUY" else mt5.symbol_info_tick(SYMBOL).bid
    sl = round(sl, digits)
    tp = round(tp, digits)
    
    # 7. Place order
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": lot,
        "type": order_type,
        "price": price,
        "sl": sl,
        "tp": tp,
        "deviation": 20,
        "magic": MAGIC,
        "comment": f"AI_{signal_type}_{confidence:.0f}",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    # Check order
    check = mt5.order_check(request)
    if check is None:
        log_func(f"❌ Order check failed: {mt5.last_error()}")
        return None
    
    if check.retcode != 0:
        log_func(f"❌ Order check: {check.comment}")
        return None
    
    # Execute
    result = mt5.order_send(request)
    if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
        error = mt5.last_error()
        log_func(f"❌ Order failed: {error}")
        return None
    
    log_func(f"✅ {signal_type} EXECUTED | Lot={lot} | Price={price:.2f} | SL={sl:.2f} | TP={tp:.2f} | Conf={confidence:.0f}%")
    
    # 8. Update state
    state["trades_today"] += 1
    state["last_trade_date"] = datetime.now().strftime("%Y-%m-%d")
    save_state(state)
    
    return result

# ──── CLOSE POSITION ────
def close_position(position, log_func=print):
    """Close a specific position"""
    symbol_info = mt5.symbol_info(SYMBOL)
    
    if position.type == mt5.POSITION_TYPE_BUY:
        order_type = mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(SYMBOL).bid
    else:
        order_type = mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(SYMBOL).ask
    
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": position.volume,
        "type": order_type,
        "position": position.ticket,
        "price": price,
        "deviation": 20,
        "magic": MAGIC,
        "comment": "AI_Close",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    result = mt5.order_send(request)
    if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
        log_func(f"❌ Close failed: {mt5.last_error()}")
        return False
    
    profit = position.profit
    log_func(f"✅ Closed #{position.ticket} | Profit: ${profit:.2f}")
    
    # Update daily P&L
    state = load_state()
    state["daily_pnl"] = state.get("daily_pnl", 0) + profit
    save_state(state)
    
    return True

# ──── POSITION MONITOR (trailing stop) ────
def check_trailing_stop(atr, log_func=print):
    """Check if open positions need trailing stop update"""
    positions = get_open_positions()
    if not positions:
        return
    
    for pos in positions:
        current_price = mt5.symbol_info_tick(SYMBOL).bid if pos.type == mt5.POSITION_TYPE_BUY else mt5.symbol_info_tick(SYMBOL).ask
        
        # Calculate new SL based on trailing (1.5x ATR from current price)
        trail_distance = atr * SL_ATR
        if pos.type == mt5.POSITION_TYPE_BUY:
            new_sl = current_price - trail_distance
            if new_sl > pos.sl:  # Only move SL up for BUY
                request = {
                    "action": mt5.TRADE_ACTION_SLTP,
                    "symbol": SYMBOL,
                    "position": pos.ticket,
                    "sl": round(new_sl, 2),
                    "tp": pos.tp,
                }
                mt5.order_send(request)
                log_func(f"🔒 Trailing SL updated: {pos.sl:.2f} → {new_sl:.2f}")
        else:
            new_sl = current_price + trail_distance
            if new_sl < pos.sl:  # Only move SL down for SELL
                request = {
                    "action": mt5.TRADE_ACTION_SLTP,
                    "symbol": SYMBOL,
                    "position": pos.ticket,
                    "sl": round(new_sl, 2),
                    "tp": pos.tp,
                }
                mt5.order_send(request)
                log_func(f"🔒 Trailing SL updated: {pos.sl:.2f} → {new_sl:.2f}")

# ──── DAILY SUMMARY ────
def daily_summary(log_func=print):
    """Print daily trading summary"""
    state = load_state()
    account = mt5.account_info()
    if account:
        log_func(f"📊 Daily: {state['trades_today']} trades | P&L: ${state.get('daily_pnl', 0):.2f} | Balance: ${account.balance:.0f} | Equity: ${account.equity:.0f}")

# ──── SET MODE ────
def set_mode(mode):
    """mode: 'demo' or 'real'"""
    state = load_state()
    state["mode"] = mode
    save_state(state)
    print(f"Executor mode set to: {mode}")

def is_demo():
    state = load_state()
    return state.get("mode", "demo") == "demo"

if __name__ == "__main__":
    print("Executor module loaded.")
    print("Functions: execute_signal(), close_position(), check_trailing_stop(), daily_summary()")
