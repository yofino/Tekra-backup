"""
Download XAUUSD M1 historical data from Dukascopy (free, no login)
Downloads .bi5 files and converts to CSV
"""
import requests
import struct
import os
import pandas as pd
from datetime import datetime, timedelta, date as dt_date

OUT_DIR = r"C:\TradingBot\data"

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def download_bi5(year, month, day, symbol="XAUUSD"):
    """Download a single .bi5 file from Dukascopy"""
    url = f"https://www.dukascopy.com/datafeed/{symbol}/{year}/{month:02d}/{day:02d}/BID_candles_min_1.bi5"
    try:
        r = requests.get(url, timeout=10)
        if r.status_code == 200:
            return r.content
    except:
        pass
    return None

def parse_bi5(data):
    """Parse .bi5 candle data to list of [time, open, high, low, close]"""
    rows = []
    if not data:
        return rows
    
    # .bi5 format: [timestamp(u32 big-endian), open(u32), high(u32), low(u32), close(u32)] * N
    # All prices are in points (multiply by point_size)
    chunk_size = 5 * 4  # 5 values * 4 bytes
    
    for i in range(0, len(data) - chunk_size + 1, chunk_size):
        try:
            chunk = data[i:i+chunk_size]
            ts, o, h, l, c = struct.unpack('>IIIII', chunk)
            # Convert timestamp (milliseconds) to datetime
            dt = datetime.utcfromtimestamp(ts / 1000)
            rows.append([dt, o, h, l, c])
        except:
            break
    return rows

def convert_to_csv(rows, point_size=0.00001):
    """Convert raw points to actual prices and return DataFrame"""
    df = pd.DataFrame(rows, columns=['time', 'open', 'high', 'low', 'close'])
    for col in ['open', 'high', 'low', 'close']:
        df[col] = df[col] * point_size
    df['tick_volume'] = 1  # Dukascopy doesn't provide volume for free
    df['spread'] = 0
    df['real_volume'] = 0
    return df

def download_range(start_date, end_date):
    """Download data for a date range, save to CSV"""
    os.makedirs(OUT_DIR, exist_ok=True)
    
    current = start_date
    all_dfs = []
    successful_days = 0
    failed_days = 0
    
    while current < end_date:
        log(f"Downloading {current.strftime('%Y-%m-%d')}...")
        data = download_bi5(current.year, current.month, current.day)
        
        if data:
            rows = parse_bi5(data)
            if rows:
                df = convert_to_csv(rows)
                all_dfs.append(df)
                successful_days += 1
        
        current += timedelta(days=1)
        
        # Progress every 30 days
        if successful_days % 30 == 0 and successful_days > 0:
            log(f"  Progress: {successful_days} days ok, {failed_days} failed")
    
    if all_dfs:
        big_df = pd.concat(all_dfs)
        big_df.sort_values('time', inplace=True)
        big_df.drop_duplicates(subset=['time'], inplace=True)
        
        out_path = os.path.join(OUT_DIR, "xauusd_historical_m1.csv")
        big_df.to_csv(out_path, index=False)
        log(f"\nComplete: {len(big_df)} rows saved to {out_path}")
        log(f"Range: {big_df['time'].iloc[0]} to {big_df['time'].iloc[-1]}")
        log(f"Successful days: {successful_days}, Failed: {failed_days}")
    else:
        log("No data downloaded!")

if __name__ == "__main__":
    log("===== DUKASCOPY DOWNLOAD =====")
    
    # Download last 2 years of data
    end = dt_date.today()
    start = end - timedelta(days=730)  # 2 years
    log(f"Range: {start} to {end}")
    
    download_range(start, end)
