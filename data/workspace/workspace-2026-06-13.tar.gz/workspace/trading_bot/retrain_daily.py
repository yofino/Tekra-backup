"""
DAILY RETRAIN - Retrain XGBoost every day with new data
"""
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pickle, json, os, glob
from datetime import datetime, timedelta

SYMBOL = "XAUUSDm"
DATA_DIR = r"C:\TradingBot\data"
MODEL_DIR = r"C:\TradingBot\models"
HISTORY_FILE = r"C:\TradingBot\models\training_history.json"
TODAY = datetime.now().strftime("%Y%m%d")

def log(msg):
    t = datetime.now().strftime("%H:%M:%S")
    print(f"[{t}] {msg}")

log("===== DAILY RETRAIN =====")

# 1. Load all CSV data
log("Loading data...")
all_files = glob.glob(os.path.join(DATA_DIR, "xauusd_*.csv"))
all_files.sort()

dfs = []
for f in all_files:
    try:
        df = pd.read_csv(f)
        dfs.append(df)
    except:
        pass

if not dfs:
    log("No data found!")
    exit()

df_all = pd.concat(dfs)
df_all['time'] = pd.to_datetime(df_all['time'])
df_all = df_all.drop_duplicates(subset=['time'])
df_all.set_index('time', inplace=True)
df_all.sort_index(inplace=True)

log(f"Loaded {len(df_all)} total candles ({df_all.index[0]} to {df_all.index[-1]})")

# 2. Feature engineering (same as train_v2)
df = df_all.copy()
df['returns'] = df['close'].pct_change()
df['hl_range'] = (df['high'] - df['low']) / df['close']
df['close_pos'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 0.0001)
df['body'] = (df['close'] - df['open']).abs() / (df['high'] - df['low'] + 0.0001)
df['direction'] = np.where(df['close'] > df['open'], 1, -1)
df['MA_9'] = df['close'].rolling(9).mean()
df['MA_21'] = df['close'].rolling(21).mean()
df['MA_50'] = df['close'].rolling(50).mean()
df['MA_200'] = df['close'].rolling(200).mean()
df['dist_ma9'] = (df['close'] - df['MA_9']) / df['close']
df['dist_ma21'] = (df['close'] - df['MA_21']) / df['close']
df['dist_ma50'] = (df['close'] - df['MA_50']) / df['close']
df['ma9_slope'] = df['MA_9'].pct_change(5)
df['ma21_slope'] = df['MA_21'].pct_change(5)
delta = df['close'].diff()
gain = delta.clip(lower=0)
loss = -delta.clip(upper=0)
avg_gain = gain.ewm(span=14, adjust=False).mean()
avg_loss = loss.ewm(span=14, adjust=False).mean()
rs = avg_gain / avg_loss.replace(0, np.nan)
df['RSI'] = 100 - (100 / (1 + rs))
df['RSI_change'] = df['RSI'].diff(5)
w = 20
df['BB_mid'] = df['close'].rolling(w).mean()
std = df['close'].rolling(w).std()
df['BB_upper'] = df['BB_mid'] + 2*std
df['BB_lower'] = df['BB_mid'] - 2*std
df['BB_width'] = (df['BB_upper'] - df['BB_lower']) / df['BB_mid']
df['BB_pos'] = (df['close'] - df['BB_mid']) / (df['BB_upper'] - df['BB_lower'] + 0.0001)
ema12 = df['close'].ewm(span=12, adjust=False).mean()
ema26 = df['close'].ewm(span=26, adjust=False).mean()
df['MACD'] = ema12 - ema26
df['MACD_signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
df['MACD_hist'] = (df['MACD'] - df['MACD_signal']) / df['close']
hl = df['high'] - df['low']
hc = np.abs(df['high'] - df['close'].shift())
lc = np.abs(df['low'] - df['close'].shift())
tr = np.maximum(hl, np.maximum(hc, lc))
df['ATR'] = tr.ewm(span=14, adjust=False).mean()
df['ATR_pct'] = df['ATR'] / df['close']
df['vol_ma20'] = df['tick_volume'].rolling(20).mean()
df['vol_ratio'] = df['tick_volume'] / (df['vol_ma20'] + 1)
for p in [3,5,10,20]:
    df[f'mom_{p}'] = df['close'].pct_change(p)
df['volatility'] = df['returns'].rolling(10).std()
df['hour'] = df.index.hour
df['dow'] = df.index.dayofweek
df['session'] = 0
df.loc[(df['hour'] >= 8) & (df['hour'] < 16), 'session'] = 1
df.loc[(df['hour'] >= 13) & (df['hour'] < 21), 'session'] = 2

# Label: direction 60min ahead
future_close = df['close'].shift(-60)
df['target'] = ((future_close - df['close']) / df['close'] > 0.0005).astype(int)

feature_cols = [
    'returns', 'hl_range', 'close_pos', 'body', 'direction',
    'dist_ma9', 'dist_ma21', 'dist_ma50', 'ma9_slope', 'ma21_slope',
    'RSI', 'RSI_change', 'BB_width', 'BB_pos', 'MACD_hist',
    'ATR_pct', 'vol_ratio', 'mom_3', 'mom_5', 'mom_10', 'mom_20',
    'volatility', 'hour', 'dow', 'session'
]

# 3. Train
data = df.dropna(subset=feature_cols + ['target'])
X = data[feature_cols]
y = data['target']

split = int(len(X) * 0.75)
X_tr, X_va = X.iloc[:split], X.iloc[split:]
y_tr, y_va = y.iloc[:split], y.iloc[split:]

scale_pos = (len(y_tr) - y_tr.sum()) / (y_tr.sum() + 1)

log(f"Train: {len(X_tr)}, Val: {len(X_va)}, ScalePos: {scale_pos:.2f}")

model = xgb.XGBClassifier(
    n_estimators=300, max_depth=6, learning_rate=0.03,
    subsample=0.75, colsample_bytree=0.75,
    min_child_weight=5, gamma=0.2, reg_alpha=0.5, reg_lambda=1.5,
    scale_pos_weight=scale_pos, random_state=42
)
model.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)

# 4. Evaluate
y_pred = model.predict(X_va)
y_proba = model.predict_proba(X_va)[:, 1]

acc = accuracy_score(y_va, y_pred)
prec = precision_score(y_va, y_pred, zero_division=0)
rec = recall_score(y_va, y_pred, zero_division=0)
f1v = f1_score(y_va, y_pred, zero_division=0)

# Find best threshold
best_f1, best_t = 0, 0.5
for t in np.arange(0.25, 0.7, 0.05):
    yt = (y_proba >= t).astype(int)
    ft = f1_score(y_va, yt, zero_division=0)
    if ft > best_f1: best_f1, best_t = ft, t

log(f"\n=== MODEL V{datetime.now().strftime('%Y%m%d')} ===")
log(f"Accuracy:   {acc:.4f} ({acc*100:.1f}%)")
log(f"Precision:  {prec:.4f}")
log(f"Recall:     {rec:.4f}")
log(f"F1:         {f1v:.4f}")
log(f"Best thresh: {best_t:.2f} (F1={best_f1:.4f})")
log(f"Data rows:   {len(df_all)}")

# 5. Save model
os.makedirs(MODEL_DIR, exist_ok=True)

# Save with date
model_file = os.path.join(MODEL_DIR, f"xgboost_{TODAY}.pkl")
with open(model_file, 'wb') as f:
    pickle.dump({'model': model, 'features': feature_cols, 'threshold': best_t}, f)

# Also save as "latest" (overwrites)
latest_file = os.path.join(MODEL_DIR, "xgboost_latest.pkl")
with open(latest_file, 'wb') as f:
    pickle.dump({'model': model, 'features': feature_cols, 'threshold': best_t}, f)

log(f"Saved: {model_file}")
log(f"Saved: {latest_file}")

# 6. Save training history for dashboard
history = []
if os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE) as f:
        history = json.load(f)

history.append({
    'date': TODAY,
    'accuracy': round(acc * 100, 1),
    'precision': round(prec * 100, 1),
    'recall': round(rec * 100, 1),
    'f1': round(f1v, 3),
    'best_threshold': round(best_t, 2),
    'data_rows': len(df_all),
    'train_samples': len(X_tr),
    'val_samples': len(X_va)
})

with open(HISTORY_FILE, 'w') as f:
    json.dump(history, f, indent=2)

log(f"Training history saved: {HISTORY_FILE}")
log(f"History records: {len(history)}")

# 7. Update bot to use latest model
bot_config = os.path.join(os.path.dirname(MODEL_DIR), "bot_v3_ai.py")
if os.path.exists(bot_config):
    with open(bot_config) as f:
        bot_code = f.read()
    # Update MODEL_PATH to use latest
    if "MODEL_PATH = r" in bot_code:
        old_path = bot_code.split("MODEL_PATH = r")[1].split("\n")[0]
        bot_code = bot_code.replace(f"MODEL_PATH = r{old_path}", f'MODEL_PATH = r"{latest_file}"')
        with open(bot_config, 'w') as f:
            f.write(bot_code)
        log("Bot model path updated to latest")

log("\n===== DONE =====")
log(f"Model v{TODAY}: {acc*100:.1f}% accuracy on {len(df_all)} candles")
