"""
RETRAIN ALL - MT5 M5 + Live M1 + 2yr Hourly + 5yr Daily
"""
import MetaTrader5 as mt5, pandas as pd, numpy as np, xgboost as xgb
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pickle, os, glob
from datetime import datetime, timedelta

SYMBOL="XAUUSDm"
DATA_DIR=r"C:\TradingBot\data"
MODEL_DIR=r"C:\TradingBot\models"
NOW=datetime.now().strftime("%Y%m%d_%H%M")

def log(msg): print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

log("===== RETRAIN ALL DATA =====")
all_dfs=[]

# 1. MT5 M5
log("1. MT5 M5...")
mt5.initialize()
rates=mt5.copy_rates_range(SYMBOL,mt5.TIMEFRAME_M5,datetime.now()-timedelta(days=90),datetime.now())
mt5.shutdown()
if rates is not None:
    df=pd.DataFrame(rates); df['time']=pd.to_datetime(df['time'],unit='s'); df.set_index('time',inplace=True)
    log(f"   {len(df)} candles"); all_dfs.append(df)

# 2. Live M1->M5
log("2. Live M1->M5...")
for f in sorted(glob.glob(os.path.join(DATA_DIR,"xauusd_2026*.csv"))):
    df=pd.read_csv(f); df['time']=pd.to_datetime(df['time'],format='mixed'); df.set_index('time',inplace=True)
    df5=df.resample('5min').agg({'open':'first','high':'max','low':'min','close':'last','tick_volume':'sum','spread':'mean'}).dropna()
    log(f"   {os.path.basename(f)}: {len(df)}->{len(df5)} M5"); all_dfs.append(df5)

# 3. Historical 1h -> M5
hp=os.path.join(DATA_DIR,"xauusd_historical_1h.csv")
if os.path.exists(hp):
    log("3. 2yr Hourly->M5...")
    df=pd.read_csv(hp); df['time']=pd.to_datetime(df['time'],utc=True).dt.tz_localize(None)
    df.set_index('time',inplace=True); df.sort_index(inplace=True)
    for c in ['tick_volume','spread']:
        if c not in df.columns: df[c]=1 if c=='tick_volume' else 0
    df5=df.resample('5min').agg({'open':'first','high':'max','low':'min','close':'last','tick_volume':'sum','spread':'mean'}).ffill().dropna()
    log(f"   {len(df)}->{len(df5)} M5"); all_dfs.append(df5)

# 4. 5yr Daily -> M5
dp=os.path.join(DATA_DIR,"xauusd_5y_daily.csv")
if os.path.exists(dp):
    log("4. 5yr Daily->M5...")
    df=pd.read_csv(dp); df['time']=pd.to_datetime(df['time'],utc=True).dt.tz_localize(None)
    df.set_index('time',inplace=True); df.sort_index(inplace=True)
    for c in ['tick_volume','spread']:
        if c not in df.columns: df[c]=1 if c=='tick_volume' else 0
    df5=df.resample('5min').agg({'open':'first','high':'max','low':'min','close':'last','tick_volume':'sum','spread':'mean'}).ffill().dropna()
    log(f"   {len(df)}->{len(df5)} M5"); all_dfs.append(df5)

# Combine
df=pd.concat(all_dfs); df=df[~df.index.duplicated(keep='first')]; df.sort_index(inplace=True)
log(f"TOTAL: {len(df)} M5 ({df.index[0]} to {df.index[-1]})")

# Features
log("Features...")
df['returns']=df['close'].pct_change()
df['hl_range']=(df['high']-df['low'])/df['close']
df['close_pos']=(df['close']-df['low'])/(df['high']-df['low']+0.0001)
df['body']=(df['close']-df['open']).abs()/(df['high']-df['low']+0.0001)
df['direction']=np.where(df['close']>df['open'],1,-1)
for p in [9,21,50]:
    ma=df['close'].rolling(p).mean(); df[f'dist_ma{p}']=(df['close']-ma)/df['close']; df[f'ma{p}_slope']=ma.pct_change(p)
delta=df['close'].diff(); gain=delta.clip(lower=0); loss=-delta.clip(upper=0)
df['RSI']=100-(100/(1+(gain.ewm(14,adjust=False).mean()/loss.ewm(14,adjust=False).mean().replace(0,np.nan))))
df['RSI_change']=df['RSI'].diff(5)
mid=df['close'].rolling(20).mean(); std=df['close'].rolling(20).std()
df['BB_width']=(2*std)/mid; df['BB_pos']=(df['close']-mid)/(2*std+0.0001)
ema12=df['close'].ewm(12,adjust=False).mean(); ema26=df['close'].ewm(26,adjust=False).mean()
df['MACD_hist']=((ema12-ema26)-(ema12-ema26).ewm(9,adjust=False).mean())/df['close']
hl=df['high']-df['low'];hc=np.abs(df['high']-df['close'].shift());lc=np.abs(df['low']-df['close'].shift())
df['ATR_pct']=np.maximum(hl,np.maximum(hc,lc)).ewm(14,adjust=False).mean()/df['close']
for p in [3,5,10,20]: df[f'mom_{p}']=df['close'].pct_change(p)
df['volatility']=df['returns'].rolling(10).std()
df['hour']=df.index.hour; df['dow']=df.index.dayofweek
df['session']=0; df.loc[(df['hour']>=8)&(df['hour']<16),'session']=1; df.loc[(df['hour']>=13)&(df['hour']<21),'session']=2
future=df['close'].shift(-12); df['target']=((future-df['close'])/df['close']>0.001).astype(int)

features=['returns','hl_range','close_pos','body','direction',
    'dist_ma9','dist_ma21','dist_ma50','ma9_slope','ma21_slope',
    'RSI','RSI_change','BB_width','BB_pos','MACD_hist',
    'ATR_pct','mom_3','mom_5','mom_10','mom_20',
    'volatility','hour','dow','session']

# Train
data=df.dropna(subset=features+['target'])
X,y=data[features],data['target']
split=int(len(X)*0.75); X_tr,X_va=X.iloc[:split],X.iloc[split:]; y_tr,y_va=y.iloc[:split],y.iloc[split:]
sp=(len(y_tr)-y_tr.sum())/(y_tr.sum()+1)
log(f"Train:{len(X_tr)} Val:{len(X_va)} Scale:{sp:.1f} Buy%:{y_tr.mean()*100:.1f}%")

model=xgb.XGBClassifier(n_estimators=300,max_depth=6,learning_rate=0.03,subsample=0.75,colsample_bytree=0.75,
    min_child_weight=5,gamma=0.2,reg_alpha=0.5,reg_lambda=1.5,scale_pos_weight=sp,random_state=42)
model.fit(X_tr,y_tr,eval_set=[(X_va,y_va)],verbose=False)

y_pred=model.predict(X_va); y_proba=model.predict_proba(X_va)[:,1]
acc=accuracy_score(y_va,y_pred); prec=precision_score(y_va,y_pred,zero_division=0)
rec=recall_score(y_va,y_pred,zero_division=0); f1v=f1_score(y_va,y_pred,zero_division=0)

best_f1,best_t=0,0.5
for t in np.arange(0.25,0.7,0.05):
    yt=(y_proba>=t).astype(int); ft=f1_score(y_va,yt,zero_division=0)
    if ft>best_f1: best_f1,best_t=ft,t

log(f"\n{'='*50}")
log(f"RESULT")
log(f"Accuracy:{acc*100:.1f}% Prec:{prec*100:.1f}% Rec:{rec*100:.1f}% F1:{f1v:.3f}")
log(f"Best t={best_t:.2f} F1={best_f1:.3f}")
log(f"Data:{len(df)} M5 candles")
log(f"\nProgress:")
log(f"  V2 (MT5 only):      Acc=59.7% F1=0.346")
log(f"  V3 (+2yr hourly):   Acc=67.5% F1=0.451")
log(f"  V4 (+5yr daily):    Acc={acc*100:.1f}% F1={f1v:.3f}")

if f1v>0.30:
    os.makedirs(MODEL_DIR,exist_ok=True)
    path=os.path.join(MODEL_DIR,f"xgboost_v4_{NOW}.pkl")
    with open(path,'wb') as f: pickle.dump({'model':model,'features':features,'threshold':best_t},f)
    log(f"SAVED: {path}")
    log(f"Deploy: update bot_v3_ai.py MODEL_PATH to this file")
else:
    log("NOT SAVED")
