"""
Download 5 years XAUUSD historical data from Yahoo Finance
Free, no API key needed
"""
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
import os

OUT_DIR = r"C:\TradingBot\data"

log = lambda msg: print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

log("===== DOWNLOAD XAUUSD 5 YEAR DATA =====")

# XAUUSD from Yahoo Finance
log("Downloading GC=F (Gold Futures, 5 years, daily)...")
gold = yf.download("GC=F", period="5y", interval="1d")

if not gold.empty:
    log(f"Downloaded {len(gold)} daily candles")

# Format like our CSV
df = pd.DataFrame()
df['time'] = gold.index
df['open'] = gold['Open'].values
df['high'] = gold['High'].values
df['low'] = gold['Low'].values
df['close'] = gold['Close'].values
df['tick_volume'] = gold['Volume'].fillna(0).values
df['spread'] = 0  # Yahoo doesn't have spread data
df['real_volume'] = 0

os.makedirs(OUT_DIR, exist_ok=True)
out_path = os.path.join(OUT_DIR, "xauusd_historical_5y.csv")
df.to_csv(out_path, index=False)

log(f"Saved: {out_path}")
log(f"Size: {os.path.getsize(out_path):,} bytes")

# Also download daily for overview
log("Downloading daily data...")
gold_d = yf.download("XAUUSD=X", period="5y", interval="1d")

if not gold_d.empty:
    d_path = os.path.join(OUT_DIR, "xauusd_daily_5y.csv")
    df_d = pd.DataFrame()
    df_d['time'] = gold_d.index
    df_d['open'] = gold_d['Open'].values
    df_d['high'] = gold_d['High'].values
    df_d['low'] = gold_d['Low'].values
    df_d['close'] = gold_d['Close'].values
    df_d.to_csv(d_path, index=False)
    log(f"Daily saved: {d_path} ({len(df_d)} days)")

log("===== DONE =====")
