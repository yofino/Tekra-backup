"""
RETRAIN M5 - Use MT5 M5 data + resampled live M1 data
Same approach as the original successful V2 training
"""
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pickle, json, os, glob
from datetime import datetime, timedelta

SYMBOL = "XAUUSDm"
DATA_DIR = r"C:\TradingBot\data"
MODEL_DIR = r"C:\TradingBot\models"
NOW = datetime.now().strftime("%Y%m%d_%H%M")

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

log("===== RETRAIN M5 =====")

# 1. Fetch M5 data from MT5
log("Fetching MT5 M5 data (90 days)...")
mt5.initialize()
end = datetime.now()
start = end - timedelta(days=90)
rates = mt5.copy_rates_range(SYMBOL, mt5.TIMEFRAME_M5, start, end)
mt5.shutdown()

if rates is None:
    log("Failed to fetch MT5 data")
    exit()

df_mt5 = pd.DataFrame(rates)
df_mt5['time'] = pd.to_datetime(df_mt5['time'], unit='s')
df_mt5.set_index('time', inplace=True)
log(f"MT5 data: {len(df_mt5)} M5 candles")

# 2. Load live CSV data AND historical 1h data, resample to M5
log("Loading CSV data...")
csv_files = sorted(glob.glob(os.path.join(DATA_DIR, "xauusd_2026*.csv")))
dfs = []
for f in csv_files:
    df = pd.read_csv(f)
    df['time'] = pd.to_datetime(df['time'], format='mixed')
    dfs.append(df)

# Also load historical 1h data if exists
hist1h_path = os.path.join(DATA_DIR, "xauusd_historical_1h.csv")
if os.path.exists(hist1h_path):
    df_hist = pd.read_csv(hist1h_path)
    df_hist['time'] = pd.to_datetime(df_hist['time'])
    # Drop UTC timezone info for consistency
    if hasattr(df_hist['time'].iloc[0], 'tz'):
        df_hist['time'] = df_hist['time'].dt.tz_localize(None)
    log(f"Historical 1h: {len(df_hist)} candles")
    dfs.append(df_hist)

if dfs:
    df_live = pd.concat(dfs)
    df_live.set_index('time', inplace=True)
    df_live = df_live[~df_live.index.duplicated(keep='first')]
    df_live.sort_index(inplace=True)
    log(f"Live raw: {len(df_live)} M1 candles")
    
    # Resample M1 to M5
    df_live_m5 = df_live.resample('5min').agg({
        'open': 'first', 'high': 'max', 'low': 'min',
        'close': 'last', 'tick_volume': 'sum', 'spread': 'mean'
    }).dropna()
    log(f"Live resampled: {len(df_live_m5)} M5 candles")
    
    # Combine
    df_all = pd.concat([df_mt5, df_live_m5])
    df_all = df_all[~df_all.index.duplicated(keep='first')]
    df_all.sort_index(inplace=True)
else:
    df_all = df_mt5

df = df_all
log(f"Total: {len(df)} M5 candles ({df.index[0]} to {df.index[-1]})")

# 3. Feature engineering (same as V2 training)
log("Feature engineering...")
df['returns'] = df['close'].pct_change()
df['hl_range'] = (df['high'] - df['low']) / df['close']
df['close_pos'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 0.0001)
df['body'] = (df['close'] - df['open']).abs() / (df['high'] - df['low'] + 0.0001)
df['direction'] = np.where(df['close'] > df['open'], 1, -1)
df['MA_9'] = df['close'].rolling(9).mean()
df['MA_21'] = df['close'].rolling(21).mean()
df['MA_50'] = df['close'].rolling(50).mean()
df['dist_ma9'] = (df['close'] - df['MA_9']) / df['close']
df['dist_ma21'] = (df['close'] - df['MA_21']) / df['close']
df['dist_ma50'] = (df['close'] - df['MA_50']) / df['close']
df['ma9_slope'] = df['MA_9'].pct_change(5)
df['ma21_slope'] = df['MA_21'].pct_change(5)
delta = df['close'].diff()
gain = delta.clip(lower=0); loss = -delta.clip(upper=0)
avg_gain = gain.ewm(span=14, adjust=False).mean()
avg_loss = loss.ewm(span=14, adjust=False).mean()
rs = avg_gain / avg_loss.replace(0, np.nan)
df['RSI'] = 100 - (100 / (1 + rs))
df['RSI_change'] = df['RSI'].diff(5)
w = 20
df['BB_mid'] = df['close'].rolling(w).mean()
std = df['close'].rolling(w).std()
df['BB_upper'] = df['BB_mid'] + 2*std
df['BB_lower'] = df['BB_mid'] - 2*std
df['BB_width'] = (df['BB_upper'] - df['BB_lower']) / df['BB_mid']
df['BB_pos'] = (df['close'] - df['BB_mid']) / (df['BB_upper'] - df['BB_lower'] + 0.0001)
ema12 = df['close'].ewm(span=12, adjust=False).mean()
ema26 = df['close'].ewm(span=26, adjust=False).mean()
df['MACD'] = ema12 - ema26
df['MACD_signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
df['MACD_hist'] = (df['MACD'] - df['MACD_signal']) / df['close']
hl = df['high']-df['low']; hc = np.abs(df['high']-df['close'].shift()); lc = np.abs(df['low']-df['close'].shift())
tr = np.maximum(hl, np.maximum(hc, lc))
df['ATR'] = tr.ewm(span=14, adjust=False).mean()
df['ATR_pct'] = df['ATR'] / df['close']
df['vol_ma20'] = df['tick_volume'].rolling(20).mean()
df['vol_ratio'] = df['tick_volume'] / (df['vol_ma20'] + 1)
for p in [3,5,10,20]:
    df[f'mom_{p}'] = df['close'].pct_change(p)
df['volatility'] = df['returns'].rolling(10).std()
df['hour'] = df.index.hour
df['dow'] = df.index.dayofweek
df['session'] = 0
df.loc[(df['hour'] >= 8) & (df['hour'] < 16), 'session'] = 1
df.loc[(df['hour'] >= 13) & (df['hour'] < 21), 'session'] = 2

# Label: price direction 60min ahead (12 M5 candles)
future_close = df['close'].shift(-12)
df['target'] = ((future_close - df['close']) / df['close'] > 0.001).astype(int)

features = [
    'returns', 'hl_range', 'close_pos', 'body', 'direction',
    'dist_ma9', 'dist_ma21', 'dist_ma50', 'ma9_slope', 'ma21_slope',
    'RSI', 'RSI_change', 'BB_width', 'BB_pos', 'MACD_hist',
    'ATR_pct', 'vol_ratio', 'mom_3', 'mom_5', 'mom_10', 'mom_20',
    'volatility', 'hour', 'dow', 'session'
]

# 4. Train
data = df.dropna(subset=features + ['target'])
X, y = data[features], data['target']
split = int(len(X) * 0.75)
X_tr, X_va = X.iloc[:split], X.iloc[split:]
y_tr, y_va = y.iloc[:split], y.iloc[split:]
scale_pos = (len(y_tr) - y_tr.sum()) / (y_tr.sum() + 1)

log(f"\nTrain: {len(X_tr)}, Val: {len(X_va)}, ScalePos: {scale_pos:.1f}")
log(f"Buy class ratio: {y_tr.mean()*100:.1f}%")

model = xgb.XGBClassifier(
    n_estimators=300, max_depth=6, learning_rate=0.03,
    subsample=0.75, colsample_bytree=0.75,
    min_child_weight=5, gamma=0.2, reg_alpha=0.5, reg_lambda=1.5,
    scale_pos_weight=scale_pos, random_state=42
)
model.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)

# 5. Evaluate
y_pred = model.predict(X_va)
y_proba = model.predict_proba(X_va)[:, 1]
acc = accuracy_score(y_va, y_pred)
prec = precision_score(y_va, y_pred, zero_division=0)
rec = recall_score(y_va, y_pred, zero_division=0)
f1v = f1_score(y_va, y_pred, zero_division=0)

# Find best threshold
best_f1, best_t = 0, 0.5
for t in np.arange(0.25, 0.7, 0.05):
    yt = (y_proba >= t).astype(int)
    ft = f1_score(y_va, yt, zero_division=0)
    if ft > best_f1: best_f1, best_t = ft, t

y_best = (y_proba >= best_t).astype(int)
prec_best = precision_score(y_va, y_best, zero_division=0)
rec_best = recall_score(y_va, y_best, zero_division=0)
buy_count = y_pred.sum()
buy_best = y_best.sum()

log(f"\n{'='*50}")
log(f" RETRAIN M5 RESULT")
log(f"{'='*50}")
log(f"Accuracy:   {acc:.4f} ({acc*100:.1f}%)")
log(f"Precision:  {prec:.4f}  (best_t={best_t:.2f}: {prec_best:.4f})")
log(f"Recall:     {rec:.4f}  (best_t={best_t:.2f}: {rec_best:.4f})")
log(f"F1:         {f1v:.4f}  (best_t={best_t:.2f}: {best_f1:.4f})")
log(f"Buys pred:  {buy_count}/{len(y_pred)} ({buy_count/len(y_pred)*100:.1f}%)")
log(f"Buys best:  {buy_best}/{len(y_best)} ({buy_best/len(y_best)*100:.1f}%)")
log(f"Data:       {len(df)} M5 candles")
log(f"{'='*50}")

# 6. Compare with V2 baseline (59.7%, F1=0.346)
log(f"\nComparison:")
log(f"  V2 baseline: Acc=59.7%, Prec=34.6%, Rec=34.5%, F1=0.346")
log(f"  New model:   Acc={acc*100:.1f}%, Prec={prec*100:.1f}%, Rec={rec*100:.1f}%, F1={f1v:.3f}")

if f1v > 0.30:  # Deploy if F1 > 0.30
    os.makedirs(MODEL_DIR, exist_ok=True)
    path = os.path.join(MODEL_DIR, f"xgboost_v3_m5_{NOW}.pkl")
    with open(path, 'wb') as f:
        pickle.dump({'model': model, 'features': features, 'threshold': best_t}, f)
    log(f"\nSAVED: {path}")
    log(f"Model siap deploy! F1={f1v:.3f} > 0.30 (baseline)")
else:
    log(f"\nNOT SAVED: F1={f1v:.3f} < 0.30 (V2 baseline)")
    log(f"Keep using V2 model")
