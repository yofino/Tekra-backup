"""
FINAL RETRAIN - MT5 M5 + Live M1 + Historical 1h
All resampled to M5 for consistent training
"""
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pickle, json, os, glob
from datetime import datetime, timedelta

SYMBOL = "XAUUSDm"
DATA_DIR = r"C:\TradingBot\data"
MODEL_DIR = r"C:\TradingBot\models"
NOW = datetime.now().strftime("%Y%m%d_%H%M")

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

log("===== FINAL RETRAIN =====")

all_dfs = []

# 1. Fetch MT5 M5 data
log("Fetching MT5 M5 (90 days)...")
mt5.initialize()
end = datetime.now()
start = end - timedelta(days=90)
rates = mt5.copy_rates_range(SYMBOL, mt5.TIMEFRAME_M5, start, end)
mt5.shutdown()

if rates is not None:
    df_mt5 = pd.DataFrame(rates)
    df_mt5['time'] = pd.to_datetime(df_mt5['time'], unit='s')
    df_mt5.set_index('time', inplace=True)
    log(f"  MT5 M5: {len(df_mt5)} candles")
    all_dfs.append(df_mt5)

# 2. Live CSV M1 -> M5
log("Loading live CSV (M1 -> M5)...")
for f in sorted(glob.glob(os.path.join(DATA_DIR, "xauusd_2026*.csv"))):
    df = pd.read_csv(f)
    df['time'] = pd.to_datetime(df['time'], format='mixed')
    df.set_index('time', inplace=True)
    # Resample M1 to M5
    df_m5 = df.resample('5min').agg({
        'open': 'first', 'high': 'max', 'low': 'min',
        'close': 'last', 'tick_volume': 'sum', 'spread': 'mean'
    }).dropna()
    log(f"  {os.path.basename(f)}: {len(df)} M1 -> {len(df_m5)} M5")
    all_dfs.append(df_m5)

# 3. Historical 1h -> M5 (resample down)
hist_path = os.path.join(DATA_DIR, "xauusd_historical_1h.csv")
if os.path.exists(hist_path):
    df_hist = pd.read_csv(hist_path)
    df_hist['time'] = pd.to_datetime(df_hist['time'], utc=True).dt.tz_localize(None)
    df_hist.set_index('time', inplace=True)
    df_hist.sort_index(inplace=True)
    df_hist.rename(columns={'Volume': 'tick_volume'}, inplace=True)
    if 'tick_volume' not in df_hist.columns:
        df_hist['tick_volume'] = 1
    if 'spread' not in df_hist.columns:
        df_hist['spread'] = 0
    # Resample 1h to M5 (fill forward for OHLC)
    df_hist_m5 = df_hist.resample('5min').agg({
        'open': 'first', 'high': 'max', 'low': 'min',
        'close': 'last', 'tick_volume': 'sum', 'spread': 'mean'
    }).ffill().dropna()
    log(f"  Historical 1h: {len(df_hist)} -> {len(df_hist_m5)} M5")
    all_dfs.append(df_hist_m5)

# Combine all
df = pd.concat(all_dfs)
df = df[~df.index.duplicated(keep='first')]
df.sort_index(inplace=True)
log(f"TOTAL: {len(df)} M5 candles ({df.index[0]} to {df.index[-1]})")

# Feature engineering
log("Features...")
df['returns'] = df['close'].pct_change()
df['hl_range'] = (df['high'] - df['low']) / df['close']
df['close_pos'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 0.0001)
df['body'] = (df['close'] - df['open']).abs() / (df['high'] - df['low'] + 0.0001)
df['direction'] = np.where(df['close'] > df['open'], 1, -1)
for p in [9, 21, 50]:
    ma = df['close'].rolling(p).mean()
    df[f'dist_ma{p}'] = (df['close'] - ma) / df['close']
    df[f'ma{p}_slope'] = ma.pct_change(p)
delta = df['close'].diff()
gain = delta.clip(lower=0); loss = -delta.clip(upper=0)
avg_g = gain.ewm(span=14, adjust=False).mean()
avg_l = loss.ewm(span=14, adjust=False).mean()
df['RSI'] = 100 - (100 / (1 + (avg_g / avg_l.replace(0, np.nan))))
df['RSI_change'] = df['RSI'].diff(5)
std = df['close'].rolling(20).std()
df['BB_width'] = (2*std) / (df['close'].rolling(20).mean())  # No need to compute BB_mid separately? Actually let me fix this
mid = df['close'].rolling(20).mean()
df['BB_width'] = (2*std) / mid
df['BB_pos'] = (df['close'] - mid) / (2*std + 0.0001)
ema12 = df['close'].ewm(12, adjust=False).mean()
ema26 = df['close'].ewm(26, adjust=False).mean()
df['MACD_hist'] = ((ema12-ema26) - (ema12-ema26).ewm(9, adjust=False).mean()) / df['close']
hl = df['high']-df['low']; hc = np.abs(df['high']-df['close'].shift()); lc = np.abs(df['low']-df['close'].shift())
df['ATR_pct'] = np.maximum(hl, np.maximum(hc, lc)).ewm(14, adjust=False).mean() / df['close']
for p in [3,5,10,20]:
    df[f'mom_{p}'] = df['close'].pct_change(p)
df['volatility'] = df['returns'].rolling(10).std()
df['hour'] = df.index.hour
df['dow'] = df.index.dayofweek
df['session'] = 0
df.loc[(df['hour'] >= 8) & (df['hour'] < 16), 'session'] = 1
df.loc[(df['hour'] >= 13) & (df['hour'] < 21), 'session'] = 2

future = df['close'].shift(-12)
df['target'] = ((future - df['close']) / df['close'] > 0.001).astype(int)

features = [
    'returns', 'hl_range', 'close_pos', 'body', 'direction',
    'dist_ma9', 'dist_ma21', 'dist_ma50', 'ma9_slope', 'ma21_slope',
    'RSI', 'RSI_change', 'BB_width', 'BB_pos', 'MACD_hist',
    'ATR_pct', 'mom_3', 'mom_5', 'mom_10', 'mom_20',
    'volatility', 'hour', 'dow', 'session'
]

# Training
data = df.dropna(subset=features + ['target'])
X, y = data[features], data['target']
split = int(len(X) * 0.75)
X_tr, X_va = X.iloc[:split], X.iloc[split:]
y_tr, y_va = y.iloc[:split], y.iloc[split:]
sp = (len(y_tr) - y_tr.sum()) / (y_tr.sum() + 1)

log(f"Train: {len(X_tr)}, Val: {len(X_va)}, Scale: {sp:.1f}, Buy%: {y_tr.mean()*100:.1f}%")

model = xgb.XGBClassifier(
    n_estimators=300, max_depth=6, learning_rate=0.03,
    subsample=0.75, colsample_bytree=0.75,
    min_child_weight=5, gamma=0.2, reg_alpha=0.5, reg_lambda=1.5,
    scale_pos_weight=sp, random_state=42
)
model.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)

y_pred = model.predict(X_va)
y_proba = model.predict_proba(X_va)[:, 1]
acc = accuracy_score(y_va, y_pred)
prec = precision_score(y_va, y_pred, zero_division=0)
rec = recall_score(y_va, y_pred, zero_division=0)
f1v = f1_score(y_va, y_pred, zero_division=0)

best_f1, best_t = 0, 0.5
for t in np.arange(0.25, 0.7, 0.05):
    yt = (y_proba >= t).astype(int)
    ft = f1_score(y_va, yt, zero_division=0)
    if ft > best_f1: best_f1, best_t = ft, t

log(f"\n{'='*50}")
log(f" RESULT")
log(f"Accuracy:   {acc*100:.1f}%")
log(f"Precision:  {prec*100:.1f}%")
log(f"Recall:     {rec*100:.1f}%")
log(f"F1:         {f1v:.3f} (best t={best_t:.2f}, F1={best_f1:.3f})")
log(f"Buy ratio:  {y_pred.sum()}/{len(y_pred)}")
log(f"Data:       {len(df)} M5 candles")
log(f"\nV2 baseline: Acc=59.7%, Prec=34.6%, F1=0.346")

if f1v > 0.30:
    os.makedirs(MODEL_DIR, exist_ok=True)
    path = os.path.join(MODEL_DIR, f"xgboost_v3_{NOW}.pkl")
    with open(path, 'wb') as f:
        pickle.dump({'model': model, 'features': features, 'threshold': best_t}, f)
    log(f"SAVED: {path}")
    # Update bot to use new model
    bot_path = os.path.join(DATA_DIR, '..', 'bot_v3_ai.py')
    if os.path.exists(bot_path):
        with open(bot_path) as f: code = f.read()
        code = code.replace('xgboost_v2.pkl', os.path.basename(path))
        with open(bot_path, 'w') as f: f.write(code)
        log("Bot updated to use new model!")
else:
    log("NOT SAVED - V2 still better")
