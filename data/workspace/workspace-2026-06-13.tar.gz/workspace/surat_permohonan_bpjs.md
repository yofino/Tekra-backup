# SURAT PERMOHONAN PEMBAYARAN

---

**Kepada Yth.**
**Kepala BPJS Kesehatan Cabang Bandung**
di Tempat

---

**Perihal:** Permohonan Pembayaran Pekerjaan

---

Dengan hormat,

Bersama surat ini, kami mengajukan permohonan pembayaran atas pekerjaan yang telah selesai dilaksanakan di Kantor BPJS Kesehatan Bandung, dengan rincian sebagai berikut:

| No | Uraian Pekerjaan | No. Invoice | Nominal |
|---|---|---|---|
| 1 | Maintenance General CheckUp Access Control & Fire Alarm | 8/05/INV/2026 | Rp 920.000 |
| 2 | Pemindahan Jalur Kabel LAN | 9/05/INV/2026 | Rp 900.000 |
| 3 | Penarikan Kabel Speaker dan HDMI | 10/05/INV/2026 | Rp 1.535.000 |
| **TOTAL** | | | **Rp 3.355.000** |

Sebagai kelengkapan, bersama ini kami lampirkan:
1. Invoice asli (3 lembar)
2. Berita Acara Serah Terima Pekerjaan / BAST
3. Fotokopi NPWP Perusahaan
4. Fotokopi Rekening Bank

Demikian surat permohonan ini kami sampaikan. Atas perhatian dan kerja samanya, kami ucapkan terima kasih.

---

Bandung, 21 Mei 2026

Hormat kami,

**CV Primadaya Teknologi Rakyat**


_________________________
**Yofi Julian**
Direktur

---

**Lampiran:** 7 berkas
