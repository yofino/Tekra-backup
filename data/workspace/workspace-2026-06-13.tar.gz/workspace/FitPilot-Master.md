# FitPilot — Master Blueprint (B2B + B2C)

> **Produk**: FitPilot (by Pilot Digital)
> **Tagline**: *"Pilot your fitness journey."*
> **Dibuat**: 1 Juni 2026 | Ujang | v2.0

---

## 🎯 FitPilot adalah...

**Satu platform, dua pasar:**

```
┌──────────────────────────────────────────────────────┐
│                    FITPILOT                           │
│                                                      │
│   ┌─────────────────┐       ┌──────────────────┐    │
│   │      B2B        │       │       B2C        │    │
│   │  Gym Owners     │◄─────►│   End Users      │    │
│   │  (SaaS Admin)   │       │   (Mobile App)   │    │
│   └────────┬────────┘       └────────┬─────────┘    │
│            │                         │               │
│    Revenue: Gym              Revenue: Premium       │
│    Rp 299K-1.5M/bln          Rp 49K/bln/user        │
│            │                         │               │
│            └──────────┬──────────────┘               │
│                       │                              │
│              NETWORK EFFECT:                         │
│    User tracker → discover gym → gym join B2B       │
│    Gym join B2B → member install app → B2C grow     │
└──────────────────────────────────────────────────────┘
```

---

## 📊 B2B vs B2C — Feature Matrix

| Modul | B2B (Gym Owner) | B2C (End User) |
|-------|:---:|:---:|
| **Membership** | ✅ CRM, tiers, digital waivers | ❌ |
| **Billing** | ✅ QRIS/Gopay, recurring, POS | ❌ (bayar premium doang) |
| **Class Booking** | ✅ Calendar, waitlist, capacity | ✅ (liat jadwal + booking dari app) |
| **Check-in** | ✅ QR + GPS anti-fraud | ✅ (scan QR gym) |
| **Door Access** | ✅ 24/7 access control | ✅ (buka pintu gym dari app) |
| **Workout Logger** | ✅ (buat PT + assign) | ✅ (personal logger) |
| **Exercise Library** | ✅ (1000+ exercises) | ✅ (same database) |
| **AI Coach** | ❌ (admin doang) | ✅ (personal AI coach) |
| **AI CV Rep Counting** | ❌ | ✅ (on-device ML) |
| **AI Form Correction** | ❌ | ✅ (real-time audio) |
| **AI Routine Generator** | ✅ (assign ke member) | ✅ (personal program) |
| **Nutrition Tracker** | ❌ | ✅ (food diary + AI photo) |
| **Body Measurements** | ❌ | ✅ (weight, BF%, circumferences) |
| **Progress Photos** | ❌ | ✅ (before/after gallery) |
| **Health Vitals** | ❌ | ✅ (HR, BP, sleep, SpO2, glucose) |
| **Wearable Sync** | ❌ | ✅ (Apple Watch, Garmin, Fitbit) |
| **Gamification** | ✅ (gym challenges) | ✅ (XP, badges, leagues) |
| **Social Feed** | ❌ | ✅ (timeline, PR sharing, groups) |
| **Reporting** | ✅ (revenue, attendance, retention) | ❌ (personal insights doang) |
| **Marketing CRM** | ✅ (lead, automation, WA bot) | ❌ |
| **Coach Platform** | ✅ (manage trainers, payroll) | ✅ (find coach, track dengan coach) |
| **Gym Discovery** | ✅ (muncul di map B2C) | ✅ (cari gym terdekat) |
| **Payments** | ✅ (receive payments) | ✅ (bayar membership gym) |
| **WhatsApp** | ✅ (blast, reminder, chatbot) | ✅ (notif personal via WA) |

---

## 💰 Revenue Model — Dual Stream

### B2B: SaaS Subscription

| Tier | Harga/Bulan | Target |
|------|------------|--------|
| STARTER | **GRATIS** | Gym kecil <=50 member |
| GROWTH | **Rp 299K** | Gym menengah <=200 member |
| PRO | **Rp 699K** | Gym besar <=500 member |
| ULTIMATE | **Rp 1.5M** | Unlimited, multi-cabang |

### B2C: Freemium

| Tier | Harga/Bulan | Target |
|------|------------|--------|
| FREE | **Rp 0** | Semua user baru |
| PRO | **Rp 49K** | Power user |
| FAMILY | **Rp 79K** | 5 anggota keluarga |

### Revenue per Gym Ecosystem

```
1 Gym (200 member):
  B2B Growth:              Rp 299K/bln
  200 member B2C (10% PRO):  20 × Rp 49K = Rp 980K/bln
  ─────────────────────────────────────────
  Total Revenue/Gym:       Rp 1.28M/bln
```

---

## 🔄 Network Effects — Why This Wins

| Effek | B2B → B2C | B2C → B2B |
|-------|-----------|-----------|
| **Discovery** | Gym promosi app ke member | User cari gym di app, nemu partner gym |
| **Churn Reduction** | Member lebih engaged (tracker + gamification) = lebih lama stay | User gym X stay = B2B retention naik |
| **Referral** | Member gym puas → ajak temen install app → temen join gym | User rekomendasi gym ke temen → temen sign up B2B |
| **Data** | Gym liat data workout member → optimasi kelas | User workout data → AI personalization makin akurat |

---

## 🏗️ Architecture — Single Codebase

```
┌─────────────────────────────────────────────┐
│              LARAVEL 11 (Backend)            │
│  ┌──────────┐  ┌──────────┐  ┌───────────┐ │
│  │ B2B API │  │ B2C API  │  │ Common    │ │
│  │ (Admin)  │  │ (User)   │  │ Services  │ │
│  └──────────┘  └──────────┘  └───────────┘ │
│         │             │            │        │
│         ▼             ▼            ▼        │
│  ┌─────────────────────────────────────┐   │
│  │         SHARED DATABASE              │   │
│  │  • users (admin + member)            │   │
│  │  • gyms, classes, bookings           │   │
│  │  • workouts, exercises, routines     │   │
│  │  • nutrition, body_metrics           │   │
│  │  • health_vitals, wearables          │   │
│  │  • gamification (xp, badges, etc)    │   │
│  │  • social (feed, groups, follows)    │   │
│  └─────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
         │                    │
         ▼                    ▼
   Admin Panel          Mobile App
   (Web: Livewire)      (Flutter: iOS + Android)
   ┌──────────┐        ┌──────────────────┐
   │ B2B      │        │ B2C UI (role:    │
   │ Dashboard│        │   member/trainer) │
   │ Management│       │                  │
   │ Reports  │        │ ┌──────────────┐ │
   │ CRM      │        │ │ Workout      │ │
   └──────────┘        │ │ Nutrition    │ │
                        │ │ Health       │ │
                        │ │ Social       │ │
                        │ │ Wearable     │ │
                        │ │ AI (on-device)│ │
                        │ └──────────────┘ │
                        └──────────────────┘
```

---

## 📱 App Concepts

### B2C User App Screens

```
┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐
│     HOME            │  │    WORKOUT          │  │    NUTRITION        │
│                     │  │                     │  │                     │
│  🔥 45-day streak   │  │  PUSH DAY           │  │  🥗 1,850 / 2,200  │
│  ⭐ Health Score 78  │  │                     │  │  🍗 P: 145 / 160g  │
│                     │  │  ⏱️ 45:23 elapsed   │  │  🍞 C: 180 / 220g  │
│  Today:             │  │                     │  │  🥑 F: 55 / 65g    │
│  🏋️ 10:00 AM PUSH   │  │  ○○○○○ 65kg × 8    │  │                     │
│  🥗 1,450 cal       │  │  ○○○○○ 70kg × 6    │  │  Breakfast          │
│  👣 8,450 steps     │  │  ○○○○● 75kg × 4 PR │  │  🍳 Nasi Goreng    │
│  💧 6/8 glasses     │  │                     │  │  ☕ Kopi Susu       │
│  😴 7.2 hours       │  │  REST: 90s ███████  │  │                     │
│                     │  │                     │  │  [+ Add Meal]      │
└─────────────────────┘  └─────────────────────┘  └─────────────────────┘
```

### B2B Admin Dashboard

```
┌──────────────────────────────────────────────────────┐
│  FITPILOT ADMIN                    Gym: Iron Paradise │
│──────────────────────────────────────────────────────│
│                                                      │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌───────────┐ │
│  │ Revenue │ │ Active  │ │ Today   │ │ At Risk   │ │
│  │ Rp 8.5M │ │ 187     │ │ 23      │ │ 12 ⚠️     │ │
│  │  +12%   │ │ Members │ │ Check-in│ │ Members   │ │
│  └─────────┘ └─────────┘ └─────────┘ └───────────┘ │
│                                                      │
│  📊 Attendance Trend        🏋️ Popular Classes       │
│  ████████████░░░░          1. Yoga (92% full)        │
│  █████████████░░          2. HIIT (87% full)         │
│                             3. Muay Thai (78% full)   │
│                                                      │
│  ⚠️ AI Alerts:                                       │
│  • Budi (3 weeks no visit) → Send WA re-engagement   │
│  • Yoga Selasa 7PM full → Consider add slot          │
│  • Revenue projected +8% this month ✅                │
└──────────────────────────────────────────────────────┘
```

---

## 🎯 Competitive Positioning

```
                 AI FEATURES
                      ↑
          FitPilot ●  │  
          (B2B+B2C)   │  ● Vibefam ($89-289)
                      │
                      │     ● PushPress ($0-229)
                      │  ● Wodify ($79-179)
                      │
   ──────────────────────────────────────→ PRICE
              GymHub ●      ● Mindbody
              ($6-12)        ($129+)
                      │
                      │
                 BASIC│FEATURES
```

**FitPilot:** AI tercanggih + harga termurah + pasar Indonesia + B2B+B2C ecosystem.

---

## 📅 Combined Roadmap

| Fase | Duration | B2B | B2C |
|------|----------|-----|-----|
| Fase 0 | Setup 2 minggu | Project, tenant, auth, RBAC | Project structure, auth |
| Fase 1 | Bulan 1 | Membership, check-in QR, billing | Profile, basic workout logger |
| Fase 2 | Bulan 2 | Class booking, reporting, WA notif | Exercise library, body tracker |
| Fase 3 | Bulan 3 | CRM, lead, marketing automation | Nutrition tracker + Indo food DB |
| Fase 4 | Bulan 4 | AI churn prediction, AI chatbot | AI coach, AI routine generator |
| Fase 5 | Bulan 5 | Progress tracker (assign ke PT) | AI CV rep counting + form check |
| Fase 6 | Bulan 6 | Gamification challenges, leaderboard | Wearable sync (Apple/Garmin) |
| Fase 7 | Bulan 7 | Door access, POS, payroll | Social feed, groups, PR sharing |
| Fase 8 | Bulan 8 | Multi-cabang, franchise analytics | Gamification (XP, badges, leagues) |
| Fase 9 | Bulan 9 | API, Zapier, integrations | Health vitals, sleep, meditation |
| Fase 10 | Bulan 10+ | Enterprise, white-label | Family plan, coach marketplace |

> **Total: ~10 bulan ke MVP penuh B2B+B2C**

---

*FitPilot = Satu platform, dua pasar, network effect mematikan. ✈️*
