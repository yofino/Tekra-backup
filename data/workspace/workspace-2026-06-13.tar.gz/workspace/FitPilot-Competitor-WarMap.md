# FitPilot — Competitor War Map & Feature Blueprint

> **Produk**: FitPilot (by Pilot Digital)
> **Tagline**: *"Pilot your fitness journey."*
> **Dibuat**: 1 Juni 2026 | Ujang

---

## 🎯 Misi

**Tiru semua fitur kompetitor → bikin 10x lebih bagus → kuasai Indonesia dulu → ekspansi SEA.**

---

## 📊 Grand Feature Comparison

### Legend: ✅ Punya | ⚡ Unggulan | ❌ Gak Ada | 🤏 Setengah-setengah

| Feature | **FitPilot (KITA)** | Mindbody | Glofox | PushPress | Wodify | GymHub 🇮🇩 | OnlyGym 🇮🇩 | GRIMAX 🇮🇩 | Vibefam 🇸🇬 |
|---------|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **PRICING (USD/mo)** | **GRATIS - $48** | $129+ | Custom | $0-$229 | $79-$179+ | $6-12 | Hidden | Hidden | $89-289 |
| Free Tier | ✅ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **ADMIN FEATURES** | | | | | | | | | |
| Membership Management | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Class Booking | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ |
| Waitlist Auto-Manage | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| QR Code Check-in | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| 24/7 Door Access | ✅ | ❌ | ❌ | 🤏 | ⚡ | ❌ | ❌ | ❌ | 🤏 |
| Automated Billing | ✅ | ✅ | ✅ | ⚡ | ✅ | 🤏 | 🤏 | 🤏 | ✅ |
| Digital Waivers | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| POS / Merchandise | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Staff Payroll | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| **MOBILE** | | | | | | | | | |
| Branded Member App | ✅ | ✅ | ✅ | ⚡ (+$81) | ⚡ | ❌ | ❌ | ❌ | ⚡ (+$80) |
| Staff App | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| Offline Mode | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **PROGRESS TRACKER** | | | | | | | | | |
| Workout Plan Creator | ⚡ | ❌ | ❌ | 🤏 (+$79) | 🤏 | ❌ | ❌ | ❌ | ❌ |
| Exercise Library | ⚡ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Video Tutorials | ⚡ | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| PR / Personal Record | ⚡ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Body Measurements | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Progress Photos | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **AI FEATURES** | | | | | | | | | |
| AI Churn Prediction | ⚡ | ❌ | ❌ | ❌ | ⚡ | ❌ | ❌ | ❌ | ⚡ |
| AI Adaptive Programming | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| AI Form Correction (CV) | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| AI Rep Counting (CV) | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| AI Chatbot Support | ⚡ | ❌ | ❌ | 🤏 | ❌ | ❌ | ❌ | ❌ | ✅ |
| AI Revenue Forecasting | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| AI Dynamic Pricing | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **WEARABLE** | | | | | | | | | |
| Apple Watch HR | ⚡ | ❌ | ❌ | ❌ | 🤏 | ❌ | ❌ | ❌ | ❌ |
| Garmin Integration | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Recovery-Based Training | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **GAMIFICATION** | | | | | | | | | |
| XP & Leveling | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Leaderboards | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Streak System | ⚡ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Badges & Achievements | ⚡ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Challenges | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **SOCIAL** | | | | | | | | | |
| Activity Feed | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Workout Sharing | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Group Challenges | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Coach Marketplace | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **MARKETING** | | | | | | | | | |
| Lead Capture | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| Email/SMS Automation | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| WhatsApp Bot | ⚡ | ❌ | ❌ | 🤏 | ❌ | ❌ | ❌ | ❌ | ✅ |
| Cart Abandonment | ✅ | ❌ | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Referral Program | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **INDONESIA** | | | | | | | | | |
| Bahasa Indonesia | ⚡ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ |
| QRIS Payment | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| GoPay / OVO / Dana | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| WhatsApp Business API | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| **ENTERPRISE** | | | | | | | | | |
| Multi-Location | ✅ | ✅ | ✅ | ❌ | ✅ | 🤏 | ❌ | 🤏 | ✅ |
| Franchise Analytics | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Custom Onboarding | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| **TECHNICAL** | | | | | | | | | |
| Open API | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Zapier Integration | ✅ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Webhooks | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Custom Subdomain | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| Bilingual (ID/EN) | ⚡ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

> **⚡ = FitPilot UNGGUL / EKSKLUSIF** — fitur yang gak ada di kompetitor manapun

---

## 🚀 FitPilot Feature Specification

### MODUL 1: Membership Management
**Tiru dari**: GymDesk (simplicity) + Wodify (family groups)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| Member Profile | Foto, data diri, goals, medical notes, emergency contact | GymDesk |
| Membership Tiers | Daily / Weekly / Monthly / Yearly + custom duration | Glofox |
| Auto-Expiry | Auto non-aktif kalau expired, grace period 3 hari | Wodify |
| Family Groups | 1 akun utama + anggota keluarga, shared payment | Wodify |
| Digital Waiver | TTD digital saat daftar, tersimpan di cloud | Glofox |
| Freeze Membership | Pause membership max 30 hari, alasan + approval | Wodify |
| Transfer Membership | Pindah membership type dengan prorated billing | PushPress |
| Member Tagging | Tag member (VIP, At Risk, PT Client, dll) | PushPress |

### MODUL 2: Class Booking & Scheduling
**Tiru dari**: Glofox (seamless) + Mindbody (waitlist)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| Class Calendar | Weekly/monthly view, filter by class type/trainer | Glofox |
| Capacity Management | Max capacity per class, auto-close full | PushPress |
| Smart Waitlist | Auto-promote kalau ada yg cancel, notif WA otomatis | Wodify |
| Recurring Classes | Template repeating schedule (setiap Senin 7AM, dll) | PushPress |
| Priority Booking | VIP member bisa booking duluan (early access 24h) | Wodify |
| Late Cancel Fee | Auto-charge kalau cancel < 2 jam sebelum kelas | Wodify |
| PT Session Booking | Booking 1-on-1 dengan trainer spesifik | Mindbody |
| Room Booking | Booking studio/ruangan (yoga room, boxing ring, dll) | Glofox |

### MODUL 3: Check-in & Access Control
**Tiru dari**: OnlyGym (anti-fraud) + Wodify (24/7 door)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| QR Code Check-in | QR unik per member, regenerate tiap 24 jam | OnlyGym |
| Anti-Fraud Detection | GPS check, face match, device ID verification | OnlyGym |
| Kiosk Mode | Tablet di pintu masuk, self-service check-in | PushPress |
| 24/7 Door Access | Integrasi door controller, buka pintu via app | Wodify |
| Guest Pass | Generate guest pass QR, expire 1 hari | Glofox |
| Capacity Live | Real-time "berapa orang di dalam gym sekarang" | Glofox |
| Attendance History | Log lengkap check-in/out dengan timestamp | PushPress |

### MODUL 4: Billing & Payments (INDONESIA-READY)
**Tiru dari**: PushPress (flex fees) + Wodify (fast payouts)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| Recurring Billing | Auto-debit bulanan via payment gateway | PushPress |
| Payment Gateway | **QRIS, GoPay, OVO, Dana, ShopeePay**, Transfer Bank, VA | ❌ NONE |
| Midtrans / Xendit | Integrasi payment gateway lokal lengkap | ❌ NONE |
| Prorated Billing | Kalkulasi otomatis upgrade/downgrade mid-cycle | PushPress |
| Late Payment | Auto reminder WA + email H-3, H-1, H+1, H+7 | Wodify |
| Invoice Otomatis | PDF invoice terkirim otomatis tiap bulan | GymDesk |
| POS Kasir | Jual supplement, minuman, merchandise — integrated | Glofox |
| Flex Fees | Owner bisa atur siapa yg bayar processing fee | PushPress |
| Payout Schedule | Owner pilih daily/weekly/monthly payout | Wodify |

### MODUL 5: Progress Tracker (KILLER FEATURE)
**Tiru dari**: Fitbod (AI) + Hevy (UX) + Strava (social)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **Workout Logger** | Log sets, reps, weight, RPE, notes, rest timer | Hevy |
| **Exercise Library** | 1000+ exercises dengan animasi 3D + video + instructions | Hevy + Fitbod |
| **Custom Workout Builder** | Drag-and-drop buat workout plan + share ke member | Fitbod |
| **PR Tracking** | Auto-detect personal records, celebration animation | Hevy |
| **Body Measurements** | Log weight, body fat, waist, chest, arms, thighs — chart overtime | ❌ NONE |
| **Progress Photos** | Before/after gallery, side-by-side comparison, body part tagged | ❌ NONE |
| **AI Adaptive Programming** | AI otomatis naikin beban/reps/volume berdasarkan progress | Fitbod |
| **AI Rep Counting** | Kamera HP hitung reps otomatis (on-device ML) | ❌ NONE |
| **AI Form Correction** | Real-time audio cues: "punggung lurus", "lutut jangan lock" | ❌ NONE |
| **Goal Setting** | Weight target, body fat %, strength goal, consistency goal | Fitbod |
| **Workout Streak** | 🔥 Fire streak counter, freeze protection | Duolingo |
| **Progress Charts** | Visualisasi penurunan berat, kenaikan strength, body measurements | ❌ NONE |
| **TV Display Mode** | Cast workout ke TV gym — real-time leaderboard, WOD display, timer | PushPress |

### MODUL 6: AI Features
**Tiru dari**: Vibefam (AI retention) + Wodify (churn prediction) + 1club.ai (proactive AI)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **AI Churn Prediction** | Prediksi member yg mau cabut (berdasarkan attendance ↓, billing late, no check-in 2 minggu) | Wodify |
| **AI Re-engagement** | Auto-WA ke member at-risk: "Bro udah 2 minggu gak dateng nih..." | Vibefam |
| **AI Dynamic Pricing** | Rekomendasi harga paket optimal berdasarkan demand, kompetitor lokal, okupansi | 1club.ai |
| **AI Capacity Optimization** | Prediksi kelas mana yg bakal penuh, saranin buka slot tambahan | 1club.ai |
| **AI Revenue Forecasting** | Prediksi revenue 30/60/90 hari ke depan berdasarkan tren member | ❌ NONE |
| **AI Chatbot (WA)** | Member tanya "kelas yoga besok jam berapa?" via WA — auto jawab | Vibefam |
| **AI Chatbot (Admin)** | Owner tanya "hari ini revenue berapa?" — auto jawab + report | ❌ NONE |
| **AI Personal Coach** | Member chat AI: "gantiin latihan bench press yg aman buat bahu gue" | Freeletics |

### MODUL 7: Gamification
**Tiru dari**: PushPress (Committed Club) + Peloton (leaderboard) + Duolingo (streak)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **XP & Level System** | 5 tier: Bronze → Silver → Gold → Platinum → Diamond | Fitbod |
| **Streak Counter** | 🔥 Harian: check-in. 💪 Mingguan: workout. 👑 Bulanan: consistency | Duolingo |
| **Streak Shield** | Earn 1 shield per 7-day streak, protects 1 missed day | Duolingo |
| **Achievement Badges** | 50+ badges: "First PR", "100 Workouts", "Early Bird", "Night Owl", "Beast Mode" | Hevy |
| **Leaderboard** | Real-time ranking: most workouts, heaviest lift, most calories, most classes | Peloton |
| **Challenges** | Owner bikin challenge ("30 Day Push-up", "Lose 5kg Club"), member join | Strava |
| **Committed Club** | Attendance challenge: datang X kali per bulan = badge + discount next month | PushPress |
| **Seasonal Leagues** | 3-month ranked competitive seasons, promotion/relegation | Zwift |

### MODUL 8: Social & Community
**Tiru dari**: Strava (social feed) + Hevy (sharing)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **Activity Feed** | Timeline workout semua member gym (privacy setting per user) | Strava |
| **Workout Sharing** | Share workout summary ke IG Story / WA — branded graphic | Hevy |
| **PR Celebration** | Auto-post ke feed kalau member dapet PR, semua bisa celebrate 🎉 | Strava |
| **Groups** | Member bisa bikin group: "Yoga Lovers", "Deadlift Gang", "Weight Loss Squad" | Strava |
| **High Five** | Quick "semangat!" button ke member yg lagi workout live | Peloton |
| **Coach Platform** | Trainer bisa manage client list, assign workout, pantau progress | TrueCoach |
| **In-App Chat** | Chat trainer ↔ member, member ↔ member | PushPress |

### MODUL 9: Marketing & CRM
**Tiru dari**: Glofox (automation) + PushPress (Grow)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **Lead Capture Form** | Embed form di website gym, auto-create lead di CRM | Glofox |
| **Lead Pipeline** | Kanban board: New → Contacted → Trial → Closed Won/Lost | Wodify |
| **Automated Follow-up** | WA/email sequence: H+0 (welcome), H+3 (testimoni), H+7 (trial offer), H+14 (last chance) | Glofox |
| **Trial Management** | 1-day / 3-day / 7-day free trial pass, auto-expire + follow-up | Wodify |
| **Cart Abandonment** | Kalau daftar membership gak selesai → WA reminder 1h later | Glofox |
| **Referral Program** | Member ajak teman = 1 bulan gratis, teman = diskon 50% | ❌ NONE |
| **Winback Campaign** | Member expired > 30 hari → WA "we miss you" + special offer | Glofox |
| **Email Marketing** | Broadcast email: event, promo, new class, gym news | Wodify |
| **Review Collector** | Auto-request Google review dari member puas (attendance > 10x) | ❌ NONE |

### MODUL 10: Reporting & Analytics
**Tiru dari**: Wodify (custom reports) + PerfectGym (ML BI)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **Revenue Dashboard** | Daily/weekly/monthly revenue, breakdown per source | Wodify |
| **Member Dashboard** | New, active, at-risk, churned, retention rate, growth rate | Wodify |
| **Attendance Report** | Peak hours, class occupancy %, trainer utilization | PushPress |
| **Financial Report** | P&L gym, outstanding payments, revenue projection | GymDesk |
| **Custom Report Builder** | Drag-and-drop fields, filter, group by, export CSV/PDF | Wodify |
| **Scheduled Reports** | Auto-email report ke owner tiap Senin pagi | ❌ NONE |
| **AI Insights** | "Member X at risk", "Kelas Selasa 7PM selalu full (tambah slot)", "Revenue projected naik 15% bulan depan" | 1club.ai |

### MODUL 11: Nutrition (ADD-ON)
**Tiru dari**: MyFitnessPal (tracking) + SnapCalorie (AI photo)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **Food Diary** | Log makanan: search, barcode scan, custom food | MyFitnessPal |
| **AI Photo Logging** | Foto makanan → AI deteksi kalori & makro otomatis | SnapCalorie |
| **Macro Goals** | Set protein/carb/fat target, progress bar | MyFitnessPal |
| **Pre/Post Workout Tips** | "Sekarang waktunya protein shake, bro!" (notif via WA) | ❌ NONE |

### MODUL 12: Mobile App (Flutter)
**Tiru dari**: Hevy (UX) + Wodify (one app for all) + OnlyGym (anti-fraud)

| Fitur | Detail | Contek dari |
|-------|--------|-------------|
| **One App for All** | Member + Trainer + Owner dalam 1 app (role-based UI) | Wodify |
| **Offline Mode** | Log workout, check-in, booking — sync pas online | ❌ NONE |
| **Push Notification** | Class reminder, payment due, PR achieved, challenge update | Hevy |
| **Widget** | Android/iOS widget: today's class, streak, next workout | ❌ NONE |
| **Wear OS / watchOS** | Apple Watch & Wear OS companion app for quick check-in | ❌ NONE |
| **Live HR Display** | Real-time heart rate from Apple Watch / Garmin during workout | Peloton |

---

## 💰 Pricing Strategy — Contek & Bikin Lebih Agresif

### Kompetitor Pricing Reference

| Competitor | Free | Entry | Mid | High | Enterprise |
|------------|------|-------|-----|------|------------|
| GymHub 🇮🇩 | ❌ | Rp 99K | Rp 199K | - | - |
| PushPress | $0 | $159 | $229 | - | - |
| GymDesk | ❌ | $75 | $150 | $200 | Custom |
| Wodify | ❌ | $79 | $179+ | $239+ | Custom |
| Vibefam 🇸🇬 | ❌ | $89 | $189 | $239 | Custom |

### FitPilot Pricing (IDR, terjangkau)

| Tier | Harga/Bulan | Member Max | Key Features |
|------|------------|------------|--------------|
| **STARTER** | **GRATIS** | 50 | Membership, check-in QR, basic booking, 1 cabang |
| **GROWTH** | **Rp 299K** (~$18) | 200 | + AI insights, WA auto-notif, marketing automation, reporting |
| **PRO** | **Rp 699K** (~$42) | 500 | + Progress tracker, branded app, workout builder, challenges |
| **ULTIMATE** | **Rp 1.5M** (~$90) | Unlimited | + AI CV, nutrition, 24/7 door, multi-cabang, API |

**Add-ons:**
- Branded App: +Rp 199K/mo
- AI CV Module: +Rp 149K/mo
- Nutrition Module: +Rp 99K/mo
- Extra Location: +Rp 99K/mo

---

## 🔥 FitPilot's 10 UNFAIR ADVANTAGES

| # | Advantage | Kompetitor Terbaik | FitPilot |
|---|-----------|-------------------|----------|
| 1 | **Pertama AI-powered di Indonesia** | Tidak ada | ✅ AI churn, coaching, CV, chatbot |
| 2 | **WhatsApp Deep Integration** | Vibefam (basic) | ✅ Check-in, booking, payment, support, chatbot |
| 3 | **Computer Vision Rep Counting** | Tidak ada | ✅ On-device ML, works offline |
| 4 | **Indonesian Payment Complete** | Tidak ada | ✅ QRIS, GoPay, OVO, Dana, ShopeePay, VA |
| 5 | **Progress Tracker All-in-One** | Tidak ada | ✅ Workout + Body + Photo + PR + AI + Charts |
| 6 | **Free Tier Nyata** | PushPress (US) | ✅ <=50 members, FREE selamanya |
| 7 | **Offline-First Mobile** | Tidak ada | ✅ Gym di pelosok tetap bisa pake |
| 8 | **Gamification RPG System** | Tidak ada | ✅ XP, level, badges, leagues, challenges |
| 9 | **Bilingual ID/EN** | Tidak ada | ✅ UI togglable, support both languages |
| 10 | **1/3 Harga Kompetitor Global** | $75-289 | ✅ $0-90 dengan fitur 3x lebih banyak |

---

## 🗺️ Technology Stack — FitPilot

| Layer | Tech | Kenapa |
|-------|------|--------|
| **Backend** | Laravel 11 | Multi-tenant, queue (Horizon), websocket (Reverb) |
| **Frontend** | Livewire 3 + Alpine.js + Tailwind | Cepat development, server-rendered |
| **Mobile** | Flutter 3.x | Satu codebase Android + iOS + offline-first |
| **Database** | MySQL 8 (multi-schema) | 1 tenant = 1 schema |
| **Cache/Queue** | Redis + Horizon | WhatsApp blast, billing batch, AI jobs |
| **Realtime** | Laravel Reverb | Live leaderboard, live check-in feed |
| **CV/AI** | MediaPipe + MoveNet (on-device) + DeepSeek API (cloud) | Rep counting + form correction on phone; AI coaching via cloud |
| **Payment** | Midtrans + Xendit | QRIS, GoPay, OVO, Dana, VA, CC |
| **Messaging** | WhatsApp Cloud API | Notif, chatbot, check-in, booking |
| **Storage** | S3-compatible (MinIO / DO Spaces) | Progress photos, waivers, invoices |

---

*Dokumen ini adalah blueprint perang FitPilot — tiru, contek, bikin lebih bagus. Indonesia dulu, SEA berikutnya.* ✈️
