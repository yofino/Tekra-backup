"""
Dashboard Streamlit — Monitoring XAUUSD AI Trading Bot
Jalan di VPS Nocita (Linux), akses dari browser

Cara jalan:
    cd dashboard && streamlit run streamlit_app.py
"""

import streamlit as st
import requests
import pandas as pd
from datetime import datetime
import time

# Config
st.set_page_config(
    page_title="XAUUSD AI Bot",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# API endpoint (Windows VPS)
API_URL = "http://WINDOWS_VPS_IP:5000/api"  # GANTI DENGAN IP VPS WINDOWS

# Auto refresh
REFRESH_SECONDS = 5

def fetch_data(endpoint: str):
    """Ambil data dari API bot"""
    try:
        resp = requests.get(f"{API_URL}/{endpoint}", timeout=3)
        return resp.json()
    except:
        return None


def main():
    st.title("📊 XAUUSD AI Trading Bot")
    
    # Sidebar
    with st.sidebar:
        st.header("⚙️ Settings")
        
        status_data = fetch_data("status")
        status = status_data.get("status", "unknown") if status_data else "offline"
        
        if status == "running":
            st.success("🟢 Bot Running")
        elif status == "paused":
            st.warning("🟡 Bot Paused")
        else:
            st.error("🔴 Bot Offline")
        
        st.divider()
        
        # Commands
        st.subheader("Commands")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("⏸️ Pause", use_container_width=True):
                requests.post(f"{API_URL}/command", json={"command": "pause"})
        with col2:
            if st.button("▶️ Resume", use_container_width=True):
                requests.post(f"{API_URL}/command", json={"command": "resume"})
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("❌ Close All", use_container_width=True):
                requests.post(f"{API_URL}/command", json={"command": "close_all"})
        with col2:
            if st.button("🚨 Emergency", use_container_width=True, type="primary"):
                requests.post(f"{API_URL}/command", json={"command": "emergency_stop"})
        
        st.divider()
        st.caption(f"Last refresh: {datetime.now().strftime('%H:%M:%S')}")
    
    # Main content
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Overview", "💼 Positions", "📋 History", "🤖 Strategy"])
    
    with tab1:
        # Metric cards
        account = fetch_data("account")
        status = fetch_data("status")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            balance = account.get("balance", 0) if account else 0
            st.metric("💰 Balance", f"${balance:,.2f}")
        
        with col2:
            equity = account.get("equity", 0) if account else 0
            if account:
                pnl = equity - balance
                pnl_pct = (pnl / balance * 100) if balance > 0 else 0
            else:
                pnl = 0
                pnl_pct = 0
            st.metric(
                "📈 Floating P/L",
                f"${pnl:,.2f}",
                f"{pnl_pct:+.2f}%"
            )
        
        with col3:
            positions = fetch_data("positions")
            pos_count = len(positions) if positions else 0
            st.metric("🔢 Open Positions", pos_count)
        
        with col4:
            stats = status.get("stats", {}) if status else {}
            win_rate = 0
            if stats.get("total_trades", 0) > 0:
                win_rate = (stats.get("wins", 0) / stats["total_trades"]) * 100
            st.metric("🎯 Win Rate", f"{win_rate:.0f}%")
        
        # Signal
        if status:
            signal = status.get("signal", {})
            action = signal.get("action", "HOLD")
            
            if action == "BUY":
                st.info(f"🔵 Signal: {action}")
            elif action == "SELL":
                st.error(f"🔴 Signal: {action}")
            else:
                st.info(f"⚪ Signal: {action}")
        
        # Price
        price = status.get("price", {}) if status else {}
        if price:
            st.metric(
                "💵 XAUUSD",
                f"Bid: ${price.get('bid', 0):.2f} | Ask: ${price.get('ask', 0):.2f}"
            )
    
    with tab2:
        st.subheader("💼 Open Positions")
        positions = fetch_data("positions")
        
        if positions and len(positions) > 0:
            df = pd.DataFrame(positions)
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.info("Tidak ada posisi terbuka")
    
    with tab3:
        st.subheader("📋 Trade History")
        st.info("History akan tampil setelah connect database PostgreSQL")
    
    with tab4:
        st.subheader("🤖 Strategy Info")
        st.json({
            "strategy": "XGBoost / RuleBased",
            "symbol": "XAUUSD",
            "timeframe": "H1",
            "max_positions": 3,
            "risk_per_trade": "1%",
            "max_drawdown": "10%"
        })
    
    # Auto refresh
    time.sleep(REFRESH_SECONDS)
    st.rerun()


if __name__ == "__main__":
    main()
