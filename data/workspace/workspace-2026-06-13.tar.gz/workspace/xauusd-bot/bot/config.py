"""
Konfigurasi sentral untuk XAUUSD Trading Bot
Load dari .env file
"""

import os
from dotenv import load_dotenv

load_dotenv()

# --- MT5 ---
MT5_LOGIN = int(os.getenv("MT5_LOGIN", "0"))
MT5_PASSWORD = os.getenv("MT5_PASSWORD", "")
MT5_SERVER = os.getenv("MT5_SERVER", "")
MT5_PATH = os.getenv("MT5_PATH", "")

# --- Trading ---
SYMBOL = os.getenv("SYMBOL", "XAUUSD")
TIMEFRAME = os.getenv("TIMEFRAME", "H1")
LOT_SIZE = float(os.getenv("LOT_SIZE", "0.01"))
MAX_POSITIONS = int(os.getenv("MAX_POSITIONS", "3"))
MAX_DRAWDOWN_PCT = float(os.getenv("MAX_DRAWDOWN_PCT", "10.0"))
RISK_PER_TRADE_PCT = float(os.getenv("RISK_PER_TRADE_PCT", "1.0"))

# --- Database ---
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "xauusd_bot")
DB_USER = os.getenv("DB_USER", "bot")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")

# --- Dashboard ---
DASHBOARD_API_KEY = os.getenv("DASHBOARD_API_KEY", "")
DASHBOARD_URL = os.getenv("DASHBOARD_URL", "http://localhost:8501")

# --- Mode ---
MODE = os.getenv("MODE", "demo")

# --- Timeframe mapping ---
TIMEFRAME_MAP = {
    "M1": 1, "M5": 5, "M15": 15, "M30": 30,
    "H1": 16385, "H4": 16388, "D1": 16408, "W1": 16409
}

MT5_TIMEFRAME = TIMEFRAME_MAP.get(TIMEFRAME, 16385)

# --- Model ---
MODEL_PATH = os.getenv("MODEL_PATH", "models/xgboost_xauusd.pkl")
