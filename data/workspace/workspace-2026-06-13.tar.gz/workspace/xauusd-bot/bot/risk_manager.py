"""
Risk Manager — batasan & proteksi
- Stop Loss / Take Profit
- Max positions
- Max drawdown
- Lot size kalkulator
"""

import MetaTrader5 as mt5
from loguru import logger
from bot.config import (
    SYMBOL, MAX_POSITIONS, MAX_DRAWDOWN_PCT,
    RISK_PER_TRADE_PCT
)


def calculate_lot_size(sl_pips: float) -> float:
    """
    Hitung lot size berdasarkan risk 1% per trade
    sl_pips: jarak SL dalam pips (XAUUSD: 1 pip = 0.01)
    """
    account = mt5.account_info()
    if account is None:
        return 0.01
    
    balance = account.balance
    risk_amount = balance * (RISK_PER_TRADE_PCT / 100)
    
    # XAUUSD: 1 lot = 100 oz, 1 pip = $1 per 0.01 lot
    lot_size = risk_amount / (sl_pips * 10)
    
    # Round ke 0.01
    lot_size = round(lot_size, 2)
    lot_size = max(0.01, min(lot_size, 1.0))  # min 0.01, max 1.0
    
    return lot_size


def check_max_positions() -> bool:
    """Cek jumlah posisi terbuka XAUUSD"""
    positions = mt5.positions_get(symbol=SYMBOL)
    count = len(positions) if positions else 0
    return count < MAX_POSITIONS


def check_drawdown() -> bool:
    """Cek apakah drawdown melebihi batas"""
    account = mt5.account_info()
    if account is None:
        return False
    
    drawdown_pct = ((account.balance - account.equity) / account.balance) * 100
    
    if drawdown_pct > MAX_DRAWDOWN_PCT:
        logger.warning(f"⚠️ DRAWDOWN {drawdown_pct:.2f}% melebihi limit {MAX_DRAWDOWN_PCT}%")
        return False
    
    return True


def check_spread(max_spread: float = 1.0) -> bool:
    """Cek spread gak kegedean (XAUUSD normal 0.1-0.5)"""
    info = mt5.symbol_info(SYMBOL)
    if info is None:
        return False
    
    spread = (info.ask - info.bid) * 10  # pips
    return spread <= max_spread


def calculate_sl_tp(
    order_type: int,  # mt5.ORDER_TYPE_BUY atau mt5.ORDER_TYPE_SELL
    entry_price: float,
    sl_pips: float = 30.0,
    tp_pips: float = 60.0
) -> tuple:
    """
    Hitung SL dan TP price
    XAUUSD: 1 pip = 0.01
    Return (sl_price, tp_price)
    """
    pip_value = 0.01 * sl_pips
    
    if order_type == mt5.ORDER_TYPE_BUY:
        sl_price = entry_price - (pip_value * sl_pips)
        tp_price = entry_price + (pip_value * tp_pips)
    else:
        sl_price = entry_price + (pip_value * sl_pips)
        tp_price = entry_price - (pip_value * tp_pips)
    
    return round(sl_price, 2), round(tp_price, 2)


def can_trade() -> tuple[bool, str]:
    """
    Cek semua kondisi sebelum trading
    Return (boleh_trade, alasan_kalau_gak_boleh)
    """
    checks = [
        (check_max_positions, "Max posisi tercapai"),
        (check_drawdown, "Drawdown melebihi batas"),
        (check_spread, "Spread terlalu lebar"),
    ]
    
    for check_fn, reason in checks:
        if not check_fn():
            return False, reason
    
    return True, "OK"
