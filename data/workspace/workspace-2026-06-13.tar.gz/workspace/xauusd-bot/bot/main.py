"""
Main Bot Loop — XAUUSD AI Trading
Jalan terus 24/5, cek candle → prediksi → eksekusi

Cara jalan:
    python -m bot.main
"""

import time
import sys
import threading
from datetime import datetime, timezone
from loguru import logger
import MetaTrader5 as mt5

from bot.config import SYMBOL, TIMEFRAME, LOT_SIZE, MODE, MODEL_PATH
from bot.mt5_connector import initialize_mt5, shutdown_mt5, get_spread
from bot.data_fetcher import get_candles, get_current_price, is_market_open
from bot.features import add_technical_indicators, prepare_prediction_features
from bot.risk_manager import calculate_lot_size, can_trade
from bot.executor import place_order, close_all_positions, get_open_positions
from bot.strategy import RuleBasedStrategy, XGBoostStrategy
from bot.api_server import run_api_server, update_latest_data

# Setup logger
logger.remove()
logger.add(sys.stdout, level="INFO", format="{time:HH:mm:ss} | {level} | {message}")
logger.add("logs/bot_{time:YYYY-MM-DD}.log", rotation="1 day", retention="30 days",
           level="DEBUG", format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}")


class TradingBot:
    def __init__(self):
        self.strategy = None
        self.running = True
        self.paused = False
        self.total_trades = 0
        self.wins = 0
        self.losses = 0
        self.last_signal = {"action": "HOLD", "confidence": 0}
        self.last_candle_time = None
    
    def setup(self):
        """Inisialisasi semua komponen"""
        logger.info("=" * 40)
        logger.info(" XAUUSD AI Trading Bot Starting")
        logger.info(f" Symbol: {SYMBOL} | TF: {TIMEFRAME} | Mode: {MODE}")
        logger.info("=" * 40)
        
        if not initialize_mt5():
            logger.error("Gagal inisialisasi MT5")
            return False
        
        # Pilih strategi
        import os
        if os.path.exists(MODEL_PATH):
            logger.info("Menggunakan model XGBoost")
            self.strategy = XGBoostStrategy(MODEL_PATH)
        else:
            logger.info("Model tidak ditemukan, menggunakan RuleBased")
            self.strategy = RuleBasedStrategy()
        
        logger.info("Bot siap! Menunggu sinyal...")
        return True
    
    def process_candle(self):
        """Cek candle terbaru → analisa → trade"""
        
        # Ambil data
        df = get_candles(count=200)
        if df.empty:
            return
        
        latest_candle = df.iloc[-1]
        candle_time = latest_candle['time']
        
        # Skip kalau candle belum baru
        if self.last_candle_time and candle_time <= self.last_candle_time:
            return
        
        self.last_candle_time = candle_time
        
        # Feature engineering
        df = add_technical_indicators(df)
        features = prepare_prediction_features(df)
        
        if len(features) == 0:
            return
        
        # Prediksi
        signal = self.strategy.predict(features)
        signal_map = {1: "BUY", -1: "SELL", 0: "HOLD"}
        
        self.last_signal = {
            "action": signal_map[signal],
            "confidence": 0.0  # placeholder
        }
        
        logger.info(f"[{candle_time}] Sinyal: {signal_map[signal]} | "
                    f"Price: {latest_candle['close']}")
        
        # HOLD → skip
        if signal == 0:
            return
        
        # Cek risk
        can_trade_flag, reason = can_trade()
        if not can_trade_flag:
            logger.warning(f"Trade ditahan: {reason}")
            return
        
        # Hitung lot size
        lot = calculate_lot_size(sl_pips=30)
        
        # Eksekusi
        order_type = mt5.ORDER_TYPE_BUY if signal == 1 else mt5.ORDER_TYPE_SELL
        result = place_order(order_type, lot)
        
        if result["success"]:
            self.total_trades += 1
            logger.info(f"Total trades: {self.total_trades}")
    
    def update_state(self):
        """Update state buat API/dashboard"""
        price = get_current_price()
        account = mt5.account_info()
        
        state = {
            "status": "paused" if self.paused else "running",
            "price": price,
            "signal": self.last_signal,
            "stats": {
                "total_trades": self.total_trades,
                "wins": self.wins,
                "losses": self.losses
            }
        }
        
        if account:
            state["account"] = {
                "balance": account.balance,
                "equity": account.equity,
                "margin_free": account.margin_free
            }
        
        update_latest_data(state)
    
    def run(self):
        """Main loop"""
        if not self.setup():
            return
        
        # Start API server di thread terpisah
        api_thread = threading.Thread(target=run_api_server, daemon=True)
        api_thread.start()
        
        logger.info("Main loop starting...")
        
        while self.running:
            try:
                if not self.paused and is_market_open():
                    self.process_candle()
                
                # Update state buat dashboard
                self.update_state()
                
                # Sleep sesuai timeframe (cek tiap 1 detik)
                time.sleep(1)
                
            except KeyboardInterrupt:
                logger.info("Shutdown signal diterima")
                break
            except Exception as e:
                logger.error(f"Error di main loop: {e}")
                time.sleep(5)
        
        shutdown_mt5()
        logger.info("Bot stopped")


if __name__ == "__main__":
    bot = TradingBot()
    bot.run()
