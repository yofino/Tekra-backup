"""
Koneksi & manajemen MT5
- Inisialisasi terminal
- Login ke akun
- Utility: spread, balance, dll
"""

import MetaTrader5 as mt5
import time
from loguru import logger
from bot.config import MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_PATH


def initialize_mt5() -> bool:
    """Inisialisasi MT5 terminal dan login"""
    
    if not mt5.initialize(path=MT5_PATH):
        logger.error(f"MT5 init gagal: {mt5.last_error()}")
        return False
    
    # Coba login kalau ada credential
    if MT5_LOGIN and MT5_PASSWORD and MT5_SERVER:
        authorized = mt5.login(
            login=MT5_LOGIN,
            password=MT5_PASSWORD,
            server=MT5_SERVER
        )
        if not authorized:
            logger.error(f"MT5 login gagal: {mt5.last_error()}")
            mt5.shutdown()
            return False
        logger.info(f"MT5 login sukses → akun #{MT5_LOGIN}")
    else:
        logger.warning("MT5 credential kosong, pakai terminal yg sudah login")
    
    # Verifikasi
    account_info = mt5.account_info()
    if account_info is None:
        logger.error("Gak bisa ambil account info")
        mt5.shutdown()
        return False
    
    logger.info(f"Balance: ${account_info.balance:.2f} | "
                f"Equity: ${account_info.equity:.2f} | "
                f"Leverage: 1:{account_info.leverage}")
    
    return True


def get_spread(symbol: str = "XAUUSD") -> float:
    """Ambil current spread dalam pips"""
    info = mt5.symbol_info(symbol)
    if info is None:
        return 0.0
    return (info.ask - info.bid) * 10  # XAUUSD: 1 pip = 0.01


def shutdown_mt5():
    """Shutdown MT5 connection"""
    mt5.shutdown()
    logger.info("MT5 shutdown")
