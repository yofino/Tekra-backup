"""
Eksekusi order ke MT5
- BUY / SELL market order
- Close position
- Close all positions
"""

import MetaTrader5 as mt5
from datetime import datetime
from loguru import logger
from bot.config import SYMBOL, MODE
from bot.risk_manager import calculate_sl_tp


def place_order(
    order_type: int,  # mt5.ORDER_TYPE_BUY (0) / mt5.ORDER_TYPE_SELL (1)
    lot_size: float,
    sl_pips: float = 30.0,
    tp_pips: float = 60.0,
    comment: str = "AI-XAUUSD"
) -> dict:
    """
    Buka posisi market order
    Return: {
        "success": bool,
        "ticket": int,
        "price": float,
        "sl": float,
        "tp": float,
        "error": str
    }
    """
    
    if MODE == "demo":
        logger.info(f"[DEMO] Would open {'BUY' if order_type == 0 else 'SELL'} "
                    f"{SYMBOL} @ {lot_size} lot")
    
    # Ambil harga
    if order_type == mt5.ORDER_TYPE_BUY:
        price = mt5.symbol_info_tick(SYMBOL).ask
    else:
        price = mt5.symbol_info_tick(SYMBOL).bid
    
    # Hitung SL/TP
    sl_price, tp_price = calculate_sl_tp(
        order_type, price, sl_pips, tp_pips
    )
    
    # Siapin request
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": lot_size,
        "type": order_type,
        "price": price,
        "sl": sl_price,
        "tp": tp_price,
        "deviation": 10,
        "magic": 420001,  # ID unik bot
        "comment": comment,
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    if MODE == "demo":
        return {
            "success": True,
            "ticket": 0,
            "price": price,
            "sl": sl_price,
            "tp": tp_price,
            "mode": "demo"
        }
    
    # Kirim order
    result = mt5.order_send(request)
    
    if result.retcode != mt5.TRADE_RETCODE_DONE:
        logger.error(f"Order gagal: {result.comment} (code {result.retcode})")
        return {
            "success": False,
            "ticket": 0,
            "price": price,
            "sl": sl_price,
            "tp": tp_price,
            "error": result.comment
        }
    
    logger.info(f"✅ Order #{result.order} | {SYMBOL} | "
                f"{'BUY' if order_type == 0 else 'SELL'} | "
                f"{lot_size} lot @ {price} | "
                f"SL: {sl_price} | TP: {tp_price}")
    
    return {
        "success": True,
        "ticket": result.order,
        "price": price,
        "sl": sl_price,
        "tp": tp_price
    }


def close_position(ticket: int) -> bool:
    """Tutup posisi berdasarkan ticket"""
    position = mt5.positions_get(ticket=ticket)
    if not position:
        logger.warning(f"Posisi #{ticket} gak ditemukan")
        return False
    
    position = position[0]
    
    if position.type == mt5.POSITION_TYPE_BUY:
        order_type = mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(position.symbol).bid
    else:
        order_type = mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(position.symbol).ask
    
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": position.symbol,
        "volume": position.volume,
        "type": order_type,
        "position": ticket,
        "price": price,
        "deviation": 10,
        "magic": 420001,
        "comment": "Close AI",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    if MODE == "demo":
        logger.info(f"[DEMO] Close #{ticket} @ {price}")
        return True
    
    result = mt5.order_send(request)
    
    if result.retcode == mt5.TRADE_RETCODE_DONE:
        logger.info(f"❌ Closed #{ticket} @ {price}")
        return True
    
    logger.error(f"Close #{ticket} gagal: {result.comment}")
    return False


def close_all_positions() -> int:
    """Tutup semua posisi XAUUSD"""
    positions = mt5.positions_get(symbol=SYMBOL)
    if not positions:
        return 0
    
    closed = 0
    for pos in positions:
        if close_position(pos.ticket):
            closed += 1
    
    logger.info(f"Closed {closed}/{len(positions)} posisi")
    return closed


def get_open_positions() -> list:
    """Ambil semua posisi XAUUSD yang terbuka"""
    positions = mt5.positions_get(symbol=SYMBOL)
    if not positions:
        return []
    
    result = []
    for pos in positions:
        result.append({
            "ticket": pos.ticket,
            "type": "BUY" if pos.type == 0 else "SELL",
            "volume": pos.volume,
            "open_price": pos.price_open,
            "current_price": pos.price_current,
            "sl": pos.sl,
            "tp": pos.tp,
            "profit": pos.profit,
            "time": datetime.fromtimestamp(pos.time)
        })
    
    return result
