"""
Base Strategy — template buat semua strategi
Lo bisa bikin strategi turunan dari class ini
"""

from abc import ABC, abstractmethod
import pickle
import numpy as np
from loguru import logger


class BaseStrategy(ABC):
    """Abstract base class untuk semua strategi trading"""
    
    def __init__(self, name: str):
        self.name = name
        self.model = None
    
    @abstractmethod
    def predict(self, features: np.ndarray) -> int:
        """
        Prediksi sinyal dari fitur
        Return: 1 (BUY), -1 (SELL), 0 (HOLD)
        """
        pass
    
    def load_model(self, path: str):
        """Load model dari file .pkl"""
        with open(path, 'rb') as f:
            self.model = pickle.load(f)
        logger.info(f"Model loaded: {path}")


class RuleBasedStrategy(BaseStrategy):
    """
    Strategi rule-based sederhana (baseline)
    BUY kalau: RSI < 35 + harga dekat support + MACD bullish
    SELL kalau: RSI > 65 + harga dekat resistance + MACD bearish
    """
    
    def __init__(self):
        super().__init__("RuleBased v1")
    
    def predict(self, features: np.ndarray) -> int:
        if len(features) == 0:
            return 0
        
        f = features[0]
        
        # Unpack: [rsi, macd, macd_hist, macd_signal, bb_width, bb_position,
        #           atr_pct, candle_size, body_pct, dist_support, dist_resistance,
        #           volume_ratio, momentum_5, momentum_10, roc_10]
        
        rsi = f[0]
        macd_hist = f[2]
        bb_position = f[5]
        body_pct = f[8]
        dist_support = f[9]
        dist_resistance = f[10]
        
        # BUY signal
        if (rsi < 35 and
            dist_support < 1.5 and
            macd_hist > -0.1 and
            body_pct > -0.2):
            return 1
        
        # SELL signal
        if (rsi > 65 and
            dist_resistance < 1.5 and
            macd_hist < 0.1 and
            body_pct < 0.3):
            return -1
        
        return 0  # HOLD


class XGBoostStrategy(BaseStrategy):
    """Strategi pakai model XGBoost yg udah dilatih"""
    
    def __init__(self, model_path: str = None):
        super().__init__("XGBoost")
        if model_path:
            self.load_model(model_path)
    
    def predict(self, features: np.ndarray) -> int:
        if self.model is None:
            return 0
        if len(features) == 0:
            return 0
        
        # Model return: 0=HOLD, 1=BUY, 2=SELL
        pred = self.model.predict(features)[0]
        
        mapping = {0: 0, 1: 1, 2: -1}
        return mapping.get(int(pred), 0)
    
    def predict_proba(self, features: np.ndarray) -> dict:
        """Return probabilitas tiap kelas"""
        if self.model is None:
            return {}
        if len(features) == 0:
            return {}
        
        proba = self.model.predict_proba(features)[0]
        return {
            "hold": float(proba[0]),
            "buy": float(proba[1]),
            "sell": float(proba[2]) if len(proba) > 2 else 0.0
        }
