"""
REST API Server — bridge antara bot (Windows) dan dashboard (Linux Nocita)
Jalan di port 5000, dipanggil dashboard buat ambil data real-time
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import MetaTrader5 as mt5
from datetime import datetime
from loguru import logger

app = Flask(__name__)
CORS(app)

# Cache data terbaru
LATEST_DATA = {
    "status": "initializing",
    "price": {"bid": 0, "ask": 0},
    "account": {},
    "positions": [],
    "signal": {"action": "HOLD", "confidence": 0},
    "stats": {"total_trades": 0, "wins": 0, "losses": 0},
    "last_update": None
}


def update_latest_data(bot_state: dict):
    """Dipanggil dari main loop buat update cache"""
    global LATEST_DATA
    LATEST_DATA.update(bot_state)
    LATEST_DATA["last_update"] = datetime.now().isoformat()


@app.route("/api/status", methods=["GET"])
def get_status():
    """Endpoint: status bot real-time"""
    return jsonify(LATEST_DATA)


@app.route("/api/account", methods=["GET"])
def get_account():
    """Endpoint: info akun MT5"""
    account = mt5.account_info()
    if account is None:
        return jsonify({"error": "Gagal ambil account info"}), 500
    
    return jsonify({
        "login": account.login,
        "balance": account.balance,
        "equity": account.equity,
        "margin": account.margin,
        "margin_free": account.margin_free,
        "leverage": account.leverage,
        "currency": account.currency
    })


@app.route("/api/positions", methods=["GET"])
def get_positions():
    """Endpoint: posisi terbuka"""
    from bot.executor import get_open_positions
    return jsonify(get_open_positions())


@app.route("/api/history", methods=["GET"])
def get_history():
    """Endpoint: riwayat trade (dari database)"""
    # TODO: connect ke PostgreSQL
    return jsonify([])


@app.route("/api/command", methods=["POST"])
def post_command():
    """
    Endpoint: kirim command dari dashboard
    Body: {"command": "pause" | "resume" | "close_all" | "emergency_stop"}
    """
    data = request.json
    command = data.get("command", "")
    
    responses = {
        "pause": "Bot paused",
        "resume": "Bot resumed",
        "close_all": "Closing all positions...",
        "emergency_stop": "⚠️ Emergency stop!"
    }
    
    logger.info(f"Command dari dashboard: {command}")
    
    if command == "close_all":
        from bot.executor import close_all_positions
        closed = close_all_positions()
        return jsonify({"status": "ok", "message": f"Closed {closed} positions"})
    
    if command == "emergency_stop":
        from bot.executor import close_all_positions
        close_all_positions()
        import os
        os._exit(0)
    
    return jsonify({"status": "ok", "message": responses.get(command, "Unknown")})


def run_api_server(host="0.0.0.0", port=5000):
    """Start API server"""
    logger.info(f"API server start di {host}:{port}")
    app.run(host=host, port=port, debug=False, threaded=True)


if __name__ == "__main__":
    from bot.mt5_connector import initialize_mt5
    initialize_mt5()
    run_api_server()
