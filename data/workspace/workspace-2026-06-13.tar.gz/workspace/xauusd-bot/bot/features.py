"""
Feature Engineering — ubah data candle mentah jadi fitur ML
Semua fitur dari library ta (technical analysis) + custom
"""

import pandas as pd
import numpy as np
from loguru import logger


def add_technical_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Tambahin semua indikator teknikal ke DataFrame
    Return DataFrame dengan kolom fitur tambahan
    """
    df = df.copy()
    
    # --- RSI ---
    delta = df['close'].diff()
    gain = delta.where(delta > 0, 0.0).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # --- MACD ---
    ema12 = df['close'].ewm(span=12, adjust=False).mean()
    ema26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = ema12 - ema26
    df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # --- Bollinger Bands ---
    sma20 = df['close'].rolling(20).mean()
    std20 = df['close'].rolling(20).std()
    df['bb_upper'] = sma20 + (std20 * 2)
    df['bb_lower'] = sma20 - (std20 * 2)
    df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / sma20
    df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
    
    # --- Moving Averages ---
    df['sma_20'] = df['close'].rolling(20).mean()
    df['sma_50'] = df['close'].rolling(50).mean()
    df['sma_200'] = df['close'].rolling(200).mean()
    df['ema_9'] = df['close'].ewm(span=9, adjust=False).mean()
    df['ema_21'] = df['close'].ewm(span=21, adjust=False).mean()
    
    # --- ATR (Average True Range) ---
    high_low = df['high'] - df['low']
    high_close = abs(df['high'] - df['close'].shift(1))
    low_close = abs(df['low'] - df['close'].shift(1))
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['atr'] = true_range.rolling(14).mean()
    df['atr_pct'] = df['atr'] / df['close'] * 100
    
    # --- Price Action ---
    df['candle_size'] = abs(df['close'] - df['open']) / df['atr']
    df['upper_wick'] = df['high'] - df[['open', 'close']].max(axis=1)
    df['lower_wick'] = df[['open', 'close']].min(axis=1) - df['low']
    df['body_pct'] = (df['close'] - df['open']) / df['open'] * 100
    
    # --- Support & Resistance (sederhana) ---
    df['high_20'] = df['high'].rolling(20).max()
    df['low_20'] = df['low'].rolling(20).min()
    df['dist_support'] = (df['close'] - df['low_20']) / df['atr']
    df['dist_resistance'] = (df['high_20'] - df['close']) / df['atr']
    
    # --- Volume ---
    df['volume_sma'] = df['tick_volume'].rolling(20).mean()
    df['volume_ratio'] = df['tick_volume'] / df['volume_sma']
    
    # --- Momentum ---
    df['momentum_5'] = df['close'] - df['close'].shift(5)
    df['momentum_10'] = df['close'] - df['close'].shift(10)
    df['roc_10'] = (df['close'] / df['close'].shift(10) - 1) * 100
    
    return df


def get_feature_columns() -> list:
    """Return list kolom yang dipake sebagai fitur model"""
    return [
        'rsi', 'macd', 'macd_hist', 'macd_signal',
        'bb_width', 'bb_position',
        'atr_pct', 'candle_size', 'body_pct',
        'dist_support', 'dist_resistance',
        'volume_ratio',
        'momentum_5', 'momentum_10', 'roc_10'
    ]


def prepare_prediction_features(df: pd.DataFrame) -> np.ndarray:
    """Ambil baris terakhir, return numpy array siap prediksi"""
    feature_cols = get_feature_columns()
    
    if len(df) < 200:
        logger.warning(f"Data terlalu sedikit: {len(df)} baris")
        return np.array([])
    
    latest = df[feature_cols].iloc[-1:].copy()
    latest = latest.fillna(0)
    
    return latest.values
