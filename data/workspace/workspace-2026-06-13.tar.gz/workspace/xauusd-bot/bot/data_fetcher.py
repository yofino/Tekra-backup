"""
Ambil data harga dari MT5
- Candle OHLCV
- Tick real-time
"""

import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime, timezone
from loguru import logger
from bot.config import SYMBOL, MT5_TIMEFRAME


def get_candles(count: int = 200) -> pd.DataFrame:
    """
    Ambil candle terbaru dari MT5
    Return DataFrame dengan kolom: time, open, high, low, close, tick_volume, spread
    """
    rates = mt5.copy_rates_from_pos(SYMBOL, MT5_TIMEFRAME, 0, count)
    
    if rates is None or len(rates) == 0:
        logger.error(f"Gagal ambil data candle {SYMBOL}")
        return pd.DataFrame()
    
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    return df


def get_current_price() -> dict:
    """Ambil harga bid/ask terkini"""
    tick = mt5.symbol_info_tick(SYMBOL)
    if tick is None:
        logger.error(f"Gagal ambil tick {SYMBOL}")
        return {"bid": 0, "ask": 0}
    
    return {
        "bid": tick.bid,
        "ask": tick.ask,
        "time": datetime.fromtimestamp(tick.time, tz=timezone.utc)
    }


def is_market_open() -> bool:
    """Cek apakah market XAUUSD sedang buka"""
    symbol_info = mt5.symbol_info(SYMBOL)
    if symbol_info is None:
        return False
    return symbol_info.trade_mode != 2  # 2 = market closed


if __name__ == "__main__":
    from bot.mt5_connector import initialize_mt5
    initialize_mt5()
    
    df = get_candles(10)
    print(df.tail())
    print(get_current_price())
