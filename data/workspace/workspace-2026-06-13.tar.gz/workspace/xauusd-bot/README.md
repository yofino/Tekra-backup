# XAUUSD AI Trading Bot

## Arsitektur

```
VPS NOCITA (Linux)              VPS WINDOWS (baru)
├── PostgreSQL :5432 ◄───────── REST API :5000 ──┤
├── Dashboard :8501 ◄───────── WebSocket ────────┤
└── OpenClaw                                     ├── MT5 Terminal
                                                 ├── Python Bot Engine
                                                 ├── Model AI
                                                 └── Redis
```

## Setup

### 1. VPS Windows — Bot Engine

```powershell
# Install Python 3.12
# Install MT5 dari broker lo
# Login MT5 dengan akun demo/live

cd C:\xauusd-bot
pip install -r requirements.txt
copy .env.example .env   # isi MT5 login & path
python bot\main.py
```

### 2. VPS Nocita (Linux) — Dashboard + DB

```bash
cd ~/xauusd-bot
docker-compose up -d
# Dashboard: http://IP-NOCITA:8501
```

## Struktur Folder

```
xauusd-bot/
├── bot/                    # Windows: engine trading
│   ├── config.py           # Konfigurasi
│   ├── mt5_connector.py    # Koneksi & login MT5
│   ├── data_fetcher.py     # Tarik data candle
│   ├── features.py         # Feature engineering
│   ├── strategy/           # Strategi trading
│   ├── risk_manager.py     # Money management
│   ├── executor.py         # Eksekusi order
│   ├── api_server.py       # REST API ke dashboard
│   └── main.py             # Entry point
├── dashboard/              # Linux: monitoring
│   └── streamlit_app.py
├── training/               # Offline: training model
│   ├── prepare_data.py
│   └── train_model.py
├── docker-compose.yml      # Dashboard + DB
└── .env.example
```
