@echo off
REM ============================================
REM Start Trading Bot + API Server
REM Jalan ini tiap Windows start
REM ============================================
cd /d C:\xauusd-bot
python -m bot.main
pause
