@echo off
REM ============================================
REM Setup Script — XAUUSD Trading Bot
REM Jalanin di Windows Server 2022
REM ============================================

echo ============================================
echo  XAUUSD AI Trading Bot - Windows Setup
echo ============================================
echo.

REM --- 1. Cek Python ---
echo [1/4] Cek Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python 3.12 belum terinstall
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)
echo Python OK ✓

REM --- 2. Install library ---
echo.
echo [2/4] Install Python packages...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo ERROR: Gagal install packages
    pause
    exit /b 1
)
echo Packages OK ✓

REM --- 3. Copy .env ---
echo.
echo [3/4] Setup config...
if not exist .env (
    copy .env.example .env
    echo File .env dibuat dari template
    echo ⚠️ BUKA .env dan isi MT5_LOGIN, MT5_PASSWORD, dll!
)
echo Config OK ✓

REM --- 4. Buat folder ---
mkdir logs 2>nul
mkdir models 2>nul
echo Folder OK ✓

echo.
echo ============================================
echo  Setup selesai!
echo.
echo  Langkah selanjutnya:
echo  1. Edit file .env → isi MT5 credential
echo  2. Pastikan MT5 terminal terinstall
echo  3. Jalankan: python -m bot.main
echo ============================================
pause
