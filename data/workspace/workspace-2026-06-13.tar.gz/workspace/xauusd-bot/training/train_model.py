"""
Train model XGBoost dari data historis MT5
Jalanin di PC lokal atau VPS Windows dengan data yg cukup

Cara: python training/train_model.py
"""

import MetaTrader5 as mt5
import pandas as pd
import numpy as np
import pickle
from datetime import datetime
from loguru import logger
import sys
sys.path.insert(0, '.')

from bot.config import SYMBOL, MT5_LOGIN, MT5_PASSWORD, MT5_SERVER
from bot.features import add_technical_indicators, get_feature_columns
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score


def fetch_historical_data(years: int = 3) -> pd.DataFrame:
    """
    Ambil data historis XAUUSD H1 dari MT5
    MT5 biasanya nyimpen data 1-5 tahun di terminal
    """
    logger.info("Menginisialisasi MT5...")
    mt5.initialize()
    mt5.login(MT5_LOGIN, MT5_PASSWORD, MT5_SERVER)
    
    # Hitung jumlah candle (H1)
    total_candles = years * 365 * 24
    logger.info(f"Ambil {years} tahun data H1 (~{total_candles} candle)...")
    
    rates = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_H1, 0, total_candles)
    
    if rates is None:
        logger.error("Gagal ambil data historis")
        return pd.DataFrame()
    
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    
    logger.info(f"Data diambil: {len(df)} candle ({df['time'].min()} s/d {df['time'].max()})")
    
    mt5.shutdown()
    return df


def create_labels(df: pd.DataFrame, horizon: int = 6) -> pd.Series:
    """
    Buat label buat training:
    - 1 (BUY): harga naik > ATR*0.5 dalam horizon candle ke depan
    - 2 (SELL): harga turun > ATR*0.5 dalam horizon candle ke depan
    - 0 (HOLD): sisanya
    
    horizon: berapa candle ke depan buat hitung future return
    """
    atr = df['atr'] if 'atr' in df.columns else (df['high'] - df['low']).rolling(14).mean()
    
    future_return = df['close'].shift(-horizon) - df['close']
    threshold = atr * 0.5
    
    labels = np.zeros(len(df))
    labels[future_return > threshold] = 1   # BUY
    labels[future_return < -threshold] = 2  # SELL
    
    # Hapus label di ujung data (gak ada future)
    labels[-horizon:] = np.nan
    
    logger.info(f"Label: {np.sum(labels==1)} BUY, {np.sum(labels==2)} SELL, "
                f"{np.sum(labels==0)} HOLD")
    
    return pd.Series(labels, index=df.index)


def train():
    # 1. Ambil data
    df = fetch_historical_data(years=3)
    if df.empty:
        return
    
    # 2. Feature engineering
    logger.info("Feature engineering...")
    df = add_technical_indicators(df)
    df = df.dropna()
    
    # 3. Labeling
    logger.info("Membuat label...")
    labels = create_labels(df, horizon=6)
    df['label'] = labels
    df = df.dropna(subset=['label'])
    
    # 4. Prepare data
    feature_cols = get_feature_columns()
    X = df[feature_cols]
    y = df['label'].astype(int)
    
    # 5. Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=False
    )
    
    logger.info(f"Training: {len(X_train)} sampel, Testing: {len(X_test)} sampel")
    
    # 6. Train model
    model = XGBClassifier(
        n_estimators=200,
        max_depth=5,
        learning_rate=0.1,
        objective='multi:softprob',
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42
    )
    
    logger.info("Training XGBoost...")
    model.fit(X_train, y_train)
    
    # 7. Evaluasi
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    logger.info(f"\nAkurasi: {acc:.4f}")
    logger.info("\n" + classification_report(y_test, y_pred,
                                             target_names=['HOLD', 'BUY', 'SELL']))
    
    # 8. Feature importance
    importance = pd.DataFrame({
        'feature': feature_cols,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)
    logger.info("\nTop 10 fitur:\n" + importance.head(10).to_string())
    
    # 9. Simpan model
    model_path = "models/xgboost_xauusd.pkl"
    import os
    os.makedirs("models", exist_ok=True)
    
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    
    logger.info(f"\n✅ Model disimpan ke {model_path}")


if __name__ == "__main__":
    train()
