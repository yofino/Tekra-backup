# Topologi Infrastruktur TekraNet

```
                                    ┌─────────────────────┐
                                    │    CLOUD / VPS       │
                                    ├─────────────────────┤
                                    │ Nocita (103.129.148) │
                                    │ • Portal ERP/Billing │
                                    │ • Siti (AI CS Agent) │
                                    │ • aaPanel / Webmail  │
                                    │ • Mail Server        │
                                    ├─────────────────────┤
                                    │ TekraApp (103.197)   │
                                    │ • aaPanel / Apps     │
                                    └──────────┬──────────┘
                                               │
            ════════════════════════════════════╪════════════════════════════════════
                                               │
┌──────────────────────────────────────────────┴──────────────────────────────────────────────┐
│                                      POP PUSAT (HQ)                                         │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│  │                              ISP / WAN (Total: 2.250M)                               │   │
│  ├─────────────────────────────────────────────────────────────────────────────────────┤   │
│  │ Simaya (PBR)  │  MyRep ×3 (250M)  │  Sunmory ×2 (250M)  │  Indibiz (300M)           │   │
│  └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                          │                                                  │
│  ┌───────────────────────────────────────┴──────────────────────────────────────────────┐   │
│  │                        pfSense Pusat (192.168.123.1)                                 │   │
│  │                  WAN1 .50 │ WAN2 .60 │ WAN3 .70 │ WAN4 .80 │ WAN5 .90 │ WAN7 .110   │   │
│  │                                                   WAN6 .124 ←── VLAN Cilisung 600M   │   │
│  └───────────────────────────────────────┬──────────────────────────────────────────────┘   │
│                                          │                                                  │
│  ┌───────────────────────────────────────┴──────────────────────────────────────────────┐   │
│  │                      MikroTik x86 Pusat (CCR2116-12G-4S+)                           │   │
│  │                        IP: 172.80.10.100  |  ROS 7.11.3                              │   │
│  │                        PPPoE Server  |  DHCP  |  VLAN Backbone                       │   │
│  └───┬──────────┬──────────┬──────────┬──────────┬──────────┬──────────┬───────────────┘   │
│      │          │          │          │          │          │          │                    │
│  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──┐  ┌───┴──────────┐          │
│  │CCR1  │  │CCR2/ │  │OLT   │  │OLT   │  │ACS   │  │Zabbix│  │Server Room    │          │
│  │Hotsp │  │ X86  │  │EPON  │  │GPON  │  │TR069 │  │Monit │  │Proxmox,NVR,.. │          │
│  │.10.1 │  │PPPoE │  │.10. │  │.10.  │  │.10.  │  │.10.18│  │.10.4,.10,.207│          │
│  │PUB:  │  │PUB:  │  │203   │  │204   │  │230   │  └──────┘  └───────────────┘          │
│  │115.  │  │103.  │  └──────┘  └──────┘  └──────┘                                        │
│  │178.. │  │171.. │                                                                        │
│  └──────┘  └──────┘                                                                        │
│                       └──────┘  └──────┘  └──────┘                                        │
│                                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│  │                           VLAN PPPoE Area                                            │   │
│  ├─────────────────────────────────────────────────────────────────────────────────────┤   │
│  │ vlan3 Bojong Seureuh │ vlan4 Bojong Suren │ vlan5 Bojong Suren Girang               │   │
│  │ vlan7 Sukaluyu       │ vlan8 Ciburuy      │ vlan9 PPPoE GPON                        │   │
│  └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
          │                         │                         │
          │ VLAN (40/41)            │ OVPN                    │ Tunnel
          │ 600M Backhaul           │                         │
          ▼                         ▼                         ▼
┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐
│   POP CILISUNG      │  │     POP DAGO        │  │   POP KATAPANG      │
├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤
│ ISP: MyRep (250M)   │  │ ISP: Simaya (PBR)   │  │ ISP: MyRep (250M)   │
│      MyRep (500M)   │  │      MyRep ×3 (250) │  │      Primacom (PBR) │
│ Total: 750M         │  │      Sunmory (300)  │  │ Total: 350M         │
│ LB Aktif: 600M→Pusat│  │ Total: 1.150M       │  │ LB Aktif: 250M      │
│                     │  │ LB Aktif: 1.050M    │  │                     │
│ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │ ┌─────────────────┐ │
│ │ GX4 (10.7.0.8)  │ │  │ │CCR1009(10.6.0.2)│ │  │ │RB450Gx4(10.7.0.9│ │
│ │ RB4011iGS+      │ │  │ │ROS 6.48.6 CPU82%│ │  │ │ROS 7.19 CPU 55% │ │
│ │ ROS 7.16 CPU 40%│ │  │ │PPPoE + Hotspot  │ │  │ │PPPoE            │ │
│ └─────────────────┘ │  │ └─────────────────┘ │  │ └─────────────────┘ │
│                     │  │                     │  │                     │
│ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │                     │
│ │pfSense(192.168.  │ │  │ │pfSense(115.178. │ │  │                     │
│ │124.1)            │ │  │ │49.186:1042)     │ │  │                     │
│ │WAN6 backhaul     │ │  │ │WAN1-4 41-44.1   │ │  │                     │
│ │                  │ │  │ │Celeron J1900     │ │  │                     │
│ └─────────────────┘ │  │ └─────────────────┘ │  │                     │
│                     │  │                     │  │                     │
│ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │                     │
│ │OLT HSGQ-E04ID   │ │  │ │OLT HSGQ (ether5)│ │  │                     │
│ │(192.168.101.10) │ │  │ │OLT HIOSO(ether6)│ │  │                     │
│ │EPON 52 ONU(PON1)│ │  │ │                  │ │  │                     │
│ └─────────────────┘ │  │ └─────────────────┘ │  │                     │
└─────────────────────┘  └─────────────────────┘  └─────────────────────┘
```

## Ringkasan Per POP

| POP | MikroTik | pfSense | OLT | ISP |
|---|---|---|---|---|
| **PUSAT** | CCR1 (10.10.10.1) Hotspot<br>CCR2/X86 (172.80.10.100) PPPoE | 192.168.123.1 | EPON (.203) + GPON (.204) | Simaya, MyRep×3, Sunmory×2, Indibiz |
| **CILISUNG** | RB4011 (10.7.0.8) | 192.168.124.1 | HSGQ-E04ID (.101.10) | MyRep ×2 (via Pusat) |
| **DAGO** | CCR1009 (10.6.0.2) | 115.178.49.186:1042 | HSGQ + HIOSO | Simaya, MyRep×3, Sunmory |
| **KATAPANG** | RB450Gx4 (10.7.0.9) | — | — | MyRep, Primacom |

## MikroTik Router Detail

| Router | IP Internal | IP Publik | Board | ROS | SSH | Fungsi |
|---|---|---|---|---|---|---|
| **CCR1** | 10.10.10.1 | 115.178.49.186 (Simaya) | CCR1009-7G-1C-1S+ | 6.49.13 | asep:18 | Hotspot |
| **CCR2/X86** | 172.80.10.100 | 103.171.149.136 (cloud) | CCR2116-12G-4S+ | 7.11.3 | asep:18 | PPPoE Server |
| **Cilisung GX4** | 10.7.0.8 | — | RB4011iGS+ | 7.16.1 | asep:18 | PPPoE Cilisung |
| **Katapang** | 10.7.0.9 | — | RB450Gx4 | 7.19.4 | asep:18 | PPPoE Katapang |
| **Dago** | 10.6.0.2 | — | CCR1009 | 6.48.6 | asep:18 | PPPoE Dago |

## pfSense WAN Mapping (Pusat)

| WAN | Gateway IP | ISP | Speed | Status (16 Mei 2026) |
|---|---|---|---|---|
| WAN1 | 192.168.123.50 | MyRepublic | 250M | 🟢 Online |
| WAN2 | 192.168.123.60 | MyRepublic | 250M | ⚠️ Dimatikan (throttled 2Mbps) |
| WAN3 | 192.168.123.70 | MyRepublic | 250M | 🟢 Online |
| WAN4 | 192.168.123.80 | Sunmory | 250M | 🟢 Online |
| WAN5 | 192.168.123.90 | Sunmory | 250M | 🟢 Online |
| WAN6 | 192.168.123.124 | Cilisung Backhaul (DHCP) | 600M | 🟢 Online |
| WAN7 | 192.168.123.110 | Telkom | 300M | 🟢 Online |

## Konektivitas Antar POP
- **Pusat ↔ Cilisung:** VLAN Backhaul (40/41, 600M)
  - Cilisung → Pusat: DHCP via pfSense Cilisung ke pfSense Pusat WAN6
  - Pusat → Cilisung: VLAN via X86 Bridge Backbone → SFP Cilisung
  - Topologi bulak-balik di kabel FO yg sama (peer-to-peer)
  - Router Cilisung: DNS sendiri (8.8.8.8, 8.8.4.4), gak forward ke X86
- **Pusat ↔ Dago:** OVPN ethernet via pfSense + OVPN cloud
- **Pusat ↔ Katapang:** Tunnel

## Server & Infrastruktur
| Server | IP | Fungsi |
|---|---|---|
| Zabbix + Grafana | 10.10.10.18 | Monitoring (grafana:3000, zabbix:3000) |
| ACS GenieACS | 10.10.10.230 | TR-069 ONT Management |
| Proxmox VE | 10.10.10.4 | Virtualisasi |
| NVR Dahua | 10.10.10.10 | CCTV |
| Hikvision | 10.10.10.207 | Access Control |
| OpenClaw Asep | 10.10.10.18 | AI NOC Agent |
| Mini PC | 10.10.10.205 | RDP via CCR1:33899 |
| VPS Nocita | 103.129.148.97 | Portal + Mail + Siti AI |
| VPS TekraApp | 103.197.191.8 | Apps |

## Monitoring (Zabbix + Grafana)
- **Grafana**: http://10.10.10.18:3000 (admin / admin123)
- **Dashboard WAN**: http://10.10.10.18:3000/d/24a45def (42 panels)
- **Zabbix**: http://10.10.10.18:3000 (Admin / k34Nu335577 — blocked sementara)
- **Gateway script**: `/opt/scripts/pf_gateway.sh` (HTTPS scrape)
- **SNMP proxy**: `/opt/scripts/pf_dago_snmp.sh`, `/opt/scripts/pf_cilisung_snmp.sh`

## DNS Cache (updated 16 Mei 2026)
- **PUSAT X86:** cache-size 8192KB, cache-max-ttl **1w** (dimundurin dari 1d)
- **CILISUNG GX4:** cache-size 4096KB, cache-max-ttl **1w**
- Default MikroTik: cache-size=2048KB, cache-max-ttl=1w
- Perubahan 14 Mei (all routers): 2048→4096KB, 1w→1d
- 16 Mei: X86 penuh 99.7% (4085/4096KB) akibat TTL 1d + 666 klien (Pusat 495 + Cilisung 171)
- 16 Mei fix: Flush + X86 upgrade 4096→8192KB, TTL balik 1w
- Penting: DNS cuma dipake di awal koneksi, expired gak bikin koneksi putus

## WhatsApp CDN Monitoring
- **Zabbix items:** host 10084 — wa.cdn[pusat,loss|rtt], wa.cdn[cilisung,loss|rtt]
- **Triggers:** loss > 50% (HIGH), RTT > 200ms (WARNING)
- **Script:** /opt/scripts/monitor_whatsapp.sh, /opt/scripts/zabbix_send_wa.py
- **Cron:** tiap 5 menit cek + alert WA ke Yofi kalau loss > 30%
- **Rute WA:** Pusat via MyRep WAN1-3 / Indibiz WAN4 (load balance), Cilisung via Telkom (125.161.x.x)
- Target ping: 57.144.101.32 (WhatsApp CDN Jakarta CGK2)

## Portal Billing
| Area | URL |
|---|---|
| Pusat | portal.tekra.id |
| Dago | north.my.id |
| Katapang | southnet.my.id |

## Total Kapasitas ISP
- **Beli:** ~4.500 Mbps
- **LB Aktif:** ~3.450 Mbps
