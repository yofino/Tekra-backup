# PRD — NetPilot: SaaS Billing ISP + HR + AI

> **Product Name**: NetPilot (by **Tekra** — PT Teknologi Rakyat)
> **Brand Family**: Pilot Series — NetPilot / FitPilot / WorkPilot
> **Version**: 1.0 MVP
> **Author**: Ujang
> **Date**: 1 Juni 2026
> **Status**: Draft — Siap Eksekusi Claude Code
> **Philosophy**: *"Pilot your network. We'll handle the controls."*

---

## 1. Executive Summary

NetPilot adalah SaaS multi-tenant untuk ISP skala kecil-menengah di Indonesia. Menggabungkan billing internet, manajemen jaringan, HR/payroll, dan AI assistant dalam satu platform. Di bawah brand **Tekra** (PT Teknologi Rakyat), NetPilot adalah produk pertama dari **Pilot Series** — keluarga produk SaaS untuk bisnis Indonesia.

Target market: 2.000+ ISP kecil di Indonesia yang masih pakai Excel / sistem manual.

**Unique Selling Point**: AI NOC Assistant 24/7 + WhatsApp-integrated customer service + Hikvision attendance — tidak ada kompetitor yang menawarkan ini dalam satu paket.

---

## 2. Tech Stack Recommendation

| Layer | Teknologi | Alasan |
|-------|-----------|--------|
| **Backend** | Laravel 11 | Ekosistem matang, queue, notification, Eloquent ORM |
| **Frontend** | Livewire 3 + Alpine.js | Reactivity tanpa SPA overhead, server-rendered |
| **CSS** | Tailwind CSS 3.4 + DaisyUI | Cepat, customizable, mobile-first |
| **Database** | MySQL 8 / MariaDB | Familiar, JSON columns, window functions |
| **Cache** | Redis | Queue, real-time, rate limiting |
| **Queue** | Laravel Horizon | MikroTik jobs, WhatsApp blast, invoice generation |
| **Realtime** | Laravel Reverb | WebSocket untuk dashboard live |
| **Mobile** | Flutter 3.x (Android + iOS native) | Satu codebase, kamera real-time, GPS anti-fake, offline mode |
| **AI/LLM** | OpenAI / DeepSeek API | Chatbot, NOC assistant, analytics |
| **WhatsApp** | WhatsApp Business Cloud API | Notifikasi, CS chat, reminder |
| **Payment** | Midtrans + Duitku | Coverage payment terluas Indonesia |

---

## 3. Architecture

```
┌─────────────────────────────────────────────────┐
│                  LOAD BALANCER                   │
├─────────────────────────────────────────────────┤
│                   WEB SERVER                     │
│  Laravel App (multi-tenant middleware)           │
├─────────────────────────────────────────────────┤
│              ┌──────────────────┐               │
│  DATABASE    │  QUEUE / REDIS   │  STORAGE      │
│  MySQL       │  Horizon         │  S3/Local     │
│  (per-tenant │  Jobs + Cache    │               │
│   schema)    └──────────────────┘               │
├─────────────────────────────────────────────────┤
│              EXTERNAL INTEGRATIONS               │
│  MikroTik  │ OLT │ Hikvision │ WhatsApp │ AI    │
│  SSH/API   │ API │ API       │ Cloud API│ LLM   │
└─────────────────────────────────────────────────┘
```

**Multi-tenant Strategy**: Database per tenant (schema isolation). Satu database master untuk tenant management + subscription.

---

## 4. Modules Detail

---

### MODUL A: Multi-Tenant Core

| Feature | Priority | Description |
|---------|----------|-------------|
| Tenant Registration | P0 | Daftar ISP baru, trial 14 hari |
| Tenant Database | P0 | Auto-create schema per tenant |
| Subscription Plan | P0 | Starter/Pro/Enterprise, auto-renew |
| White-label | P1 | Logo, nama, domain custom, warna tema |
| Billing Tenant | P1 | Invoice tenant, payment history |
| Audit Log | P1 | Semua aktivitas tercatat |

### MODUL B: Customer Management (CRM)

| Feature | Priority | Description |
|---------|----------|-------------|
| Customer CRUD | P0 | Nama, alamat, no WA, koordinat |
| No Services Generator | P0 | Auto-generate ID unik (format custom) |
| Status Management | P0 | Aktif, Isolir, Menunggu, Non-Aktif |
| Coverage Area | P0 | CRUD area, kode area, ODC/ODP |
| Package Assignment | P0 | Assign paket ke pelanggan |
| Import/Export Excel | P1 | Bulk import, export data |
| Customer Portal | P2 | Self-service: cek tagihan, bayar, tiket |
| Customer Map View | P2 | Leaflet.js, visualisasi geografis |

### MODUL C: Billing & Invoice

| Feature | Priority | Description |
|---------|----------|-------------|
| Auto Invoice Generation | P0 | Cron job bulanan, generate tagihan otomatis |
| Invoice Template | P0 | PDF invoice, QR code payment |
| Payment Status | P0 | Belum Bayar, Sudah Bayar, Terkirim |
| Due Date Management | P0 | Jatuh tempo, grace period, denda |
| Bill History | P1 | Riwayat tagihan per pelanggan |
| Reminder Automation | P1 | WhatsApp/Email H-7, H-3, H-1, Jatuh Tempo |
| Multi Payment Method | P1 | QRIS, VA, Bank Transfer, Retail, E-Wallet |
| Recurring Bill | P1 | Tagihan non-internet (listrik, BPJS) |
| Payment Reconciliation | P1 | Auto-detect payment via Moota/webhook |
| Tax Configuration | P2 | PPN 11%, PPh |

### MODUL D: Finance & Accounting

| Feature | Priority | Description |
|---------|----------|-------------|
| Income Management | P0 | CRUD pemasukan, kategori, coverage |
| Expense Management | P0 | CRUD pengeluaran, upload bukti |
| Cash Flow Dashboard | P0 | Revenue vs expense, profit/loss |
| Monthly Report | P1 | Report P&L, export PDF/Excel |
| Bank Management | P1 | Multiple bank accounts |
| Commission | P2 | Komisi sales/teknisi |

### MODUL E: Network Integration

| Feature | Priority | Description |
|---------|----------|-------------|
| MikroTik Router CRUD | P0 | Tambah/manage router, SSH + API |
| PPPoE Management | P0 | Create/disable/delete user, active sessions |
| Hotspot Management | P1 | User, profile, active, binding |
| Traffic Monitoring | P1 | Per interface, per client, grafik |
| Auto Isolir | P0 | Auto-disable PPPoE jika tagihan overdue |
| Auto Open | P0 | Auto-enable setelah pembayaran |
| Speed Profile Sync | P1 | Sinkronisasi paket → profil MikroTik |
| OLT Integration | P1 | HSGQ, HIOSO, VSOL, CData |
| GenieACS Integration | P0 | **ONT Monitoring**: RX Power, suhu, uptime, firmware, active devices per ONT. **Remote Config**: ganti WiFi SSID/Password, reboot ONT, factory reset, VLAN config, firmware upgrade. **Customer Portal**: pelanggan bisa ganti password WiFi sendiri tanpa telpon teknisi. **Bulk Operations**: push config ke banyak ONT sekaligus
| Network Dashboard | P1 | Status WAN, CPU, uptime semua router |
| Backup Config | P2 | Auto-backup MikroTik config |

### MODUL F: Helpdesk / Ticketing

| Feature | Priority | Description |
|---------|----------|-------------|
| Ticket CRUD | P0 | Open, Process, Pending, Close |
| Assign Technician | P0 | Assign ke teknisi, notifikasi WA |
| Ticket Timeline | P1 | Log aktivitas tiket |
| Customer Portal Tickets | P2 | Pelanggan buka tiket sendiri |
| SLA Management | P2 | Response time, resolution time |
| AI Ticket Classifier | P1 | Auto-kategori + prioritas + assign |

### MODUL G: HR / Attendance (ANTI-FAKE)

| Feature | Priority | Description |
|---------|----------|-------------|
| Photo Capture Check-in | P0 | Real-time foto (bukan upload gallery). Selfie + timestamp wajib |
| Anti-Fake GPS | P0 | Multi-layer validation: EXIF GPS, IP geolocation, WiFi networks, accuracy check, mock location detection, speed anomaly, altitude check. Trust score 0-100 per check-in |
| Manual + GPS Attendance | P0 | Check-in via PWA dengan foto + lokasi auto-tagged |
| Hikvision Integration | P0 | Tarik log dari DS-K1T320MFX via ISAPI |
| Trust Score Audit | P0 | Score < 70 flag review, < 40 auto-reject + notif admin |
| Shift Management | P1 | Shift pagi/siang/malam, flexi |
| Overtime Calculation | P1 | Auto-hitung lembur |
| Leave Management | P1 | Cuti, sakit, izin + approval |
| Attendance Report | P1 | Rekap harian/bulanan, export |
| Real-time Dashboard | P1 | Hadir, terlambat, absen + peta lokasi |

### MODUL H: Payroll

| Feature | Priority | Description |
|---------|----------|-------------|
| Salary Structure | P0 | Gaji pokok, tunjangan, potongan |
| Auto Salary Calc | P0 | Gaji = pokok + tunjangan - potongan + lembur |
| BPJS Calculation | P1 | Auto PPh 21, BPJS TK & Kesehatan |
| Digital Payslip | P1 | PDF slip gaji, kirim WA/Email |
| Bank Transfer Export | P1 | Format BCA/Mandiri/BRI |
| THR Calculator | P2 | THR proporsional |
| Payroll History | P1 | Riwayat gaji, filter |

### MODUL I: AI Assistant

| Feature | Priority | Description |
|---------|----------|-------------|
| AI Customer Service | P1 | Chatbot website/WA, jawab FAQ, cek tagihan |
| AI NOC Monitor | P1 | Monitor 24/7, alert, troubleshoot |
| AI Bill Collector | P2 | Follow-up tagihan via WA, natural language |
| AI Churn Predictor | P2 | Prediksi pelanggan mau cabut |
| AI Upsell Recommender | P2 | Rekomendasi upgrade paket |
| AI Ticket Router | P1 | Auto-kategori + prioritas tiket |

### MODUL J: Inventory

| Feature | Priority | Description |
|---------|----------|-------------|
| Item CRUD | P2 | ONT, kabel, alat, kategori |
| Stock Management | P2 | In/out, minimum stock alert |
| Asset Tracking | P2 | Assign ke pelanggan/teknisi |

---

## 5. Data Model (Key Tables)

```
tenants              — Tenant ISP (id, name, domain, plan, status)
tenant_subscriptions — Subscription (plan, start, end, payment)

customers            — Pelanggan (no_services PK, name, address, wa, 
                       coverage_id, router_id, package_id, status)
coverages            — Area coverage (code PK, name, odc, odp, coordinates)
packages             — Paket internet (name, speed, price, mikrotik_profile)
routers              — Router MikroTik (ip, port, user, pass, type)
invoices             — Tagihan (inv_number, customer_no, amount, due_date, status)
invoice_items        — Detail tagihan
payments             — Pembayaran (invoice_id, amount, method, date, proof)
incomes              — Pemasukan (amount, category, date, coverage)
expenses             — Pengeluaran (amount, category, date, receipt)

tickets              — Tiket (no, customer_id, subject, status, technician_id)
ticket_timelines     — Log aktivitas tiket

employees            — Karyawan (name, nip, position, shift, salary)
attendances          — Absensi (employee_id, date, time_in, time_out, source)
leaves               — Cuti (employee_id, type, start, end, status)
payrolls             — Gaji (employee_id, period, basic, allowances, deductions, net)
payslip_items        — Detail slip gaji

ai_conversations     — Log chat AI
ai_settings          — Konfigurasi AI per tenant
```

---

## 6. API Design (RESTful)

```
# Auth
POST   /api/v1/auth/login
POST   /api/v1/auth/logout
GET    /api/v1/auth/me

# Customers
GET    /api/v1/customers
POST   /api/v1/customers
GET    /api/v1/customers/{no_services}
PUT    /api/v1/customers/{no_services}
DELETE /api/v1/customers/{no_services}

# Invoices
GET    /api/v1/invoices
POST   /api/v1/invoices
GET    /api/v1/invoices/{id}
POST   /api/v1/invoices/{id}/pay

# MikroTik
GET    /api/v1/routers/{id}/pppoe-active
POST   /api/v1/routers/{id}/pppoe-users
DELETE /api/v1/routers/{id}/pppoe-users/{name}
POST   /api/v1/routers/{id}/isolir/{customer}
POST   /api/v1/routers/{id}/un-isolir/{customer}

# Attendance
GET    /api/v1/attendances
POST   /api/v1/attendances/check-in
POST   /api/v1/attendances/check-out

# Payroll
GET    /api/v1/payrolls
POST   /api/v1/payrolls/calculate
GET    /api/v1/payrolls/{id}/payslip

# AI
POST   /api/v1/ai/chat
POST   /api/v1/ai/noc/analyze
GET    /api/v1/ai/recommendations

# Webhooks (untuk payment gateway)
POST   /api/v1/webhooks/midtrans
POST   /api/v1/webhooks/duitku
POST   /api/v1/webhooks/moota
```

All endpoints: `Accept: application/json`, `Authorization: Bearer {token}`, rate limited, paginated.

---

## 7. Security Requirements

| Requirement | Implementation |
|-------------|---------------|
| Authentication | Laravel Sanctum (SPA) + JWT (API) |
| Password Policy | Bcrypt, min 8 char, force reset first login |
| CSRF | Built-in Laravel |
| XSS | Auto-escape Blade output |
| SQL Injection | Eloquent prepared statements |
| Rate Limiting | 60 req/min API, 5 login attempts |
| CORS | Whitelist tenant domains only |
| Encryption | AES-256 for sensitive data |
| Audit Log | All CRUD operations logged |
| 2FA | OTP via WhatsApp/Email (P2) |
| Backup | Daily auto-backup, 30-day retention |

---

## 8. Development Roadmap

### Phase 1: MVP (4-6 minggu)
- [ ] Multi-tenant core + auth
- [ ] Customer + Coverage
- [ ] Billing + Invoice
- [ ] MikroTik basic (PPPoE, Isolir)
- [ ] Payment gateway (Midtrans)
- [ ] Dashboard analytics

### Phase 2: Growth (6-8 minggu)
- [ ] Finance module
- [ ] Ticketing system
- [ ] HR: Attendance + Payroll
- [ ] Hikvision integration
- [ ] WhatsApp notification
- [ ] Customer portal

### Phase 3: AI + Advanced (8-10 minggu)
- [ ] AI Customer Service
- [ ] AI NOC Assistant
- [ ] OLT/ACS integration
- [ ] Inventory
- [ ] White-label

### Phase 4: Mobile App (8-10 minggu)
- [ ] Flutter Android + iOS app
- [ ] Real-time photo attendance (anti-fake)
- [ ] Technician ticket management
- [ ] Customer self-service
- [ ] Push notification
- [ ] Offline mode

---

## 9. Competitor Comparison

| Fitur | Tekra (Old CI3) | **NetPilot (Tekra)** | Mikhmon | ISPConfig |
|-------|-------------|---------|---------|-----------|
| Multi-tenant | ❌ | ✅ | ❌ | ❌ |
| AI Assistant | ❌ | ✅ | ❌ | ❌ |
| HR + Payroll | ❌ | ✅ | ❌ | ❌ |
| WhatsApp CS | ✅ | ✅ | ❌ | ❌ |
| Mobile App | ❌ | ✅ PWA | ❌ | ❌ |
| Multi-payment | ✅ | ✅ | ❌ | ✅ |
| White-label | ❌ | ✅ | ❌ | ❌ |
| OLT/ACS | ✅ | ✅ | ❌ | ❌ |
| API | Partial | ✅ Full | ❌ | ✅ |

---

## 10. Estimated Revenue Model

| Plan | Price/mo | Customers | Features |
|------|----------|-----------|----------|
| **Starter** | Rp 199K | Up to 200 | Core billing + MikroTik |
| **Pro** | Rp 499K | Up to 1K | + AI CS, WhatsApp, HR Basic |
| **Enterprise** | Rp 1.5M | Unlimited | + AI NOC, White-label, API, Full HR |

**Target**: 50 tenant ISP × Rp 500K avg = **Rp 25jt MRR** dalam 12 bulan.

---

*Dokumen ini siap diberikan ke Claude Code untuk eksekusi build tahap 1.*
