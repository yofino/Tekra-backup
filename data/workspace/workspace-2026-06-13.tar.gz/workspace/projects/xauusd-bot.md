# XAUUSD Trading Bot — Project Progress

**Mulai:** 23 Mei 2026
**Status:** Planning / Setup

---

## Arsitektur

| Komponen | Lokasi | Fungsi |
|---|---|---|
| Bot Engine + MT5 | **Windows VPS** (atau PC desktop) | Loop trading 24/5, eksekusi order, model AI |
| Dashboard | **VPS Nocita** (Docker) | Streamlit monitoring |
| Database | **VPS Nocita** | PostgreSQL |
| Notifikasi | **VPS Nocita** | OpenClaw → WhatsApp alert |
| Training Model | **PC lokal / terpisah** | Training XGBoost → file .pkl |

## Flow

1. Training model di PC → dapet file `.pkl`
2. Copy `.pkl` ke folder `models/` di Windows VPS
3. Bot jalan 24/5: cek candle → AI prediksi → eksekusi
4. Database + dashboard di Nocita buat monitoring
5. OpenClaw kirim alert real-time ke WhatsApp

## OpenClaw — Alert ke WA

- ⚠️ Stop Loss kena → notif nominal loss
- ✅ Take Profit kena → notif profit
- 🔴 MT5 disconnect → alert
- 📊 Daily recap → ringkasan harian
- 🚨 Drawdown limit → auto pause warning

## Spek Windows (Desktop / VPS)

- **CPU:** i3 gen 8+ / Ryzen 3
- **RAM:** 8GB (16GB recommended)
- **Storage:** SSD 100GB+
- **OS:** Windows 10/11 Pro 64-bit
- **Internet:** Stabil, latency rendah ke broker
- **Syarat desktop:** Harus nyala 24/5, listrik aman (UPS recommended)

## Struktur Project

```
xauusd-bot/
├── bot/                          → Windows VPS
│   ├── config.py                 # Konfigurasi dari .env
│   ├── mt5_connector.py          # Koneksi & login MT5
│   ├── data_fetcher.py           # Tarik harga candle & tick
│   ├── features.py               # 15+ indikator teknikal
│   ├── risk_manager.py           # SL/TP, lot size, drawdown
│   ├── executor.py               # BUY/SELL/Close order
│   ├── api_server.py             # REST API (port 5000)
│   ├── strategy/__init__.py      # RuleBased + XGBoost
│   └── main.py                   # Loop utama 24/5
├── dashboard/                    → VPS Nocita (Docker)
│   └── streamlit_app.py          # Dashboard monitoring
├── training/                     → PC/VPS (offline)
│   └── train_model.py            # Training XGBoost
├── scripts/                      → Windows
│   ├── setup_windows.bat         # Auto setup
│   └── start_bot.bat             # Start bot
├── docker-compose.yml            # DB + Dashboard di Nocita
├── requirements.txt
└── .env.example
```

## Setup — Step by Step

### Sekarang (nunggu VPS, testing di PC)
- [ ] Copy project ke PC lokal
- [ ] Install Python 3.12 + `pip install -r requirements.txt`
- [ ] Copy `.env.example` → `.env`, isi MT5 credential
- [ ] Test koneksi: `python -m bot.mt5_connector`

### Setelah VPS Windows siap
- [ ] Copy project ke `C:\xauusd-bot`
- [ ] Install Python + MT5
- [ ] Jalanin `scripts/setup_windows.bat`
- [ ] Test: `python -m bot.main` (mode demo dulu)

### Di VPS Nocita
- [ ] Copy `docker-compose.yml` + folder `dashboard/`
- [ ] Edit `API_URL` → arahkan ke IP Windows VPS
- [ ] `docker-compose up -d`
- [ ] Buka `http://IP-NOCITA:8501`

---

## Log

- **23 Mei 2026** — Arsitektur disetujui, bahas spek Windows, OpenClaw role, save progress
