#!/usr/bin/env python3
"""
Network Quality Monitor + TraceRoute
Silent unless ada masalah. Kalau alert → include tracepath & per-WAN info.
"""

import subprocess, sys, json, os, re
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

# ── Persistence State ────────────────────────
STATE_FILE = "/tmp/network_monitor_state.json"

def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except:
        return {}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)

def should_alert(issue_key):
    """Only alert if issue seen in 2+ consecutive checks"""
    state = load_state()
    prev = state.get(issue_key, 0)
    state[issue_key] = prev + 1
    # Clean up stale issues not seen this run (handled at end)
    save_state(state)
    return state[issue_key] >= 2

ZBX_URL = "http://10.10.10.18/zabbix/api_jsonrpc.php"
ZBX_USER = "Admin"; ZBX_PASS = "zabbix"

# ── WAN to ISP Mapping (from ref-topology.md) ──
WAN_ISP_MAP = {
    "WAN1": ("MyRepublic", "250M"),
    "WAN2": ("MyRepublic", "250M"),
    "WAN3": ("MyRepublic", "250M"),
    "WAN4": ("Sunmory", "250M"),
    "WAN5": ("Sunmory", "250M"),
    "WAN6": ("Cilisung BH", "600M"),
    "WAN7GW": ("Telkom", "300M"),
}

# ── Zabbix ───────────────────────────────────
def zabbix(token, method, params):
    r = requests.post(ZBX_URL, json={
        "jsonrpc": "2.0", "method": method,
        "params": params, "auth": token, "id": 1
    }, timeout=10)
    return r.json().get("result", [])

def zabbix_login():
    r = requests.post(ZBX_URL, json={
        "jsonrpc": "2.0", "method": "user.login",
        "params": {"username": ZBX_USER, "password": ZBX_PASS}, "id": 1
    }, timeout=10)
    return r.json().get("result", "")

# ── Ping ─────────────────────────────────────
def ping_host(host):
    try:
        r = subprocess.run(["ping", "-c", "5", "-W", "2", host],
                          capture_output=True, text=True, timeout=15)
        stdout = r.stdout
        if "statistics" not in stdout:
            return (host, None, None, None, None, "blocked")
        loss_m = re.search(r'(\d+)% packet loss', stdout)
        loss = int(loss_m.group(1)) if loss_m else 100
        avg_m = re.search(r'rtt min/avg/max/mdev = ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)', stdout)
        if avg_m:
            rtt_min, rtt_avg, rtt_max, jitter = float(avg_m.group(1)), float(avg_m.group(2)), float(avg_m.group(3)), float(avg_m.group(4))
        else:
            avg_m = re.search(r'= ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)', stdout)
            if avg_m:
                rtt_min, rtt_avg, rtt_max, jitter = float(avg_m.group(1)), float(avg_m.group(2)), float(avg_m.group(3)), float(avg_m.group(4))
            else:
                rtt_min, rtt_avg, rtt_max, jitter = 0, 0, 0, 0
        return (host, loss, rtt_min, rtt_avg, rtt_max, "ok")
    except:
        return (host, 100, 0, 0, 0, "timeout")

# ── ISP Detection ────────────────────────────
def detect_isp(ip):
    """Try to identify ISP name from IP"""
    # Internal/private IPs
    if ip.startswith(('10.', '192.168.', '172.16.', '172.17.', '172.18.', '172.19.',
                      '172.20.', '172.21.', '172.22.', '172.23.', '172.24.', '172.25.',
                      '172.26.', '172.27.', '172.28.', '172.29.', '172.30.', '172.31.')):
        return "internal"
    
    # Known gateway IPs
    if ip == '10.10.10.1':
        return "MikroTik Gateway"
    
    try:
        # Try reverse DNS first (fastest)
        r = subprocess.run(["dig", "+short", "-x", ip],
                          capture_output=True, text=True, timeout=3)
        rdns = r.stdout.strip()
        if rdns:
            # Extract meaningful name from rDNS
            rdns_lower = rdns.lower()
            for pattern, isp in [
                ("myrepublic", "MyRepublic"),
                ("telkom", "Telkom"),
                ("telkomsel", "Telkomsel"),
                ("indosat", "Indosat"),
                ("biznet", "Biznet"),
                ("firstmedia", "FirstMedia"),
                ("cbn", "CBN"),
                ("simaya", "Simaya"),
                ("solnet", "Solnet"),
                ("hinet", "HiNet"),
                ("google", "Google"),
                ("cloudflare", "Cloudflare"),
                ("facebook", "Meta/Facebook"),
                ("akamai", "Akamai CDN"),
                ("fastly", "Fastly CDN"),
                ("cloudfront", "AWS CloudFront"),
                ("1e100", "Google"),
                ("edgecast", "EdgeCast CDN"),
                ("stackpath", "StackPath CDN"),
            ]:
                if pattern in rdns_lower:
                    return isp
            # Return first part of rDNS as hint
            parts = rdns.split('.')
            if len(parts) >= 2:
                return parts[-2].upper()[:20]
        
        # Fallback: whois
        r = subprocess.run(["whois", ip], capture_output=True, text=True, timeout=5)
        output = r.stdout
        for line in output.split('\n'):
            line_lower = line.lower()
            if line_lower.startswith('netname:') or line_lower.startswith('descr:') or line_lower.startswith('org-name:'):
                val = line.split(':', 1)[1].strip()
                if val and val not in ('-', 'N/A', 'ID'):
                    # Map known netnames to friendly names
                    isp_map = {
                        'simaya-id': 'Simaya',
                        'solnet-netblock': 'Solnet',
                        'telkomnet': 'Telkom',
                        'telkomsel': 'Telkomsel',
                        'myrepublic-id': 'MyRepublic',
                        'biznet': 'Biznet',
                        'indosat-id': 'Indosat',
                    }
                    val_lower = val.lower()
                    for k, v in isp_map.items():
                        if k in val_lower:
                            return v
                    # Return first descriptive line
                    return val[:25]
    except:
        pass
    return None

# ── TracePath ────────────────────────────────
def tracepath_host(host):
    """Returns first 8 hops of tracepath with ISP detection"""
    try:
        r = subprocess.run(["tracepath", "-n", "-m", "8", host],
                          capture_output=True, text=True, timeout=15)
        hops = []
        for line in r.stdout.split('\n'):
            m = re.match(r'\s*(\d+):\s+([\d.]+)\s+([\d.]+)ms', line)
            if m:
                hop = int(m.group(1))
                ip = m.group(2)
                rtt = float(m.group(3))
                isp = detect_isp(ip)
                isp_str = f" ({isp})" if isp else ""
                hops.append(f"  hop{hop}: {ip}{isp_str} — {rtt:.1f}ms")
            elif '* * *' in line or 'no reply' in line:
                hops.append(f"  hop: *")
        return hops[:8]
    except:
        return ["  tracepath gagal"]

# ── Main ─────────────────────────────────────
issues = []
warnings = []
trace_targets = []
now = datetime.now().strftime("%H:%M WIB")

token = zabbix_login()
item_map = {}
wan_bw = {}
total_bw = 0
# Define POPS for use throughout
POPS = [
    ("Pusat", "pfSense Gateway", ["WAN1","WAN2","WAN3","WAN4","WAN5","WAN6","WAN7GW"]),
]

if not token:
    issues.append("🔴 Gagal login Zabbix")
else:
    # ── 1. Gateway Status per POP ────────────
    pops = POPS
    
    all_items = zabbix(token, "item.get", {
        "hostids": "10084",
        "search": {"name": "pfSense"},
        "output": ["name", "lastvalue"]
    })
    item_map = {i["name"]: i.get("lastvalue","?") for i in all_items}
    
    for pop_name, name_prefix, wans in pops:
        gw_lines = []
        for wan in wans:
            status = item_map.get(f"{name_prefix} {wan}: status", "?")
            loss = item_map.get(f"{name_prefix} {wan}: loss", "?")
            rtt = item_map.get(f"{name_prefix} {wan}: rtt", "?")
            
            if status == "?":
                continue
            
            # Get ISP label for Pusat WANs
            isp_label = ""
            if pop_name == "Pusat" and wan in WAN_ISP_MAP:
                isp, speed = WAN_ISP_MAP[wan]
                isp_label = f" ({isp} {speed})"
            
            if status != "0":
                gw_lines.append(f"  🔴 {wan}{isp_label}: DOWN")
            else:
                try:
                    loss_f = float(loss)
                    if loss_f > 0:
                        gw_lines.append(f"  🟡 {wan}{isp_label}: {loss}% loss")
                except:
                    pass
        
        if gw_lines:
            issues.append(f"🔗 {pop_name} Gateway:\n" + "\n".join(gw_lines))
    
    # ── 2. Bandwidth Pusat ─────────────────
    bw_items = zabbix(token, "item.get", {
        "hostids": "10681",
        "search": {"name": "Bits received"},
        "output": ["name", "lastvalue"]
    })
    
    wan_bw = {}
    wan_if_map = {"WAN1":"ix0.10","WAN3":"ix0.30","WAN4":"ix0.40",
                  "WAN5":"ix0.50","WAN6":"ix0.60","WAN7GW":"ix0.70"}
    for item in bw_items:
        for wan, iface in wan_if_map.items():
            if iface in item["name"]:
                wan_bw[wan] = float(item["lastvalue"]) / 1e6
    
    total_bw = sum(wan_bw.values())
    peak_wans = []
    for w, mbps in sorted(wan_bw.items(), key=lambda x: -x[1]):
        if mbps > 280 and w != "WAN6":  # Skip WAN6 (Cilisung BH), threshold 280M
            isp, speed = WAN_ISP_MAP.get(w, ("?", "?"))
            peak_wans.append(f"{w}({isp})={mbps:.0f}Mbps")
    if peak_wans:
        warnings.append(f"📊 Pusat bandwidth tinggi ({total_bw:.0f}M total): {', '.join(peak_wans)}")

# ── 3. Ping + Trace targets ─────────────────
TARGETS = [
    ("YouTube", "youtube.com"),
    ("Google", "google.com"),
    ("Facebook", "facebook.com"),
    ("TikTok", "tiktok.com"),
    ("Instagram", "instagram.com"),
    ("WhatsApp", "www.whatsapp.com"),
    ("Twitter/X", "twitter.com"),
    ("Shopee", "shopee.co.id"),
    ("Valve/Steam", "valve.com"),
    ("Cloudflare", "1.1.1.1"),
    ("Google DNS", "8.8.8.8"),
]

# Ping all in parallel
ping_results = {}
with ThreadPoolExecutor(max_workers=8) as ex:
    futures = {ex.submit(ping_host, h): name for name, h in TARGETS}
    for f in as_completed(futures):
        name = futures[f]
        host, loss, rtt_min, rtt_avg, rtt_max, status = f.result()
        ping_results[name] = (host, loss, rtt_min, rtt_avg, rtt_max, status)

# Analyze ping results
for name in [t[0] for t in TARGETS]:
    host, loss, rtt_min, rtt_avg, rtt_max, status = ping_results[name]
    
    if status == "timeout":
        issues.append(f"🔴 {name}: TIMEOUT")
        trace_targets.append((name, host))
    elif status == "blocked":
        pass  # ICMP blocked, skip
    elif loss is not None and loss >= 10:
        issues.append(f"🔴 {name}: {loss}% loss | avg {rtt_avg:.0f}ms | max {rtt_max:.0f}ms")
        trace_targets.append((name, host))
    elif loss is not None and loss >= 5:
        warnings.append(f"🟡 {name}: {loss}% loss | avg {rtt_avg:.0f}ms")
    elif rtt_avg is not None and rtt_avg > 250:
        warnings.append(f"🟡 {name}: {rtt_avg:.0f}ms (latency tinggi)")
        trace_targets.append((name, host))

# ── 4. TracePath ke target bermasalah ────────
traces = []
if trace_targets:
    traces.append("")
    traces.append("🔍 TracePath:")
    for name, host in trace_targets[:3]:  # max 3 trace
        traces.append(f"  {name} ({host}):")
        hops = tracepath_host(host)
        for h in hops:
            traces.append(h)

# ── Filter: only keep persistent issues (seen 2+ consecutive runs) ──
all_items = issues + warnings
this_run_keys = set()
filtered_issues = []
filtered_warnings = []

for item in issues:
    key = "issue:" + item[:60].split('\n')[0]
    this_run_keys.add(key)
    if should_alert(key):
        filtered_issues.append(item)

for item in warnings:
    key = "warn:" + item[:60].split('\n')[0]
    this_run_keys.add(key)
    if should_alert(key):
        filtered_warnings.append(item)

# Clean up stale keys (not seen this run)
state = load_state()
cleaned = {k: v for k, v in state.items() if k in this_run_keys}
save_state(cleaned)

# ── Output ───────────────────────────────────
if not filtered_issues and not filtered_warnings:
    print("NO_ISSUE")
else:
    print(f"📡 Network Alert — {now}")
    print()
    
    # Wan status summary
    wan_status_lines = []
    for pop_name, name_prefix, wans in POPS:
        statuses = []
        for wan in wans:
            s = item_map.get(f"{name_prefix} {wan}: status", "?")
            icon = "🟢" if s == "0" else ("🔴" if s != "?" else "⚫")
            statuses.append(f"{icon}{wan}")
        wan_status_lines.append(f"  {pop_name}: {' '.join(statuses)}")
    print("🔗 Gateway:")
    print("\n".join(wan_status_lines))
    
    # Bandwidth
    if wan_bw:
        bw_parts = []
        for w, mbps in sorted(wan_bw.items(), key=lambda x: -x[1]):
            if mbps > 0:
                isp, _ = WAN_ISP_MAP.get(w, ("?", "?"))
                bw_parts.append(f"{w}({isp})={mbps:.0f}")
        print(f"📊 BW Pusat: {' | '.join(bw_parts)} | Total {total_bw:.0f}M")
    
    # Issues
    if filtered_issues:
        print()
        print("🚨 Issues:")
        for issue in filtered_issues:
            print(issue)
    
    # Warnings
    if filtered_warnings:
        print()
        print("⚠️ Warnings:")
        for w in filtered_warnings:
            print(w)
    
    # Traces
    if traces:
        print("\n".join(traces))
    
    print()
    print("---")
    print("Detail: `python3 workspace/network_report.py`")
