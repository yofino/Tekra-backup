# NetPilot — Build Execution Plan

> **Product**: NetPilot (by **Tekra** — PT Teknologi Rakyat)
> **Pilot Series**: NetPilot / FitPilot / WorkPilot
> **Per Fase — Siap tempel ke Claude Code**
> 1 Juni 2026 | Ujang

---

## Fase 0: Project Setup
**Prompt Claude Code:**

```
Setup project baru dengan stack:
- Laravel 11
- Livewire 3 + Alpine.js
- Tailwind CSS 3.4 + DaisyUI
- MySQL 8 (multi-schema — 1 schema per tenant)
- Redis (cache + queue)
- Laravel Horizon (queue)
- Laravel Sanctum (auth)
- Laravel Reverb (websocket)

Structure:
- Multi-tenant via middleware (detect tenant dari subdomain/header)
- Admin layout: sidebar (collapsible), navbar (user menu, notifications)
- Dark mode support
- Indonesian language (set default locale ke 'id')
- Git init + .gitignore (node_modules, .env, storage, vendor)
- .env.example dengan semua config key
- README.md dengan setup instructions

Buat migration untuk `tenants` table:
- id, name, subdomain, domain, logo, primary_color, db_name, plan, status (trial/active/suspended), trial_ends_at, subscription_ends_at, created_at, updated_at

Jangan build fitur — setup doang. Kalau udah beres commit "feat: project setup + tenant migration".
```

---

## Fase 1: Auth + Tenant + RBAC
**Prompt Claude Code:**

```
Lanjutkan dari setup. Build:

1. **Tenant Registration**
   - Page: /register — form daftar ISP (nama, subdomain, email, password)
   - Auto-create database schema per tenant (pakai DB::statement)
   - Migrate schema baru otomatis
   - Default trial 14 hari

2. **Auth System**
   - Login page dengan tenant detection (subdomain atau dropdown)
   - Laravel Sanctum untuk SPA auth
   - Middleware: tenant detection, role checking
   - Rate limiting: 5 attempts per minute

3. **RBAC**
   - Migration: roles, permissions, role_user
   - Seeder: Super Admin, Admin ISP, Teknisi, View Only
   - Gate/Policy untuk setiap modul
   - Halaman user management (CRUD user per tenant)
   - Super Admin bisa switch tenant

4. **Layout**
   - Sidebar navigasi (responsive, collapse)
   - Profile dropdown (edit profil, ganti password, switch tenant, logout)
   - Breadcrumb auto-generate
   - Toast notification

Commit: "feat: auth + multi-tenant + RBAC".
```

---

## Fase 2: Customer + Coverage + Package
**Prompt Claude Code:**

```
Lanjutan. Build modul master data:

1. **Coverage Area**
   - Migration: coverages (code PK, name, address, coordinates, odc_count, odp_count)
   - CRUD dengan modal (Livewire component)
   - DataTables server-side
   - Select2 untuk lookup

2. **Package**
   - Migration: packages (name, speed_down, speed_up, price, mikrotik_profile, category, active)
   - CRUD + status toggle
   - Kategori paket (subscription, voucher, addon)

3. **Customer**
   - Migration: customers (no_services PK, name, email, phone, wa, address, coordinates, coverage_code FK, package_id FK, router_id FK nullable, mode_user enum(PPPOE/HOTSPOT/STATIC), status enum(Aktif/Isolir/Menunggu/NonAktif), auto_isolir bool, register_date, vendor)
   - Full CRUD dengan form wizard (step 1: data diri, step 2: coverage+paket)
   - Auto-generate no_services (format: YYYYMMDDHHMMSS)
   - Filter: status, coverage, router, package, keyword search
   - DataTables server-side dengan eager loading
   - Export Excel (Laravel Excel)
   - Import Excel dengan validasi
   - Detail page: tabs (Profil, PPPoE, Tagihan, Tiket, ONT)

4. **API Endpoints (opsional, bisa nanti)**
   - GET /api/v1/customers (paginated, filterable)
   - POST /api/v1/customers
   - GET /api/v1/coverages
   - GET /api/v1/packages

Commit: "feat: customer + coverage + package CRUD".
```

---

## Fase 3: MikroTik Integration
**Prompt Claude Code:**

```
Lanjutan. Build MikroTik integration:

1. **Router Management**
   - Migration: routers (name, ip, api_port default 8728, ssh_port default 22, username, password encrypted, type, location, active)
   - CRUD router
   - Test connection button (ping + API check)
   - Gunakan library: https://github.com/EvilFreelancer/routeros-api-php

2. **PPPoE User Management**
   - Halaman list PPPoE users dari MikroTik (read via API)
   - Create PPPoE user (dari customer detail → "Buat PPPoE")
   - Enable/Disable PPPoE user
   - Delete PPPoE user
   - Format: {no_services}-{nama} (auto)

3. **PPPoE Active Sessions**
   - Tabel real-time PPPoE active sessions
   - Info: username, caller-id (MAC), address, uptime, bytes in/out
   - Auto-refresh tiap 30 detik (Livewire polling)

4. **Isolir / Open Isolir**
   - Tombol isolir di customer list (mass action + individual)
   - Disable PPPoE user di MikroTik
   - Update customer status → Isolir
   - Open isolir: enable kembali + update status

5. **API untuk isolir**
   - POST /api/v1/mikrotik/isolir/{customer} (dipanggil cron saat overdue)
   - POST /api/v1/mikrotik/open/{customer} (dipanggil setelah payment confirmed)

6. **Dashboard Monitoring**
   - Widget: total PPPoE active, router uptime, CPU usage
   - Grafik traffic per router (fetch via MikroTik API monitoring)

Commit: "feat: mikrotik pppoe management + auto isolir".
```

---

## Fase 4: Billing + Invoice + Payment
**Prompt Claude Code:**

```
Lanjutan. Build billing module:

1. **Database**
   - Migration: invoices (id, inv_number, customer_no FK, amount, tax, total, due_date, month, year, status enum(BelumBayar/SudahBayar/Terkirim), payment_date, payment_method, created_at)
   - Migration: invoice_items (invoice_id FK, description, quantity, price)
   - Migration: payments (invoice_id FK, amount, method, transaction_id, proof_image, confirmed_at, confirmed_by)

2. **Auto Invoice Generation**
   - Artisan command: billing:generate {month} {year} {--tenant=}
   - Logic: ambil semua customer Aktif → generate invoice per bulan
   - Setiap invoice = 1 tagihan paket + optional addon
   - Schedule: cron tiap tanggal 1, jam 00:01
   - Grace period configurable (default 10 hari)
   - Denda keterlambatan (configurable, default Rp 5.000)

3. **Invoice Management**
   - Halaman list invoice (DataTables, filter: status, bulan, coverage)
   - Detail invoice (customer info, items, amount, status timeline)
   - Print invoice PDF (barryvdh/laravel-dompdf)
   - QR code payment di invoice (simple-qrcode)

4. **Payment Gateway (Midtrans)**
   - Integrasi Midtrans Snap (popup payment)
   - Webhook handler: POST /api/v1/webhooks/midtrans
   - Auto-confirm invoice saat payment sukses
   - Support: Bank Transfer (BCA, BNI, BRI, Mandiri), QRIS, GoPay, ShopeePay

5. **Manual Payment Confirmation**
   - Upload bukti transfer
   - Admin confirm/reject
   - Status invoice update

6. **Reminder System**
   - WhatsApp reminder: H-7, H-3, H-1, Jatuh Tempo, H+1 (telat)
   - Email reminder (optional)
   - Queue job untuk batch send

7. **Isolir Automation**
   - Command: billing:isolir — disable PPPoE untuk invoice overdue > grace period
   - Command: billing:open-isolir — enable PPPoE setelah payment confirmed
   - Schedule: cron tiap jam

Commit: "feat: billing + invoice + midtrans payment + auto isolir".
```

---

## Fase 5: Finance
**Prompt Claude Code:**

```
Lanjutan. Build finance module:

1. **Income**
   - Migration: incomes
   - CRUD pemasukan (amount, date, category, coverage, bank, remark, attachment)
   - Filter: date range, category, coverage
   - Quick add dari payment confirm

2. **Expense**
   - Migration: expenses
   - CRUD pengeluaran (amount, date, category, receipt, remark)
   - Upload bukti pengeluaran

3. **Categories**
   - Migration: finance_categories (name, type enum(income/expense))
   - Pre-seeded: Pemasangan, Paket, Voucher, Addon, Operasional, Gaji, Listrik, Internet, Maintenance

4. **Dashboard**
   - Total income/expense/profit bulan ini
   - Grafik revenue 6 bulan terakhir
   - Pie chart pengeluaran by category
   - Cash balance

5. **Report**
   - Monthly P&L report
   - Export PDF/Excel
   - Filter: date range, coverage

Commit: "feat: finance income + expense + reports".
```

---

## Fase 6: Ticketing
**Prompt Claude Code:**

```
Lanjutan. Build ticketing/helpdesk:

1. **Database**
   - Migration: tickets (no PK autoincrement, customer_no FK nullable, subject, description, priority enum(rendah/sedang/tinggi/urgent), status enum(Buka/Proses/Pending/Tutup), assigned_to FK users nullable, created_by, resolved_at)
   - Migration: ticket_messages (ticket_id FK, user_id FK, message, attachment, is_customer bool)

2. **Ticket CRUD**
   - List tiket (DataTables, filter: status, priority, teknisi, date)
   - Create tiket (bisa dari customer detail → "Buat Tiket")
   - Detail tiket (timeline chat-style, assign teknisi, change status)
   - SLA timer (waktu sejak open)

3. **Assignment**
   - Assign ke teknisi (dropdown teknisi available)
   - Notifikasi WA ke teknisi saat di-assign
   - Teknisi update status via PWA

4. **Customer View**
   - Customer portal: lihat tiket sendiri, reply

5. **AI Ticket Classifier (Phase 9)**
   - Auto-kategorisasi ticket dari deskripsi
   - Auto-prioritize (urgent detect kata kunci: "mati total", "down")
   - Auto-assign ke teknisi berdasarkan coverage area

Commit: "feat: ticketing helpdesk system".
```

---

## Fase 7: OLT + GenieACS
**Prompt Claude Code:**

```
Lanjutan. Build OLT + GenieACS integration:

1. **OLT Management**
   - Migration: olts (name, ip, type enum(hsgq/hioso/vsol/cdata), telnet_port, username, password encrypted)
   - CRUD OLT
   - Test connection
   - ONT list dari OLT (per PON port)

2. **GenieACS Integration**
   - Config: ACS URL, username, password (di setting tenant)
   - Helper class: GenieacsClient (HTTP client ke GenieACS API)
   
3. **ONT Monitoring Dashboard**
   - List semua ONT terdaftar
   - Status: Online/Offline
   - RX Power (dBm) dengan warning indicator (>-20 merah, -20 s/d -26 hijau, -26 s/d -30 kuning, <-30 merah)
   - Suhu ONT (>60°C warning)
   - Device uptime
   - Firmware version
   - Connected devices count
   - Auto-refresh (Livewire polling)
   - Grafik RX Power history (fetch via GenieACS tasks)

4. **Remote Configuration**
   - Halaman ONT detail
   - Button actions:
     - Reboot ONT
     - Ganti WiFi SSID & Password (form, push via GenieACS)
     - Factory reset (dengan konfirmasi)
     - Firmware upgrade
     - VLAN configuration
   - Log semua action

5. **Customer Self-Service WiFi**
   - Customer portal: halaman "Ganti Password WiFi"
   - Form: password baru (min 8 char)
   - Push config ke ONT via GenieACS
   - Success/fail feedback
   - Rate limit: max 3x per hari

6. **Bulk Operations**
   - Pilih banyak ONT → action: reboot, ganti VLAN, upgrade firmware
   - Queue job biar gak timeout
   - Progress tracking

Commit: "feat: olt + genieacs monitoring & remote config".
```

---

## Fase 8: HR + Payroll + Hikvision

### 8A — Attendance with ANTI-FAKE GPS + Photo

```
Build attendance module:

1. **Database**
   - Migration: employees (name, nip, position, phone, shift, basic_salary, allowances_json, join_date, active)
   - Migration: attendances (employee_id FK, date, time_in, time_out, checkin_photo, checkout_photo, checkin_lat, checkin_lng, checkout_lat, checkout_lng, checkin_device, checkout_device, checkin_ip, checkin_wifi_networks, status enum(hadir/terlambat/izin/sakit/alfa))
   - Migration: leaves (employee_id FK, type, start_date, end_date, reason, status, approved_by)

2. **ANTI-FAKE GPS System**
   
   a. Client-side (PWA):
      - Wajib real-time photo capture (bukan upload dari gallery)
      - Gunakan navigator.geolocation.getCurrentPosition({enableHighAccuracy: true, timeout: 10000})
      - Kirim: photo (base64), latitude, longitude, accuracy, timestamp
      - Scan WiFi networks: navigator.connection (jika tersedia)
      - Device fingerprint: userAgent, screen resolution, timezone
   
   b. Server-side Validation (setiap check-in):
      - ✅ Photo metadata: EXIF GPS harus match dengan claimed location
      - ✅ Photo timestamp: max 2 menit dari waktu upload
      - ✅ Location consistency: bandingkan dengan check-in sebelumnya (distance < 100km abnormal)
      - ✅ Accuracy check: GPS accuracy harus < 50 meter
      - ✅ IP Geolocation: bandingkan claimed GPS dengan IP geolocation (max distance 5km)
      - ✅ Work area validation: cek apakah koordinat dalam radius coverage area karyawan
      - ✅ Duplicate check: gak boleh check-in 2x dalam 5 menit
      - ✅ Mock location detection:
         - Android: cek isMockLocation flag via server-side
         - Speed check: jarak antar check-in berurutan dibagi waktu → mustahil > 500km/h
         - Altitude anomaly: lonjakan ketinggian tidak wajar
      - ✅ Photo analysis: 
         - Metadata original (tidak diedit)
         - Jika budget memungkinkan: face recognition match dengan foto profil karyawan

   c. Audit Flag:
      - Setiap check-in dapat score kepercayaan 0-100
      - Score < 70 → flag "⚠️ Perlu Review"
      - Score < 40 → auto-reject, notif admin
      - Log semua flag untuk audit

3. **Hikvision Integration**
   - Config: IP, username, password, port
   - Tarik attendance log via ISAPI: GET /ISAPI/AccessControl/AttendanceLog/Search
   - Mapping Hikvision employee ID ↔ sistem employee ID
   - Sync: cron tiap 30 menit tarik data baru

4. **Attendance Dashboard**
   - Hari ini: hadir, terlambat, izin, alfa (real-time)
   - Tabel check-in hari ini (foto, lokasi, jam, trust score)
   - Peta lokasi check-in (Leaflet.js)
   - Kalender absensi per karyawan

5. **Overtime, Shift, Leave**
   - Shift: pagi (07-15), siang (15-23), malam (23-07)
   - Auto-detect overtime (> shift end + 1 jam)
   - Leave request → approval workflow

Commit: "feat: attendance with anti-fake gps + photo + hikvision".
```

### 8B — Payroll

```
Lanjutan. Build payroll:

1. **Database**
   - Migration: payrolls (employee_id, period_year, period_month, basic_salary, total_allowances, total_overtime, total_deductions, bpjs_tk, bpjs_kes, pph21, net_salary, status, paid_at)
   - Migration: payroll_items (payroll_id FK, type enum(allowance/deduction/overtime/tax), description, amount)

2. **Salary Structure**
   - Per employee: basic salary + multiple allowances (transport, makan, jabatan, keluarga)
   - Per employee: deductions (pinjaman, kasbon, absen)
   - Config: UMR/UMK per area

3. **Auto Calculation**
   - Command: payroll:generate {month} {year} {--tenant=}
   - Logic per karyawan:
     - Basic salary (proporsional jika join mid-month)
     - Allowances (full, kecuali transport bisa proporsional)
     - Overtime: (jam lembur × (1/173 × gaji) × multiplier)
     - Deductions: total pinjaman + denda keterlambatan
     - BPJS TK: 2% (perusahaan) + 1% (karyawan)
     - BPJS Kesehatan: 4% (perusahaan) + 1% (karyawan)
     - PPh 21: hitung sesuai bracket (TER A/B/C)
     - Net salary = basic + allowances + overtime - deductions - bpjs - pph21

4. **Payslip**
   - PDF payslip (dompdf)
   - Kirim via WhatsApp (queue job)
   - Employee portal: lihat slip gaji sendiri

5. **Bank Transfer**
   - Export CSV format BCA/Mandiri/BRI
   - Bulk transfer template

6. **THR**
   - Command: payroll:thr {year}
   - Kalkulasi: (masa kerja / 12) × gaji pokok + tunjangan tetap
   - Untuk < 12 bulan: proporsional

Commit: "feat: payroll with bpjs + pph21 + payslip".
```

---

## Fase 9: AI Layer
**Prompt Claude Code:**

```
Build AI integration:

1. **AI Setup**
   - Config tenant: AI provider (OpenAI/DeepSeek), API key, model, temperature
   - AI Chat UI di sidebar (Livewire component, chat bubble)
   - Streaming response (Server-Sent Events)

2. **AI Customer Service**
   - Context: data pelanggan, tagihan, tiket, FAQ
   - Fitur:
     - "Cek tagihan saya" → query invoice, balas nominal
     - "Internet saya lambat" → cek ONT RX Power + PPPoE uptime
     - "Cara bayar" → balas payment methods
     - "Lapor gangguan" → auto-create ticket
   - Embed di customer portal

3. **AI NOC Monitor**
   - Prompt: "Analisis data network: router CPU, traffic, ONT status, WAN status"
   - Alert: deteksi anomali (spike traffic, router down, banyak ONT offline)
   - Rekomendasi: "Router Dago CPU >80%: upgrade RAM atau limit PPPoE profile"
   - Action: "Isolir pelanggan overdue? Eksekusi? (Y/N)"

4. **AI Bill Collector**
   - Follow-up otomatis via WhatsApp
   - Bahasa natural, ramah tapi tegas
   - Eskalasi: reminder → peringatan → ancaman isolir
   - Payment negotiation (cicilan, perpanjangan)

5. **AI Analytics**
   - Churn prediction: pelanggan dengan RX Power jelek + sering komplain = high risk
   - Upsell recommendation: pelanggan >5 device + paket 10M → rekomendasi upgrade

Commit: "feat: ai customer service + noc monitor + bill collector".
```

---

## Fase 10: WhatsApp + Notifications
**Prompt Claude Code:**

```
Build notification system:

1. **WhatsApp Cloud API**
   - Config: phone number ID, access token, verify token
   - Template management (reminder, payment confirm, ticket, payroll)
   - Send message service class (queue job)
   - Webhook receiver untuk incoming messages

2. **Notification Templates**
   - Payment Reminder: H-7, H-3, H-1, Due Date, H+1 Overdue
   - Payment Confirmation: success + invoice detail
   - Ticket: assigned, progress update, resolved
   - Payroll: payslip ready
   - Broadcast: pengumuman ke semua/some pelanggan

3. **WhatsApp Chat**
   - Incoming message → AI CS auto-reply
   - Handover ke manusia jika AI mentok
   - Chat history per pelanggan

4. **Email (optional)**
   - Invoice email
   - Report email

Commit: "feat: whatsapp notification + chat integration".
```

---

## Fase 11: Customer Portal
**Prompt Claude Code:**

```
Build customer self-service portal:

1. **Login**
   - No services + password
   - Atau: OTP via WhatsApp

2. **Dashboard**
   - Status internet: Online/Offline (cek PPPoE active)
   - **ONT Status Card** (via GenieACS integration):
     - 📡 Status ONT: Online / Offline
     - 📶 RX Power: -22 dBm (🟢 Bagus) / -28 dBm (🟡 Sedang) / -32 dBm (🔴 Buruk)
     - 🌡️ Suhu ONT: 45°C (normal) / 62°C (⚠️ Panas)
     - 📱 Device Aktif: 7 perangkat terhubung
     - ⏱️ Uptime: 15 hari 8 jam
   - Tagihan terbaru + status
   - Quick actions: Bayar, Lapor Gangguan, **Reboot ONT**, **Ganti Password WiFi**

3. **Halaman**
   - Tagihan: list invoice + bayar
   - Tiket: buka + lihat status
   - Profil: edit data diri, ganti password
   - **ONT Manager** (halaman dedicated):
     - Tab 1: Status ONT live (RX Power, suhu, uptime, firmware)
     - Tab 2: Daftar device terhubung (MAC address, hostname, IP)
     - Tab 3: Actions (Reboot ONT, Ganti SSID & Password WiFi)
     - Rate limit: reboot 2x/hari, ganti password 3x/hari
     - Log riwayat action
   - Riwayat: payment history

4. **UI**
   - Mobile-first
   - Simple, bersih
   - Sesuai tema tenant (logo, warna)

Commit: "feat: customer self-service portal".
```

---

## Fase 12: Polish + PWA + White-label + Launch
**Prompt Claude Code:**

```
Final polish:

1. **PWA**
   - Service worker (offline cache)
   - Install prompt
   - Push notification
   - App icon + splash screen

2. **White-label**
   - Custom domain (CNAME + SSL auto)
   - Custom logo + favicon
   - Custom primary color (tailwind config)
   - Custom footer text

3. **Onboarding**
   - Wizard untuk tenant baru (5 step)
   - Import data (CSV template)
   - Quick setup: tambah router pertama, buat coverage, buat paket

4. **Performance**
   - Cache: Redis untuk frequent queries
   - Queue: semua heavy operations (invoice gen, isolir, WhatsApp blast)
   - DB indexing review
   - Assets CDN (Laravel Vite)

5. **Backup**
   - Daily DB backup per tenant
   - 30-day retention

6. **Testing**
   - Pest PHP untuk unit + feature test
   - Test coverage >70%
   - Load test (100 concurrent users)

7. **Documentation**
   - Admin guide (PDF)
   - API documentation (Scramble/scribe)
   - Video tutorial setup

Commit: "feat: pwa + white-label + polish + production ready".
```

---

## Fase 13: Mobile App — Android + iOS (Flutter)
**Prompt Claude Code:**

```
Build native mobile app dengan Flutter. Satu codebase untuk Android + iOS.

Stack:
- Flutter 3.x + Dart
- State: Riverpod
- HTTP: Dio
- Local DB: Drift (SQLite) untuk offline mode
- Maps: flutter_map + OpenStreetMap
- Camera: camera + image (real-time capture, bukan gallery)
- GPS: geolocator + geocoding
- Push: Firebase Cloud Messaging
- QR/Barcode: mobile_scanner
- PDF: pdf + printing (invoice PDF viewer)

Fitur:

1. AUTH
   - Login via REST API (email/no_services + password)
   - Biometric: fingerprint/face unlock
   - Persist session

2. ATTENDANCE — ANTI-FAKE GPS + PHOTO
   - Check-in flow: buka kamera depan → selfie real-time → GPS auto-tag
   - Check-out flow: sama
   - Kamera wajib real-time (CameraPreview), tombol capture
   - EXIF metadata: GPS + timestamp auto-attach
   - Upload foto + koordinat ke server
   - Server validasi 7-layer (PRD)
   - Trust score feedback: 🟢 Hijau (aman), 🟡 Kuning (perlu review), 🔴 Merah (ditolak)
   - Offline queue: simpan di SQLite → auto-sync saat konek

3. TECHNICIAN TICKET
   - List tiket assigned ke teknisi
   - Update: proses → selesai
   - Upload foto bukti perbaikan
   - Navigasi: buka Google Maps/Waze ke lokasi pelanggan
   - Offline: data tiket dicache lokal

4. CUSTOMER SELF-SERVICE
   - Dashboard: status internet + ONT card (RX Power, suhu, devices, uptime)
   - Cek tagihan + status + bayar via Midtrans (WebView)
   - ONT Manager:
     - Lihat status ONT live
     - Lihat device terhubung (MAC, hostname, IP)
     - Reboot ONT (konfirmasi + countdown)
     - Ganti SSID + Password WiFi (push GenieACS)
   - Buka tiket gangguan
   - Riwayat transaksi
   - Rate limit: reboot 2x/hari, ganti password 3x/hari

5. PUSH NOTIFICATION
   - Tagihan baru + reminder
   - Tiket assigned + update
   - Pengumuman broadcast
   - Firebase Cloud Messaging

6. OFFLINE MODE
   - SQLite local cache semua data penting
   - Action queue: simpan dulu → sync saat online
   - Background sync dengan WorkManager (Android) / BGTaskScheduler (iOS)

7. UI/UX
   - Material Design 3 (Android) + Cupertino adaptive (iOS)
   - Dark mode support
   - Sesuai tema tenant (logo, warna primary)
   - Smooth animation
   - Loading skeleton

Commit: "feat: flutter mobile app android ios with anti-fake attendance".
```

---

## Diagram Referensi

- System Architecture: `/tmp/arch_v2.png`
- Business Flow: `/tmp/flow.png`
- Portal Audit (old system): `/root/.openclaw/workspace/portal-tekra-audit.md`
- Full PRD: `/root/.openclaw/workspace/SaaS-ISP-PRD.md`
