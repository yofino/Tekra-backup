# HEARTBEAT.md

## Cek Model Aktif
Setiap heartbeat, panggil `session_status` dan cek model yang sedang aktif.
- Kalau model **bukan** `deepseek/deepseek-v4-pro` (misal sudah fallback ke model lain), kirim notif WhatsApp ke Yofi (+6282115448084) dengan pesan singkat: model DeepSeek V4 Pro sudah limit, sekarang pakai [nama model aktif].
- Kalau masih DeepSeek V4 Pro, tidak perlu notif — lanjut HEARTBEAT_OK.
- Jangan spam: kalau sudah pernah notif fallback di session yang sama, skip (cukup sekali per transisi).

## PR / Todo List
- [ ] Inventarisir perangkat per POP (MikroTik, OLT, switch, modem, UPS, dll)
- [ ] OLT Monitoring per POP (EPON Pusat, GPON Pusat, Cilisung, Dago)
- [ ] pfSense Katapang — jika ada
- [ ] Alert Zabbix → WhatsApp
- [ ] Google Postmaster Tools untuk mail.tekra.id

## 🤖 AI Trading Bot Monitor
- Pantau AI bot di Windows VPS: SSH ke 103.187.147.126 (Administrator / As3pGanteng123!)
- Cek live accuracy: `type C:\TradingBot\live_accuracy.json` — pastiin >45%
- Cek data: `dir C:\TradingBot\data` — harusnya nambah ~1,400 baris/hari
- Cek RAM: minimal 0.5GB free, kalau <0.5GB → notif Yofi
- Bot harusnya logging setiap menit: `type C:\TradingBot\bot_ai.log | tail -3`
- Kalau bot mati → `schtasks /Run /TN TradingBot`
- Sabtu ada auto-retrain, cek hasil di `C:\TradingBot\models\training_history.json`
- Kalau akurasi model baru >59.7% → tanya Yofi apakah deploy
