#!/bin/bash
# Script monitor tiket gangguan - deteksi aja, kirim via OpenClaw cron
# System cron: * * * * * /root/.openclaw/workspace/scripts/check_tickets.sh

STATE_FILE="/root/.openclaw/workspace/ticket_state.json"
WA_GROUP="6281320385966-1635417302@g.us"

# Login semua portal
for entry in "portal.tekra.id:/tmp/tekra_cookies.txt" "north.my.id:/tmp/tekra_dago_cookies.txt" "southnet.my.id:/tmp/tekra_katapang_cookies.txt"; do
  domain="${entry%%:*}"
  cookie="${entry##*:}"
  curl -s -X POST "https://$domain/auth" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "email=asep%40tekra.id&password=12345" \
    -c "$cookie" -b "$cookie" -L -o /dev/null
done

# Check tiket dan kirim notif
python3 << 'PYEOF'
import json, re, subprocess

STATE_FILE = "/root/.openclaw/workspace/ticket_state.json"
WA_GROUP = "6281320385966-1635417302@g.us"

portals = [
    ("pusat",    "portal.tekra.id",  "/tmp/tekra_cookies.txt",          "PUSAT"),
    ("dago",     "north.my.id",      "/tmp/tekra_dago_cookies.txt",     "DAGO"),
    ("katapang", "southnet.my.id",   "/tmp/tekra_katapang_cookies.txt", "KATAPANG"),
]

try:
    with open(STATE_FILE) as f:
        state = json.load(f)
except:
    state = {}

messages = []

def get_ticket_detail(domain, cookie, ticket_id):
    """Ambil timeline lengkap dari halaman detail tiket."""
    result = subprocess.run([
        "curl", "-s", "--max-time", "15",
        f"https://{domain}/help/detail/{ticket_id}",
        "-b", cookie,
        "-H", f"Referer: https://{domain}/help/done"
    ], capture_output=True, text=True)
    html = result.stdout

    timeline = []

    # Ambil semua tracking-item: tanggal + jam + konten
    tracking_blocks = re.findall(
        r'class="tracking-date">(.*?)<span>(.*?)</span>.*?class="tracking-content">(.*?)</div>',
        html, re.DOTALL
    )
    for tgl_raw, jam_raw, content_raw in tracking_blocks:
        tgl  = re.sub(r'\s+', ' ', tgl_raw).strip()
        jam  = jam_raw.strip()
        content = re.sub(r'<[^>]+>', ' ', content_raw)
        content = re.sub(r'\s+', ' ', content).strip()
        # Hilangkan bagian "No images available"
        content = content.replace("No images available.", "").strip()
        if content:
            timeline.append(f"📍 {tgl} {jam}\n   {content}")

    return timeline

for key, domain, cookie, label in portals:
    if key not in state:
        state[key] = {"latest_id": 0, "active_tickets": {}}

    s = state[key]

    result = subprocess.run([
        "curl", "-s", "-X", "POST", f"https://{domain}/help/serverhelp",
        "-b", cookie,
        "-H", "Content-Type: application/x-www-form-urlencoded",
        "-d", "draw=1&start=0&length=50&month=&year=2026&coverage=&status="
    ], capture_output=True, text=True)

    try:
        data = json.loads(result.stdout)
        rows = data.get("data", [])
    except:
        continue

    for row in rows:
        action = row.get("action", "")
        ids = re.findall(r'/help/detail/(\d+)', action)
        if not ids:
            continue

        ticket_id   = str(ids[0])
        no_ticket   = row.get("no_ticket", "")
        name        = row.get("name", "")
        report      = re.sub(r'<[^>]+>', ' ', row.get("report", "")).strip()
        status      = row.get("status", "")
        desc        = re.sub(r'<[^>]+>', ' ', row.get("description", "")).strip()
        ket = f"\nKeterangan: {desc}" if desc else ""

        if int(ticket_id) > s.get("latest_id", 0):
            # Tiket baru
            s["latest_id"] = int(ticket_id)
            if status in ("Pending", "Proses"):
                s["active_tickets"][ticket_id] = status
                timeline = get_ticket_detail(domain, cookie, ticket_id)
                timeline_str = "\n\n📋 *Timeline:*\n" + "\n".join(timeline) if timeline else ""
                messages.append(f"🚨 *TIKET BARU - {label}*\nNo: {no_ticket}\nPelanggan: {name}\nLaporan: {report}{ket}\nStatus: {status}{timeline_str}")

        elif ticket_id in s.get("active_tickets", {}):
            old_status = s["active_tickets"][ticket_id]
            if status != old_status:
                if status == "Proses":
                    s["active_tickets"][ticket_id] = status
                    timeline = get_ticket_detail(domain, cookie, ticket_id)
                    timeline_str = "\n\n📋 *Timeline:*\n" + "\n".join(timeline) if timeline else ""
                    messages.append(f"🔧 *TIKET DIPROSES - {label}*\nNo: {no_ticket} | Pelanggan: {name}\nLaporan: {report}{ket}{timeline_str}")
                elif status in ("Close", "Done"):
                    timeline = get_ticket_detail(domain, cookie, ticket_id)
                    timeline_str = "\n\n📋 *Timeline:*\n" + "\n".join(timeline) if timeline else ""
                    del s["active_tickets"][ticket_id]
                    messages.append(f"✅ *TIKET SELESAI - {label}*\nNo: {no_ticket} | Pelanggan: {name}\nLaporan: {report}{ket}{timeline_str}")

# Simpan state
with open(STATE_FILE, "w") as f:
    json.dump(state, f, indent=2)

# Kirim notif
for msg in messages:
    # Simpan ke file antrian, nanti dikirim oleh OpenClaw cron
    import os, tempfile
    queue_dir = "/tmp/ticket_notif_queue"
    os.makedirs(queue_dir, exist_ok=True)
    queue_file = os.path.join(queue_dir, f"{int(subprocess.run(['date', '+%s'], capture_output=True, text=True).stdout.strip())}_{key}.txt")
    with open(queue_file, "w") as f:
        f.write(msg)
    print(f"Queued: {msg[:60]}...")

if not messages:
    print("No ticket changes.")

PYEOF
