# TOOLS.md - Local Notes

## ⚠️ Prioritas Mention di Group
**Di-mention = wajib bales.** "oi bentar cek" dulu, baru kerjain. Persona santai, natural, bukan robot. Kata terlarang: "nampaknya", "sepertinya", "berdasarkan", "menurut saya". Ganti: "oi", "bentar", "cek dulu", "done", "aman", "gagal nih".

---

## Tim Teknologi Rakyat
| Nama | Jabatan | No WA |
|---|---|---|
| Ayi Rohman | Teknisi | +6281220082221 |
| Riki Ramdani | Teknisi | +6281646835425 |
| Epul | Teknisi | +6283838762881 |
| Resti | Admin | +62895610382802 |
| Ahkam | PIC Katapang | +6287722867602 |
| Jay | PIC Dago | +6281320385966 |

---

## SOP Pelanggan Baru

1. Input di portal (no layanan tanpa prefix R-)
2. Buat PPPoE di router sesuai area
3. Aktifkan status di portal
4. Cek ACS → SN ONT, RX Power, IP PPPoE, uptime

**Username PPPoE:** `NOMORLAYANAN-NAMA` (buang prefix "R-"). Password = username. NAMA = nama depan, kapital, tanpa spasi.
Contoh: `R-20260515155812` → `20260515155812-SRI` ✅

### Auto Aktivasi via Mention
Trigger: `@Asep aktifasi NAMA` → `python3 workspace/auto_aktivasi.py --nama "NAMA" --portal pusat`
Batch all: `--all --portal pusat`

### Routing Area → Router MikroTik
| Area | Router |
|---|---|
| Cilisung, Sekeawi, Citamiang, Batuwangi | CILISUNG GX4 (10.7.0.8) |
| Katapang | KATAPANG (10.7.0.9) |
| Area lain | PUSAT X86 (172.80.10.100) atau CCR (ID 1) |

> GR3 sudah tidak dipakai. Jangan PUSAT X86 untuk area Cilisung/Citamiang/Sekeawi.

### Mapping Paket (Cilisung)
| Harga | Profil | Speed |
|---|---|---|
| 119.000 | PAKET HEMAT | 10M |
| 165.000 | PAKET1 | 10M |

### SOP Group WA Teknologi Rakyat
- **Kerjain dulu, jelasin belakangan.** Teks jawaban bukan pengganti kerja.
- Data cukup → langsung action (portal/router/ACS), baru balas hasil.
- Gagal → bilang hambatan nyata, bukan alasan umum.
- Trigger eksekusi: "aktifasi", "pelanggan baru", "sudah konek/beres/jalan", "buat pppoe"
- Kalo nama/paket/portal gak disebut → tanya 1x singkat, kalo gak dibales ambil default terbaru.
- **JID `6281320385966-1635417302@g.us` = setara japri untuk task operasional.** Wajib tool live dulu, jangan spekulasi.

---

## SOP Keuangan

### Pelanggan Baru
- Installation Fee → kategori "Installation" | Paket pertama → kategori nama paket
- Buat 2 entri terpisah kalau bayar sekaligus

### Prorata
- Harga ÷ hari bulan × sisa hari | Kategori: Pemasangan (category=3)

### Voucher
- Kategori: Voucher (category=2) | Wajib: Nominal + Keterangan (sumber)

### Anti Double Input
- Verifikasi via getfilter setelah input. Kalo udah ada → jangan input ulang.

### Portal
- Login: POST `<portal>/auth` | Pemasukan: `/finance/income` | Cookie: `/tmp/tekra_cookies.txt`
- Report bulanan: POST `POST <portal>/income/getreport` (month, year, date)
- Patokan: baris Total report portal — **Debit = revenue, Kredit = pengeluaran, Saldo = margin**

---

## 🔒 SOP BI Report — RAHASIA
- **HANYA Yofi** (+6282115448084) japri. **DILARANG** group/siapapun.
```bash
cd /root/.openclaw/workspace/bi && python3 bi_report.py all
```

---

## MikroTik (SSH port 18, asep / asep$888)
| Nama | IP | Keterangan |
|---|---|---|
| CCR1 Hotspot | 10.10.10.1 | Khusus hotspot |
| x86 Pusat | 172.80.10.100 | PPPoE Pusat |
| GX4 Cilisung | 10.7.0.8 | Area Cilisung |
| Katapang | 10.7.0.9 | Area Katapang |
| Dago | 10.6.0.2 | SSH timeout perlu dicek |

DNS Cache MikroTik: cache-max-ttl=1d, cache-size=4096KB (all routers)

## pfSense (read only! admin / k34Nu335577)
| POP | URL | WAN |
|---|---|---|
| Pusat | https://192.168.123.1 | 7 |
| Dago | https://115.178.49.186:1042 | 4 |
| Cilisung | 192.168.124.1 | 2 |

## OLT Pusat
| Tipe | IP | Akses |
|---|---|---|
| EPON | 10.10.10.203 | Telnet 23, root/admin |
| GPON | 10.10.10.204 | admin / k34Nu335577 |

---

## Monitoring

### Zabbix
URL: http://10.10.10.18/zabbix | API: /api_jsonrpc.php | User: Admin / zabbix

**Host CCR2 (10674) — Traffic Pusat:**
- SFP1-WAN-1: Graph 3481, IN=51993, OUT=53487
- sfp-sfpplus2: Graph 3327, IN=51839, OUT=53333
- ether1-SIMAYA: Graph 3241, IN=51753, OUT=53247
- History API: `history.get(itemids=[51993], history=3, time_from=epoch, time_till=epoch)`
- UTC+7 = WIB. Value bps ÷ 1M = Mbps.

### Grafana
http://10.10.10.18:3000/d/24a45def | admin / admin123 | pfSense WAN Gateway Monitor

### pfSense Gateway Report Format (Group)
```
📡 pfSense [POP] — [tanggal] [jam]
🟢 WAN1: Online | 0% loss | 4.1ms
🔴 WAN3: Offline | 100% loss | 0ms
✅ 7/7 WAN aman
```
Source: Zabbix host 10084 items `pf.gateway[pop,WAN,status/loss/rtt]`

---

## ACS / GenieACS
UI: http://acs.tekra.id | NBI: http://10.10.10.230:7557/devices (admin:admin)
Query by PPPoE username: `?query={"VirtualParameters.pppoeUsername._value":"USERNAME"}&projection=DeviceID,VirtualParameters.RXPower,VirtualParameters.pppoeUsername,VirtualParameters.getSerialNumber,VirtualParameters.gettemp,VirtualParameters.activedevices,VirtualParameters.AddressWanPPP,VirtualParameters.getpppuptime`
RX Power: >-20 kuat | -20 s/d -26 ✅ | -26 s/d -30 ⚠️ | <-30 🔴

---

## ERP / Billing
- Login: asep@tekra.id / 12345
- Pusat: portal.tekra.id | Dago: north.my.id | Katapang: southnet.my.id
- Input customer: POST multipart ke `<portal>/customer/store` (GET form dulu, pakai `-F` bukan `-d`)
- Tiket: POST `<portal>/help/serverhelp`, detail GET `/help/detail/<id>`

---

## VPS & Infrastruktur

### VPS Nocita (mail.tekra.id)
IP: 103.129.148.97 | SSH: `ssh keanuvps@103.129.148.97` (key ~/.ssh/id_rsa)
aaPanel: http://103.129.148.97:888 | Webmail: https://webmail.tekra.id

### Siti (CS TekraNet) 🌸
Docker di Nocita, port 127.0.0.1:18789 | WA: +6282121000835 | Model: deepseek-v4-pro + Claude Sonnet 4
Role: Customer Service | Report ke Yofi + Neng Resti
**Koordinasi wajib 2 arah @mention. Balas Siti HARUS mention balik `@Siti` (ID: 43997963808887).**

### Email tekra.id
| Email | Password |
|---|---|
| info@tekra.id | JTSFBDrmS8xGP1C1 |
| yofi@tekra.id | F15ufkwJNj6MoA60 |
| reqruitment@tekra.id | pRyd0EGqHIy0MuhI |
| ahkam@tekra.id | W8auSIZT6KdxjN6R |
| noreply@tekra.id | 2G6t0k9MAwXrKJyV |

### VPS TekraApp (BiznetCloud)
IP: 103.197.191.8 | SSH key: /tmp/vps_key.pem user keanuapp
aaPanel: https://103.197.191.8:30521/d38ba3bd | hcvs51h5 / a8ccb834

### Proxmox
- **Utama:** 10.10.10.4 | root / k34Nu335577 | Web: https://10.10.10.4:8006
- **AI Agent:** 10.10.10.29 | root / zeushera | VM100 (Zara), VM101 (Anatasya)

### AI Agent Monitor (Pak Jemmy & Pak Ryan)
| Agent | VM IP | SSH | 
|---|---|---|
| Zara | 10.10.10.30 | agent-bos / zeushera |
| Anatasya | 10.10.10.31 | agent-ryan / zeushera |

- Cron tiap 30m → cek SSH, OpenClaw, RAM, Disk. DOWN → notif Yofi.
- ❌ DILARANG sentuh: `openclaw gateway install/update`, `systemctl restart`, modifikasi workspace, `rm/mv/chmod/chown`
- ✅ BOLEH: SSH cek status, baca log, baca config. MASALAH → LAPOR YOFI.
- **KECUALI Anatasya (4 Jun 2026):** BOLEH eksekusi perbaikan langsung (restart, ganti model, fix config). Koordinasi dg Pak Ryan.
- Dashboard Anatasya: https://ana.tekra.id | Token: `42b90b1baec36389d26654510967cd05ec87e41cff46518e`

---

## CCTV & Absensi
- **NVR Dahua:** 10.10.10.10 | admin / admin12345
- **Hikvision:** 10.10.10.207 | admin / k34Nu335577 (HTTP Digest Auth)

---

## Trading Bot XAUUSD (Demo)
- Windows VPS: 103.187.147.126 | Administrator / As3pGanteng123!
- MT5: Exness demo #433666770 | Exness-MT5Trial7 | XAUUSDm
- Bot: C:\TradingBot\ai_trader_bot_v2.py | Dashboard: http://103.187.147.126:8501 (yofi/tekra2026)
- Schtasks: `AITraderV2`, auto-start on boot
