#!/bin/bash
# WhatsApp Watchdog - cek koneksi WA tiap 5 menit
# Kalau WebSocket WhatsApp mati >5 menit, restart gateway

LOGFILE=/tmp/wa_watchdog.log
LOG_OPENCLAW=/tmp/openclaw/openclaw-$(date +%Y-%m-%d).log

# Cek heartbeat WhatsApp dalam 5 menit terakhir
LAST_HB=$(grep "web gateway heartbeat" "$LOG_OPENCLAW" 2>/dev/null | tail -1)

if [ -z "$LAST_HB" ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') | NO HEARTBEAT FOUND - restarting gateway" >> $LOGFILE
  systemctl --user restart openclaw-gateway.service
  exit 0
fi

# Parse timestamp dari log
HB_TIME=$(echo "$LAST_HB" | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(d.get('time',''))" 2>/dev/null)
if [ -z "$HB_TIME" ]; then
  # Fallback: extract timestamp string
  HB_TIME=$(echo "$LAST_HB" | grep -oP '\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}' | head -1)
fi

if [ -z "$HB_TIME" ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') | CANNOT PARSE HB - restarting gateway" >> $LOGFILE
  systemctl --user restart openclaw-gateway.service
  exit 0
fi

# Cek umur heartbeat dalam detik
NOW=$(date +%s)
HB_TS=$(date -d "$HB_TIME" +%s 2>/dev/null || echo 0)
AGE=$(( NOW - HB_TS ))

if [ "$AGE" -gt 300 ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') | Heartbeat ${AGE}s old (>5m) - restarting gateway" >> $LOGFILE
  systemctl --user restart openclaw-gateway.service
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') | OK (heartbeat ${AGE}s ago)" >> $LOGFILE
fi
