# 📦 Portfolio SaaS Taskora - Catalog

> Last updated: 11 May 2026 by Asep

## 🚀 Published (Ready to Sell)

| # | Produk | URL | Login | Tipe |
|---|---|---|---|---|
| 1 | **Salon Management** | salon.taskora.id | owner@example.com / password | Web SaaS |
| 2 | **Resto POS (SaaS)** | saasresto.taskora.id | superadmin / superadmin | Web SaaS |
| 3 | **Pinjaman Online** | pinjaman.taskora.id | admin@taskora.id / superadmin | Web Fintech |
| 4 | **PPOB** | ppob.taskora.id | admin@taskora.id / superadmin | Web Fintech |
| 5 | **Bank & Koperasi** | bank.taskora.id | admin@taskora.id / superadmin | Web + Mobile |
| 6 | **ERP** | app.taskora.id | admin@taskora.id / superadmin | Web Enterprise |
| 7 | **Kost Manager** | kost.taskora.id | admin@taskora.id / superadmin | Web SaaS |
| 8 | **Toko Online (PHP)** | toko.taskora.id | admin@taskora.id / superadmin | Web E-commerce |
| 9 | **Toko Online (React)** | toko2.taskora.id | admin@taskora.id / superadmin | Web E-commerce |
| 10 | **Resto POS (Single)** | resto.taskora.id | owner / password | Web |
| 11 | **Resto POS (Mobile App)** | - | - | Android/iOS |

## 🔒 Private (Source Code Ready)

| # | Produk | URL | Login | Tipe |
|---|---|---|---|---|
| 12 | **Koperasi Syariah** | koperasi.taskora.id | admin / superadmin | Web |
| 13 | **Film Taskora** | film.taskora.id | admin@taskora.id / superadmin | Web Streaming |
| 14 | **Nusa Emas Store** | nusaemas.store | admin@nusaemas.com / password | Web E-commerce |
| 15 | **GiziNow MBG** | gizinow.com | admin@gizinow.com / superadmin | Web + Apps |
| 16 | **RT RW Net** | - | - | Web |
| 17 | **Bayar** | bayar.taskora.id | - | Web Payment |
| 18 | **Taskora.id (main)** | taskora.id | - | Web Portfolio |
| 19 | **Kopi Roda** | kopiroda.id | - | Web |
| 20 | **Cek Mutasi** | - | admin@taskora.id / superadmin | Web |

## 💰 Potensi Monetisasi

| Produk | Market | Target Price | Revenue Model |
|---|---|---|---|
| Salon Management | 50K+ salon di Indonesia | 100rb/bln | SaaS recurring |
| Resto POS SaaS | 100K+ resto di Indonesia | 150rb/bln | SaaS recurring |
| Kost Manager | 80K+ kost di Indonesia | 50rb/bln | SaaS recurring |
| Pinjaman Online | Koperasi/BPR | 500rb/bln | White-label |
| PPOB | Agen pulsa | 100rb/bln | Transaction fee |
| ERP | UKM/Perusahaan | 1jt/bln | Enterprise license |
| Bank & Koperasi | BPR/KSP | 200rb/bln | White-label |
| Toko Online | UMKM | 50rb/bln | SaaS recurring |
