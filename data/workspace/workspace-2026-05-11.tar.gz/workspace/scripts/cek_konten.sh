#!/bin/bash
# Network Content Quality Check - All POPs
# Usage: bash /root/.openclaw/workspace/scripts/cek_konten.sh

echo "========================================="
echo "  🛰️ CEK KUALITAS KONTEN - TEKRA ISP"
echo "  Server: Pusat (10.10.10.18)"
echo "  $(date '+%d %b %Y %H:%M WIB')"
echo "========================================="

# Define providers by category
declare -A PROVIDERS
PROVIDERS=(
  # META
  ["facebook.com"]="📱 Facebook"
  ["instagram.com"]="📸 Instagram"
  ["whatsapp.com"]="💬 WhatsApp"
  ["messenger.com"]="💭 Messenger"
  # Google
  ["google.com"]="🔍 Google"
  ["youtube.com"]="▶️ YouTube"
  ["googlevideo.com"]="🎬 Google Video CDN"
  # Social/Content
  ["tiktok.com"]="🎵 TikTok"
  ["twitter.com"]="🐦 X/Twitter"
  ["netflix.com"]="🎬 Netflix"
  # E-Commerce
  ["shopee.co.id"]="🛒 Shopee"
  ["tokopedia.com"]="🛍️ Tokopedia"
  ["lazada.co.id"]="📦 Lazada"
  # Gaming
  ["mobilelegends.com"]="🎮 Mobile Legends"
  ["freefire.com"]="🔫 Free Fire"
  ["roblox.com"]="🏗️ Roblox"
  ["pubg.com"]="🎯 PUBG"
)

echo ""
printf "%-10s %-25s %8s %8s %6s\n" "STATUS" "LAYANAN" "RTT" "LOSS" "HASIL"
echo "-------------------------------------------------------------------"

PASS=0
FAIL=0
WARN=0

check_host() {
  local host=$1
  local name=$2
  
  # Try ping first
  result=$(ping -c 3 -W 2 "$host" 2>/dev/null)
  if [ $? -eq 0 ]; then
    rtt=$(echo "$result" | grep "rtt" | grep -oP '\d+\.\d+/\d+\.\d+/\d+\.\d+' | cut -d'/' -f2)
    loss=$(echo "$result" | grep "loss" | grep -oP '\d+%')
    
    if [ "$loss" = "0%" ]; then
      if (( $(echo "$rtt < 10" | bc -l) )); then
        status="🟢"
        PASS=$((PASS+1))
      elif (( $(echo "$rtt < 30" | bc -l) )); then
        status="🟡"
        PASS=$((PASS+1))
      else
        status="🟠"
        WARN=$((WARN+1))
      fi
      printf "%-10s %-25s %6sms %6s ✅\n" "$status" "$name" "$rtt" "$loss"
    else
      status="🔴"
      WARN=$((WARN+1))
      printf "%-10s %-25s %6sms %6s ⚠️\n" "$status" "$name" "$rtt" "$loss"
    fi
  else
    # Try HTTP as fallback
    http_code=$(curl -sk --connect-timeout 3 -o /dev/null -w '%{http_code}' "https://$host" 2>/dev/null)
    if [ "$http_code" != "000" ] && [ -n "$http_code" ]; then
      printf "%-10s %-25s %8s %6s ✅ (HTTP %s)\n" "🟢" "$name" "-" "-" "$http_code"
      PASS=$((PASS+1))
    else
      printf "%-10s %-25s %8s %6s ❌ OFFLINE\n" "🔴" "$name" "-" "100%"
      FAIL=$((FAIL+1))
    fi
  fi
}

echo ""
echo "📱 META SERVICES"
echo "-------------------"
check_host "facebook.com" "Facebook"
check_host "instagram.com" "Instagram"
check_host "whatsapp.com" "WhatsApp"
check_host "messenger.com" "Messenger"

echo ""
echo "🔍 GOOGLE SERVICES"
echo "-------------------"
check_host "google.com" "Google"
check_host "youtube.com" "YouTube"
check_host "googlevideo.com" "Google Video CDN"

echo ""
echo "📲 SOCIAL & CONTENT"
echo "-------------------"
check_host "tiktok.com" "TikTok"
check_host "twitter.com" "X / Twitter"
check_host "netflix.com" "Netflix"

echo ""
echo "🛒 E-COMMERCE"
echo "-------------------"
check_host "shopee.co.id" "Shopee"
check_host "tokopedia.com" "Tokopedia"
check_host "lazada.co.id" "Lazada"

echo ""
echo "🎮 GAMING"
echo "-------------------"
check_host "mobilelegends.com" "Mobile Legends"
check_host "freefire.com" "Free Fire"
check_host "roblox.com" "Roblox"
check_host "pubg.com" "PUBG"

echo ""
echo "-------------------------------------------------------------------"
echo "✅ Pass: $PASS  |  ⚠️ Warning: $WARN  |  ❌ Fail: $FAIL"
echo "Total: $((PASS + WARN + FAIL)) layanan dicek"
echo "========================================="
echo "  🟢 <10ms Excellent | 🟡 10-30ms Good"
echo "  🟠 >30ms Lag | 🔴 Timeout/Offline"
echo "========================================="
