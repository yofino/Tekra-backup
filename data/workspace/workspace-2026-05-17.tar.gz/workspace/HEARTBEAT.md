# HEARTBEAT.md

## Cek Model Aktif
Setiap heartbeat, panggil `session_status` dan cek model yang sedang aktif.
- Kalau model **bukan** `deepseek/deepseek-v4-pro` (misal sudah fallback ke model lain), kirim notif WhatsApp ke Yofi (+6282115448084) dengan pesan singkat: model DeepSeek V4 Pro sudah limit, sekarang pakai [nama model aktif].
- Kalau masih DeepSeek V4 Pro, tidak perlu notif — lanjut HEARTBEAT_OK.
- Jangan spam: kalau sudah pernah notif fallback di session yang sama, skip (cukup sekali per transisi).

## PR / Todo List
- [ ] Inventarisir perangkat per POP (MikroTik, OLT, switch, modem, UPS, dll)
- [ ] OLT Monitoring per POP (EPON Pusat, GPON Pusat, Cilisung, Dago)
- [ ] pfSense Katapang — jika ada
- [ ] Alert Zabbix → WhatsApp
- [ ] Google Postmaster Tools untuk mail.tekra.id
