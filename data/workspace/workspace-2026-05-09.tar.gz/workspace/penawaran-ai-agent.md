# PENAWARAN JASA
## Implementasi AI Agent Assistant
**Teknologi Rakyat / Yofi Consulting**
Bandung, April 2026

---

## 1. LATAR BELAKANG

Seiring berkembangnya kebutuhan operasional perusahaan, efisiensi komunikasi dan otomasi proses internal menjadi kebutuhan yang semakin penting. AI Agent Assistant hadir sebagai solusi cerdas yang mampu membantu tim dalam menjawab pertanyaan, mengelola data, mengirim notifikasi otomatis, hingga mengintegrasikan berbagai sistem yang sudah berjalan — semua melalui antarmuka chat seperti WhatsApp.

---

## 2. RUANG LINGKUP PEKERJAAN

### Fase 1 — Setup Infrastruktur
- Pengadaan dan konfigurasi Mini PC (server lokal)
- Instalasi Proxmox VE sebagai hypervisor (virtualisasi)
- Konfigurasi jaringan lokal & remote access yang aman
- Setup storage, backup, dan monitoring dasar

### Fase 2 — Instalasi AI Agent (2 Agent)

**Agent 1 — AI Assistant Operasional (Internal)**
- Terhubung ke WhatsApp perusahaan
- Bisa menjawab pertanyaan internal: stok, jadwal servis, status order
- Terintegrasi dengan data perusahaan (spreadsheet / sistem existing)
- Laporan on-demand via chat

**Agent 2 — AI Workflow Automation (n8n)**
- Otomasi proses repetitif (notifikasi, reminder, update data)
- Trigger otomatis berdasarkan event (tiket masuk, stok menipis, dll)
- Koneksi ke WhatsApp, Email, Google Sheets, dan sistem lainnya

### Fase 3 — Training & Handover
- Training tim internal (1-2 sesi)
- Dokumentasi teknis & user guide
- Garansi support 1 bulan pertama

---

## 3. REKOMENDASI SPESIFIKASI MINI PC

Untuk menjalankan Proxmox + 2 AI Agent secara stabil, berikut rekomendasi hardware:

### ✅ Rekomendasi Utama — Beelink EQR6 / Minisforum UM890 Pro
| Komponen | Spesifikasi |
|---|---|
| Processor | AMD Ryzen 9 6900HX / Ryzen 9 8945HS |
| RAM | 32 GB DDR5 (upgradeable ke 64 GB) |
| Storage | 512 GB NVMe SSD (OS) + 1 TB SSD (Data) |
| Network | 2.5 GbE LAN + WiFi 6 |
| Power | ~35-65W (hemat listrik) |
| Estimasi Harga | Rp 4.500.000 – 6.500.000 |

### 💡 Alternatif Budget — Beelink SEi12 / GMKtec G3
| Komponen | Spesifikasi |
|---|---|
| Processor | Intel Core i5/i7 Gen 12 |
| RAM | 16 GB DDR4 |
| Storage | 512 GB NVMe SSD |
| Network | 1 GbE LAN |
| Estimasi Harga | Rp 2.500.000 – 3.500.000 |

> Catatan: Harga di atas adalah estimasi. Hardware tidak termasuk dalam jasa kecuali disepakati pengadaan bersama.

---

## 4. INVESTASI JASA

### Opsi A — Paket Lengkap
| Item | Harga |
|---|---|
| Setup Proxmox & Infrastruktur | Rp 2.000.000 |
| Instalasi & Konfigurasi AI Agent 1 (Assistant) | Rp 4.000.000 |
| Instalasi & Konfigurasi AI Agent 2 (Automation) | Rp 3.000.000 |
| Training & Dokumentasi | Rp 1.000.000 |
| **Total Setup** | **Rp 10.000.000** |
| Monthly Maintenance & Support | Rp 1.500.000 / bulan |

### Opsi B — Paket Starter (1 Agent dulu)
| Item | Harga |
|---|---|
| Setup Proxmox & Infrastruktur | Rp 2.000.000 |
| Instalasi AI Agent 1 (Assistant WhatsApp) | Rp 4.000.000 |
| Training & Dokumentasi | Rp 500.000 |
| **Total Setup** | **Rp 6.500.000** |
| Monthly Maintenance & Support | Rp 1.000.000 / bulan |

> Harga di atas belum termasuk biaya API (OpenAI/Anthropic) jika menggunakan model cloud. Estimasi API: USD 10-30/bulan tergantung penggunaan. Tersedia juga opsi model lokal (tanpa biaya API) dengan spek hardware yang lebih tinggi.

---

## 5. TIMELINE PENGERJAAN

| Minggu | Kegiatan |
|---|---|
| Minggu 1 | Setup hardware, instalasi Proxmox, konfigurasi jaringan |
| Minggu 2 | Instalasi & konfigurasi AI Agent 1 |
| Minggu 3 | Instalasi & konfigurasi AI Agent 2 + integrasi |
| Minggu 4 | Testing, training tim, dokumentasi & handover |

---

## 6. YANG DIDAPATKAN

- ✅ Server AI yang berjalan 24/7 di lingkungan perusahaan sendiri
- ✅ Data tidak keluar ke pihak ketiga (privacy terjaga)
- ✅ 2 AI Agent siap pakai sesuai kebutuhan operasional
- ✅ Dokumentasi teknis & user guide
- ✅ Support & maintenance selama masa kontrak
- ✅ Sistem dapat dikembangkan seiring kebutuhan bertumbuh

---

## 7. SYARAT & KETENTUAN

- Pembayaran: 50% di muka, 50% setelah selesai
- Revisi fitur di luar scope dikenakan biaya tambahan sesuai kompleksitas
- Maintenance contract dapat diperpanjang setiap 3/6/12 bulan
- Penawaran berlaku 14 hari sejak tanggal diterbitkan

---

## 8. KONTAK

**Yofi**
WhatsApp: +62 821-1544-8084

---

*Penawaran ini bersifat konfidensial dan ditujukan khusus untuk pihak yang bersangkutan.*
