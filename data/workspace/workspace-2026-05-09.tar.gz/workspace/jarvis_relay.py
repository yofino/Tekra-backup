#!/usr/bin/env python3
"""
Jarvis Relay - HTTP bridge antara STB dan OpenClaw
Endpoints:
  GET  /         → health check
  POST /ask      → text → OpenClaw agent → reply
  POST /transcribe → WAV audio → Whisper STT → transcript
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import subprocess
import json
import os
import sys
import tempfile

PORT = 8765

# Cari path openclaw
OPENCLAW_BIN = subprocess.run(["which", "openclaw"], capture_output=True, text=True).stdout.strip()
if not OPENCLAW_BIN:
    OPENCLAW_BIN = "/usr/bin/openclaw"

print(f"[Relay] openclaw path: {OPENCLAW_BIN}", flush=True)
print(f"[Relay] HOME: {os.environ.get('HOME', 'NOT SET')}", flush=True)

# Load Whisper sekali saat startup (supaya cepat)
_whisper_model = None
def get_whisper():
    global _whisper_model
    if _whisper_model is None:
        print("[Relay] Loading Whisper model (base)...", flush=True)
        import whisper
        _whisper_model = whisper.load_model("base")
        print("[Relay] Whisper ready!", flush=True)
    return _whisper_model


class JarvisHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[Relay] {fmt % args}", flush=True)

    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'{"status":"Jarvis relay running"}')

    def do_POST(self):
        if self.path == "/ask":
            self._handle_ask()
        elif self.path == "/transcribe":
            self._handle_transcribe()
        else:
            self.send_response(404)
            self.end_headers()

    # ── /ask: text → OpenClaw → reply ────────────────────────────
    def _handle_ask(self):
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len)

        try:
            data = json.loads(body)
            message = data.get("message", "").strip()
        except Exception as e:
            print(f"[Relay] JSON parse error: {e}", flush=True)
            self._json({"reply": "Error parse request"})
            return

        if not message:
            self._json({"reply": "Pesan kosong"})
            return

        print(f"[Relay] 📝 Input: {message}", flush=True)

        env = {
            **os.environ,
            "HOME": "/root",
            "PATH": "/usr/local/bin:/usr/bin:/bin:/usr/lib/node_modules/.bin",
        }

        cmd = [
            OPENCLAW_BIN, "agent",
            "--message", message,
            "--session-id", "jarvis-stb",
            "--json",
            "--timeout", "60"
        ]

        print(f"[Relay] Running openclaw agent...", flush=True)

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=65, env=env
            )
            stdout = result.stdout.strip()
            stderr = result.stderr.strip()

            if stderr:
                print(f"[Relay] Stderr: {stderr[:200]}", flush=True)

            if result.returncode == 0 and stdout:
                try:
                    resp = json.loads(stdout)
                    payloads = resp.get("result", {}).get("payloads", [])
                    if payloads and payloads[0].get("text"):
                        reply = payloads[0]["text"].strip()
                    else:
                        reply = (
                            resp.get("reply") or
                            resp.get("text") or
                            resp.get("message") or
                            stdout
                        )
                except json.JSONDecodeError:
                    reply = stdout
            else:
                reply = f"Maaf, ada masalah teknis. ({result.returncode})"

        except subprocess.TimeoutExpired:
            reply = "Maaf, Asep lagi sibuk. Coba lagi ya."
            print("[Relay] ⏰ Timeout!", flush=True)
        except Exception as e:
            reply = f"Error internal: {e}"
            print(f"[Relay] ❌ Exception: {e}", flush=True)

        print(f"[Relay] 💬 Reply: {reply[:150]}", flush=True)
        self._json({"reply": reply})

    # ── /transcribe: WAV audio → Whisper → transcript ─────────────
    def _handle_transcribe(self):
        content_len = int(self.headers.get("Content-Length", 0))
        if content_len == 0:
            self._json({"transcript": "", "error": "no audio data"})
            return

        audio_data = self.rfile.read(content_len)
        print(f"[Relay] 🎤 Transcribe request: {content_len} bytes", flush=True)

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            wav_path = f.name
            f.write(audio_data)

        try:
            model = get_whisper()
            result = model.transcribe(wav_path, language="id", fp16=False)
            transcript = result["text"].strip()
            print(f"[Relay] 📝 Transcript: {transcript!r}", flush=True)
            self._json({"transcript": transcript})
        except Exception as e:
            print(f"[Relay] ❌ Whisper error: {e}", flush=True)
            self._json({"transcript": "", "error": str(e)})
        finally:
            try: os.unlink(wav_path)
            except: pass

    def _json(self, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)


class ReusableHTTPServer(HTTPServer):
    allow_reuse_address = True

if __name__ == "__main__":
    # Pre-load Whisper at startup
    try:
        get_whisper()
    except Exception as e:
        print(f"[Relay] ⚠️  Whisper preload failed: {e}", flush=True)

    print(f"[Relay] 🚀 Starting on 0.0.0.0:{PORT}", flush=True)
    server = ReusableHTTPServer(("0.0.0.0", PORT), JarvisHandler)
    print(f"[Relay] ✅ Listening!", flush=True)
    sys.stdout.flush()
    server.serve_forever()
