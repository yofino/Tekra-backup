from pathlib import Path

root = Path('/www/wwwroot/portal.tekra.id')

# Patch login_helper.php
lh = root / 'application/helpers/login_helper.php'
text = lh.read_text()
old_get = """    $data = [
        'web_url' => $domain,
    ];
    $postdata = json_encode($data);
    $url = $server . 'version/getpackage';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    $result = curl_exec($ch);
    $dt = json_decode(preg_replace('/[\\x00-\\x1F\\x80-\\xFF]/', '', $result), true);

    curl_close($ch);
    if ($dt['code'] == 1) {
        $package = $dt['package'];
        if ($package != $oldpackage) {
            $other['package'] = $package;
            $ci->db->update('other', $other);
        }
    } else {
        $package = '';
    }
    return $package;
}"""
new_get = """    $data = [
        'web_url' => $domain,
    ];
    $postdata = json_encode($data);
    $url = $server . 'version/getpackage';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    $result = curl_exec($ch);
    $cleanResult = is_string($result) ? preg_replace('/[\\x00-\\x1F\\x80-\\xFF]/', '', $result) : '';
    $dt = json_decode($cleanResult, true);

    curl_close($ch);
    if (is_array($dt) && isset($dt['code']) && $dt['code'] == 1 && !empty($dt['package'])) {
        $package = $dt['package'];
        if ($package != $oldpackage) {
            $other['package'] = $package;
            $ci->db->update('other', $other);
        }
    } else {
        $package = '';
    }
    return $package;
}"""
if old_get not in text:
    raise SystemExit('old getpackage block not found')
text = text.replace(old_get, new_get, 1)

old_pkg = """function package()
{
    $ci = get_instance();
    // Pastikan builder bersih agar tidak membawa where dari query lain (misal coverage)
    $ci->db->reset_query();
    $other = $ci->db->get_where('other', ['id' => 1])->row_array();
    if ($other['package'] == '') {
        if (getpackage() != '') {
            $ci->db->update('other', [
                'package' => getpackage(),
            ]);
        }

        $package = $ci->db->get('package')->row_array();
    } else {
        $package = decryptArray($other['package'], 'abdussalam');
    }
    return $package;
}"""
new_pkg = """function package()
{
    static $packageCache = null;
    if ($packageCache !== null) {
        return $packageCache;
    }

    $ci = get_instance();
    // Pastikan builder bersih agar tidak membawa where dari query lain (misal coverage)
    $ci->db->reset_query();
    $other = $ci->db->get_where('other', ['id' => 1])->row_array();

    if (empty($other['package'])) {
        $fetchedPackage = getpackage();
        if ($fetchedPackage != '') {
            $ci->db->update('other', [
                'package' => $fetchedPackage,
            ]);
            $other['package'] = $fetchedPackage;
        }

        if (!empty($other['package'])) {
            $package = decryptArray($other['package'], 'abdussalam');
        } else {
            $package = $ci->db->get('package')->row_array();
        }
    } else {
        $package = decryptArray($other['package'], 'abdussalam');
    }

    if (!is_array($package)) {
        $package = $ci->db->get('package')->row_array();
    }

    $packageCache = $package;
    return $packageCache;
}"""
if old_pkg not in text:
    raise SystemExit('old package() block not found')
text = text.replace(old_pkg, new_pkg, 1)
lh.write_text(text)

# Patch backend.php
bh = root / 'application/views/backend.php'
text = bh.read_text()
old_view = """                    <?php
                    $licence = verify_license();
    $licence = json_decode($licence, true);
    $exp = $licence['expired'];
    $beforeexp = date('Y-m-d', strtotime('-5 day', strtotime($exp)));
    if (package()['code_apps'] == null) {
        getpackage();
        $codeapps = $licence['server'];
    } else {
        $codeapps = $licence['server'] . 'licence/extend?codeapps=' . package()['code_apps'];
    }
    ?>"""
new_view = """                    <?php
                    $licence = verify_license();
    $licence = json_decode($licence, true);
    $exp = $licence['expired'];
    $beforeexp = date('Y-m-d', strtotime('-5 day', strtotime($exp)));
    $packageInfo = package();
    if (empty($packageInfo['code_apps'])) {
        $codeapps = $licence['server'];
    } else {
        $codeapps = $licence['server'] . 'licence/extend?codeapps=' . $packageInfo['code_apps'];
    }
    ?>"""
if old_view not in text:
    raise SystemExit('old backend.php block not found')
text = text.replace(old_view, new_view, 1)
bh.write_text(text)

print('patched files OK')
