#!/usr/bin/env python3
import sqlite3
import sys
from datetime import datetime, timedelta

def get_report(period="day"):
    db_path = "/root/.openclaw/workspace/finance/expenses.db"
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    if period == "day":
        query = """
            SELECT category, SUM(amount), COUNT(*)
            FROM expenses 
            WHERE date >= date('now', 'localtime')
            GROUP BY category
            ORDER BY SUM(amount) DESC
        """
        title = "Harian"
    elif period == "week":
        query = """
            SELECT category, SUM(amount), COUNT(*)
            FROM expenses 
            WHERE date >= date('now', 'localtime', '-7 days')
            GROUP BY category
            ORDER BY SUM(amount) DESC
        """
        title = "Mingguan (7 hari terakhir)"
    elif period == "month":
        query = """
            SELECT category, SUM(amount), COUNT(*)
            FROM expenses 
            WHERE date >= date('now', 'localtime', '-30 days')
            GROUP BY category
            ORDER BY SUM(amount) DESC
        """
        title = "Bulanan (30 hari terakhir)"
    else:
        return "Invalid period. Use: day, week, month"
    
    cursor.execute(query)
    results = cursor.fetchall()
    
    conn.close()
    
    if not results:
        return f"📊 Laporan {title}\nTidak ada pengeluaran tercatat."
    
    report = f"📊 Laporan Pengeluaran {title}\n"
    report += "=" * 40 + "\n"
    
    total = 0
    for category, amount, count in results:
        report += f"{category:15} {amount:,.0f} ({count}x)\n"
        total += amount
    
    report += "=" * 40 + "\n"
    report += f"TOTAL: {total:,.0f}\n"
    
    return report

if __name__ == "__main__":
    period = sys.argv[1] if len(sys.argv) > 1 else "day"
    print(get_report(period))