#!/usr/bin/env python3
import sqlite3
import sys
import datetime

def add_expense(amount, category, description="", payment_method="cash"):
    db_path = "/root/.openclaw/workspace/finance/expenses.db"
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO expenses (date, amount, category, description, payment_method)
        VALUES (datetime('now', 'localtime'), ?, ?, ?, ?)
    """, (amount, category, description, payment_method))
    
    conn.commit()
    conn.close()
    
    print(f"✅ Expense recorded: {amount} - {category} - {description}")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 add_expense.py <amount> <category> [description] [payment_method]")
        print("Example: python3 add_expense.py 50000 makan \"Makan siang\" cash")
        sys.exit(1)
    
    amount = float(sys.argv[1])
    category = sys.argv[2]
    description = sys.argv[3] if len(sys.argv) > 3 else ""
    payment_method = sys.argv[4] if len(sys.argv) > 4 else "cash"
    
    add_expense(amount, category, description, payment_method)