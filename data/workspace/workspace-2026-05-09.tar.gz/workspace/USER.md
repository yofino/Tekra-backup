# USER.md - About Your Human

- **Name:** Yofi
- **What to call them:** Yofi
- **Pronouns:** -
- **Timezone:** GMT+7 (Asia/Jakarta)
- **Location:** Bandung
- **Language:** Bahasa Indonesia
- **Tanggal Lahir:** 3 Juli 1995
- **Notes:** Suka yang santai, gak suka ribet

## Context

### Kerjaan
- **Pengusaha ISP** (Internet Service Provider) skala kecil
- Server ISP ada di **rumah ortu**, bukan di rumah Yofi sendiri
- Asep di-install di server yang sama dengan infrastruktur ISP

### Staff / Kontak
- **Neng Resti** — Staff administrasi Yofi
  - No. HP: 0895 610382802
  - Yofi memanggilnya "Neng Resti"

### Notes
_(Bakal diupdate seiring waktu)_
