# Dashboard Inventaris Tekra

## Lokasi
- [[01 Lokasi/Pusat|Pusat]]
- [[01 Lokasi/Dago|Dago]]
- [[01 Lokasi/Katapang|Katapang]]
- [[01 Lokasi/Cilisung|Cilisung]]

## Perangkat sample yang sudah tercatat
- [[02 Perangkat/Firewall/pfSense Pusat|pfSense Pusat]]
- [[02 Perangkat/MikroTik/MikroTik Dago|MikroTik Dago]]
- [[02 Perangkat/MikroTik/MikroTik Katapang|MikroTik Katapang]]
- [[02 Perangkat/MikroTik/MikroTik Cilisung|MikroTik Cilisung]]
- [[02 Perangkat/Monitoring/Zabbix|Zabbix]]
- [[02 Perangkat/Monitoring/Grafana|Grafana]]
- [[02 Perangkat/Server/Proxmox VE|Proxmox VE]]

## Status
- Ini masih sample awal
- Belum semua perangkat masuk
- Belum semua status monitoring terisi
- Nanti bisa ditambah OLT, VPS, ACS, CCTV, Raspberry Pi, dll
