# Dago

## Perangkat
- [[../02 Perangkat/MikroTik/MikroTik Dago|MikroTik Dago]]

## Catatan
- pfSense Dago ada, tapi belum dimasukin ke sample ini
- Menurut Yofi ada 2 perangkat OLT di Dago yang belum masuk inventaris

#lokasi #dago
