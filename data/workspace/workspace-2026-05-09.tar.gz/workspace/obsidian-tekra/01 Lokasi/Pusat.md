# Pusat

## Perangkat
- [[../02 Perangkat/Firewall/pfSense Pusat|pfSense Pusat]]
- [[../02 Perangkat/Monitoring/Zabbix|Zabbix]]
- [[../02 Perangkat/Monitoring/Grafana|Grafana]]
- [[../02 Perangkat/Server/Proxmox VE|Proxmox VE]]

## Catatan
- Lokasi inti jaringan Tekra
- Ada perangkat lain yang belum masuk: CCR1, CCR2, x86 Pusat, ACS, OLT EPON, OLT GPON, Raspberry Pi IoT, NVR, absensi

#lokasi #pusat
