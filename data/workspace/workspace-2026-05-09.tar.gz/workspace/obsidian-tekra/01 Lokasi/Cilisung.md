# Cilisung

## Perangkat
- [[../02 Perangkat/MikroTik/MikroTik Cilisung|MikroTik Cilisung]]

## Catatan
- Ada 2 perangkat lain di Cilisung yang belum masuk inventaris

#lokasi #cilisung
