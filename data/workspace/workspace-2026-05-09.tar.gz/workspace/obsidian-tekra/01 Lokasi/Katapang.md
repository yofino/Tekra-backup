# Katapang

## Perangkat
- [[../02 Perangkat/MikroTik/MikroTik Katapang|MikroTik Katapang]]

## Catatan
- Ada 1 OLT di Katapang yang belum masuk inventaris

#lokasi #katapang
