---
nama: pfSense Pusat
lokasi: Pusat
jenis: Firewall / Gateway
ip: 192.168.123.1
url: https://192.168.123.1
username: admin
password: k34Nu335577
monitoring: sebagian
status_akses: bisa diakses
---

# pfSense Pusat

- **Lokasi:** [[../../01 Lokasi/Pusat|Pusat]]
- **Jenis:** Firewall / Gateway
- **IP/URL:** `https://192.168.123.1`
- **Username:** `admin`
- **Password:** `k34Nu335577`
- **Monitoring:** sebagian

## Catatan
- Menangani load balancing pusat
- Gateway subnet yang tercatat: WAN1=50.1, WAN2=60.1, WAN3=70.1, WAN4=80.1, WAN5=90.1, WAN6=124.1, WAN7=110.1
- WAN4 sempat offline karena modem ISP rusak

#pfsense #pusat #network #monitoring
