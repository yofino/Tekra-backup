---
nama: Proxmox VE
lokasi: Pusat
jenis: Virtualization Host
ip: 10.10.10.4
url: https://10.10.10.4:8006
username: root
password: k34Nu335577
monitoring: belum dipastikan
---

# Proxmox VE

- **Lokasi:** [[../../01 Lokasi/Pusat|Pusat]]
- **IP/URL:** `https://10.10.10.4:8006`
- **Username:** `root`
- **Password:** `k34Nu335577`

## Catatan
- VM 118 (MONITORING, 4GB)
- CT103 (LXC, 2GB)

#proxmox #pusat #server
