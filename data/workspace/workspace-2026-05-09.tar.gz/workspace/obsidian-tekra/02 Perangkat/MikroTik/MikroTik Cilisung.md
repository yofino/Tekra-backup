---
nama: MikroTik Cilisung
lokasi: Cilisung
jenis: Router
ip: 10.6.0.5
ssh_port: 18
username: asep
password: asep$888
board: RB4011iGS+
routeros: 7.16.1 (stable)
akses: full
monitoring: belum dipastikan
---

# MikroTik Cilisung

- **Lokasi:** [[../../01 Lokasi/Cilisung|Cilisung]]
- **IP:** `10.6.0.5:18`
- **Username:** `asep`
- **Password:** `asep$888`
- **Board:** `RB4011iGS+`
- **RouterOS:** `7.16.1 (stable)`
- **Akses:** `full`

## Catatan
- Identity router: `CILISUNG`
- Akses SSH berhasil
- Ada 2 perangkat lain di Cilisung yang belum masuk inventaris

#mikrotik #cilisung #router
