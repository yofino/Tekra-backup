---
nama: MikroTik Katapang
lokasi: Katapang
jenis: Router
ip: 10.6.0.4
ssh_port: 18
username: asep
password: asep$888
board: RB450Gx4
routeros: 7.19.4 (stable)
akses: full
monitoring: belum dipastikan
---

# MikroTik Katapang

- **Lokasi:** [[../../01 Lokasi/Katapang|Katapang]]
- **IP:** `10.6.0.4:18`
- **Username:** `asep`
- **Password:** `asep$888`
- **Board:** `RB450Gx4`
- **RouterOS:** `7.19.4 (stable)`
- **Akses:** `full`

## Catatan
- Identity router: `BARANG KITA`
- Akses SSH berhasil
- Ada 1 OLT di Katapang yang belum masuk inventaris

#mikrotik #katapang #router
