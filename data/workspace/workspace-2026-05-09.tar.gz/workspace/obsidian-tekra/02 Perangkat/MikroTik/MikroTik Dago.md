---
nama: MikroTik Dago
lokasi: Dago
jenis: Router
ip: 10.6.0.2
ssh_port: 18
username: asep
password: asep$888
board: CCR1009-7G-1C-1S+
routeros: 6.48.6 (long-term)
akses: full
monitoring: belum dipastikan
---

# MikroTik Dago

- **Lokasi:** [[../../01 Lokasi/Dago|Dago]]
- **IP:** `10.6.0.2:18`
- **Username:** `asep`
- **Password:** `asep$888`
- **Board:** `CCR1009-7G-1C-1S+`
- **RouterOS:** `6.48.6 (long-term)`
- **Akses:** `full`

## Catatan
- Akses SSH berhasil
- Dago juga punya 2 perangkat OLT yang belum masuk inventaris

#mikrotik #dago #router
