---
nama: Grafana
lokasi: Pusat
jenis: Monitoring Dashboard
ip: 10.10.10.18
port: 3000
url: http://10.10.10.18:3000
monitoring: aktif
---

# Grafana

- **Lokasi:** [[../../01 Lokasi/Pusat|Pusat]]
- **IP/URL:** `http://10.10.10.18:3000`

## Catatan
- Satu host dengan Zabbix
- Dipakai untuk visualisasi monitoring

#grafana #pusat #monitoring
