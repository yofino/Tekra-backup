---
nama: Zabbix
lokasi: Pusat
jenis: Monitoring
ip: 10.10.10.18
url: http://10.10.10.18/zabbix
username: Admin
password: zabbix
monitoring: aktif
---

# Zabbix

- **Lokasi:** [[../../01 Lokasi/Pusat|Pusat]]
- **IP/URL:** `http://10.10.10.18/zabbix`
- **Username:** `Admin`
- **Password:** `zabbix`

## Catatan
- Dipakai untuk monitoring perangkat Tekra
- API: `http://10.10.10.18/zabbix/api_jsonrpc.php`

#zabbix #pusat #monitoring
