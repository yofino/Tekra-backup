<?php
require_once '/www/wwwroot/portal.tekra.id/application/libraries/Mikweb.php';

$customerId = 976;
$coverageId = 1; // BOJONG SEUREUH
$routerId = 2;   // PUSAT X86
$username = '20260428133854-RONY';
$profile = 'PAKET HEMAT';
$customerName = 'RONY';
$comment = 'RONY - Bojong Seureuh';

$routerIp = 'id-24.tunnel.web.id';
$routerUser = 'keanu';
$routerPass = 'k34Nu335577';
$routerPort = 2614;

$dsn = 'mysql:host=localhost;dbname=portal;unix_socket=/tmp/mysql.sock;charset=utf8';
$pdo = new PDO($dsn, 'portal', 'portal');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$customer = $pdo->query("SELECT customer_id, no_services, name, address, c_status FROM customer WHERE customer_id = {$customerId}")->fetch(PDO::FETCH_ASSOC);
if (!$customer) {
    fwrite(STDERR, "Customer tidak ditemukan\n");
    exit(1);
}

$api = new Mikweb();
$api->connect($routerIp, $routerUser, $routerPass, $routerPort);

$existing = $api->comm('/ppp/secret/print', ['?name' => $username]);
if (empty($existing)) {
    $result = $api->comm('/ppp/secret/add', [
        'name' => $username,
        'password' => $username,
        'service' => 'pppoe',
        'profile' => $profile,
        'comment' => $comment,
    ]);
    if (isset($result[0]['!trap'])) {
        fwrite(STDERR, 'Gagal create PPPoE: ' . json_encode($result) . "\n");
        exit(1);
    }
    echo "PPPoE dibuat: {$username} | {$profile}\n";
} else {
    echo "PPPoE sudah ada: {$username}\n";
}

$stmt = $pdo->prepare("UPDATE customer SET coverage = :coverage, router = :router, user_mikrotik = :user_mikrotik, user_profile = :user_profile, c_status = 'Aktif' WHERE customer_id = :customer_id");
$stmt->execute([
    ':coverage' => $coverageId,
    ':router' => $routerId,
    ':user_mikrotik' => $username,
    ':user_profile' => $profile,
    ':customer_id' => $customerId,
]);

$verify = $pdo->query("SELECT customer_id, no_services, name, coverage, router, user_mikrotik, user_profile, c_status FROM customer WHERE customer_id = {$customerId}")->fetch(PDO::FETCH_ASSOC);
echo json_encode($verify, JSON_UNESCAPED_SLASHES) . "\n";
