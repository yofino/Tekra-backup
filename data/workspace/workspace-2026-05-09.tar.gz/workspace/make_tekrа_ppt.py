from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

RED = RGBColor(152, 26, 37)
DARK = RGBColor(40, 40, 40)
LIGHT = RGBColor(245, 245, 245)
WHITE = RGBColor(255, 255, 255)
GRAY = RGBColor(110, 110, 110)

slides = [
    {
        'title': 'PRESENTASI PENAWARAN PEKERJAAN',
        'subtitle': 'INSTALASI CCTV DAN INFRASTRUKTUR JARINGAN INTERNET\nProyek Apartemen Kawasan Telkom Bandung\n\nPrimadaya Teknologi Rakyat / TEKRA\nBandung, 2026',
        'bullets': []
    },
    {
        'title': 'PROFIL PERUSAHAAN',
        'bullets': [
            'Primadaya Teknologi Rakyat bergerak di bidang solusi teknologi dan infrastruktur.',
            'Fokus layanan mencakup instalasi dan konfigurasi jaringan, CCTV/surveillance, access control, dan building technology support.',
            'Didukung tim teknis profesional untuk menghadirkan solusi yang rapi, efisien, dan sesuai kebutuhan proyek.'
        ]
    },
    {
        'title': 'KEUNGGULAN KAMI',
        'bullets': [
            'Pengalaman pekerjaan jaringan dan CCTV secara terintegrasi.',
            'Tim teknis lapangan siap eksekusi dan commissioning.',
            'Standar instalasi rapi, terstruktur, dan mudah dipelihara.',
            'Pendekatan kerja adaptif terhadap kondisi lapangan.',
            'Komitmen pada kualitas hasil dan ketepatan waktu pengerjaan.'
        ]
    },
    {
        'title': 'PENGALAMAN DAN PORTOFOLIO',
        'bullets': [
            'Sektor yang pernah kami dukung: pemerintahan, perbankan, pendidikan, hotel & properti, industri & komersial.',
            'Referensi portofolio: BPJS Kesehatan, Bank BJB, OCBC, ITB, UPI, Padma Hotel Bandung, Summarecon Bandung, Medion, dan berbagai proyek lainnya.'
        ]
    },
    {
        'title': 'LATAR BELAKANG PROYEK',
        'bullets': [
            'Primadaya Teknologi Rakyat memperoleh kesempatan untuk mendukung pekerjaan instalasi pada proyek apartemen 20 lantai di kawasan Telkom Bandung.',
            'Tahap awal difokuskan pada 7 lantai area pekerjaan dengan 6 level denah area hunian: 401-B, 402, 403, 404, 405, dan 406.',
            'Pekerjaan utama meliputi instalasi sistem CCTV dan infrastruktur jaringan internet ke tiap unit/kamar.'
        ]
    },
    {
        'title': 'RUANG LINGKUP PEKERJAAN',
        'bullets': [
            'Penarikan kabel UTP dan penyediaan material pendukung instalasi UTP.',
            'Instalasi dan konfigurasi access point, switch, core switch, dan router.',
            'Instalasi dan konfigurasi CCTV, NVR, close rack, dan wallmount rack.',
            'Penarikan backbone fiber optic antar lantai.',
            'Penyesuaian/pembongkaran kabel existing, testing, commissioning, dan handover.'
        ]
    },
    {
        'title': 'REKAP VOLUME PEKERJAAN',
        'bullets': [
            '331 titik/kamar layanan jaringan internet.',
            '71 titik CCTV.',
            '381 titik jasa penarikan kabel UTP.',
            '310 unit instalasi dan konfigurasi access point.',
            '20 unit switch, 1 core switch, 1 router, dan 4 NVR.',
            'Backbone antar lantai menggunakan Fiber Optic, distribusi ke tiap unit menggunakan LAN/UTP.'
        ]
    },
    {
        'title': 'KONSEP DESAIN SISTEM',
        'bullets': [
            'Backbone utama antar lantai menggunakan fiber optic.',
            'Distribusi ke tiap unit/kamar menggunakan LAN.',
            'Perangkat aktif ditempatkan pada titik distribusi yang efisien dan mudah dipelihara.',
            'Kamera CCTV ditempatkan pada area strategis sesuai layout dan kebutuhan pengawasan.',
            'Seluruh sistem CCTV terintegrasi ke perangkat perekam NVR.'
        ]
    },
    {
        'title': 'METODE PELAKSANAAN PEKERJAAN',
        'bullets': [
            'Survey dan verifikasi lapangan: validasi layout, jalur kabel tray/existing, dan titik pemasangan.',
            'Finalisasi titik dan jalur instalasi: backbone FO, distribusi LAN, dan titik CCTV.',
            'Pekerjaan infrastruktur pasif: penarikan kabel UTP, backbone FO, support system, dan penataan rack.',
            'Pemasangan perangkat aktif: switch, core switch, router, access point, CCTV, dan NVR.',
            'Konfigurasi dan integrasi sistem, dilanjutkan testing, commissioning, labeling, dokumentasi, dan handover.'
        ]
    },
    {
        'title': 'TIMELINE PELAKSANAAN',
        'bullets': [
            'Estimasi durasi pelaksanaan: 8–10 minggu.',
            'Minggu 1: survey final, koordinasi teknis, finalisasi titik dan jalur.',
            'Minggu 2–4: pekerjaan jalur kabel tray, backbone FO, dan penarikan kabel UTP.',
            'Minggu 5–7: pemasangan perangkat jaringan, access point, CCTV, dan NVR.',
            'Minggu 8: konfigurasi sistem, integrasi jaringan dan CCTV, testing awal.',
            'Minggu 9–10: commissioning, troubleshooting, labeling, dokumentasi, dan serah terima.'
        ]
    },
    {
        'title': 'RINGKASAN NILAI PENAWARAN',
        'bullets': [
            'Subtotal: Rp 486.767.317',
            'PPN: Rp 53.544.405',
            'Grand Total: Rp 540.311.722',
            'Penawaran mencakup pekerjaan instalasi, konfigurasi, material pendukung, backbone optik, testing, dan commissioning sesuai ruang lingkup yang diajukan.'
        ]
    },
    {
        'title': 'PENUTUP',
        'bullets': [
            'Primadaya Teknologi Rakyat siap menjadi mitra pelaksana untuk pekerjaan instalasi CCTV dan infrastruktur jaringan internet pada proyek apartemen ini.',
            'Kami berkomitmen memberikan kualitas pekerjaan yang baik, instalasi yang rapi dan terstruktur, pelaksanaan yang tepat waktu, serta sistem yang stabil, aman, dan siap operasional.',
            'Terima kasih atas perhatian dan kesempatan yang diberikan. Kami siap mendukung realisasi proyek ini secara profesional.'
        ]
    }
]

def add_header(slide, title):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, Inches(0.7))
    shape.fill.solid()
    shape.fill.fore_color.rgb = RED
    shape.line.color.rgb = RED
    tx = slide.shapes.add_textbox(Inches(0.5), Inches(0.12), Inches(12.2), Inches(0.4))
    p = tx.text_frame.paragraphs[0]
    r = p.add_run()
    r.text = title
    r.font.name = 'Poppins'
    r.font.bold = True
    r.font.size = Pt(24)
    r.font.color.rgb = WHITE

def add_footer(slide):
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, prs.slide_height - Inches(0.25), prs.slide_width, Inches(0.25))
    line.fill.solid()
    line.fill.fore_color.rgb = RED
    line.line.color.rgb = RED

for i, data in enumerate(slides):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = WHITE
    bg.line.color.rgb = WHITE

    if i == 0:
        top = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
        top.fill.solid()
        top.fill.fore_color.rgb = RED
        top.fill.transparency = 0.08
        top.line.color.rgb = WHITE

        bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.7), Inches(1.1), Inches(0.18), Inches(4.8))
        bar.fill.solid()
        bar.fill.fore_color.rgb = RED
        bar.line.color.rgb = RED

        title_box = slide.shapes.add_textbox(Inches(1.1), Inches(1.2), Inches(11), Inches(1.6))
        tf = title_box.text_frame
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        r = p.add_run()
        r.text = data['title']
        r.font.name = 'Poppins'
        r.font.bold = True
        r.font.size = Pt(26)
        r.font.color.rgb = RED

        sub_box = slide.shapes.add_textbox(Inches(1.15), Inches(2.4), Inches(10.8), Inches(3.0))
        tf = sub_box.text_frame
        for idx, line in enumerate(data['subtitle'].split('\n')):
            p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
            p.alignment = PP_ALIGN.LEFT
            r = p.add_run()
            r.text = line
            r.font.name = 'Calibri'
            r.font.size = Pt(19 if idx == 0 else 16)
            r.font.bold = idx == 0
            r.font.color.rgb = DARK if idx < 2 else GRAY
        add_footer(slide)
        continue

    add_header(slide, data['title'])

    content_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.1), Inches(11.8), Inches(5.8))
    tf = content_box.text_frame
    tf.word_wrap = True

    for idx, bullet in enumerate(data['bullets']):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.text = bullet
        p.level = 0
        p.space_after = Pt(10)
        p.font.name = 'Calibri'
        p.font.size = Pt(22 if len(data['bullets']) <= 4 else 20)
        p.font.color.rgb = DARK
        p.bullet = True

    if data['title'] == 'RINGKASAN NILAI PENAWARAN':
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(7.7), Inches(2.0), Inches(4.4), Inches(2.0))
        box.fill.solid()
        box.fill.fore_color.rgb = RED
        box.line.color.rgb = RED
        tx = slide.shapes.add_textbox(Inches(8.0), Inches(2.35), Inches(3.8), Inches(1.2))
        p = tx.text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        r = p.add_run()
        r.text = 'GRAND TOTAL\nRp 540.311.722'
        r.font.name = 'Poppins'
        r.font.bold = True
        r.font.size = Pt(24)
        r.font.color.rgb = WHITE

    add_footer(slide)

out = '/root/.openclaw/workspace/Presentasi_Penawaran_Apartemen_Tekra.pptx'
prs.save(out)
print(out)
