from pathlib import Path

root = Path('/www/wwwroot/portal.tekra.id')
lh = root / 'application/helpers/login_helper.php'
text = lh.read_text()
old_pkg = """function package()
{
    static $packageCache = null;
    if ($packageCache !== null) {
        return $packageCache;
    }

    $ci = get_instance();
    // Pastikan builder bersih agar tidak membawa where dari query lain (misal coverage)
    $ci->db->reset_query();
    $other = $ci->db->get_where('other', ['id' => 1])->row_array();

    if (empty($other['package'])) {
        $fetchedPackage = getpackage();
        if ($fetchedPackage != '') {
            $ci->db->update('other', [
                'package' => $fetchedPackage,
            ]);
            $other['package'] = $fetchedPackage;
        }

        if (!empty($other['package'])) {
            $package = decryptArray($other['package'], 'abdussalam');
        } else {
            $package = $ci->db->get('package')->row_array();
        }
    } else {
        $package = decryptArray($other['package'], 'abdussalam');
    }

    if (!is_array($package)) {
        $package = $ci->db->get('package')->row_array();
    }

    $packageCache = $package;
    return $packageCache;
}"""
new_pkg = """function package()
{
    static $packageCache = null;
    if ($packageCache !== null) {
        return $packageCache;
    }

    $ci = get_instance();
    // Pastikan builder bersih agar tidak membawa where dari query lain (misal coverage)
    $ci->db->reset_query();
    $other = $ci->db->get_where('other', ['id' => 1])->row_array();

    if (empty($other['package'])) {
        $retryTtl = 900;
        $retryMarker = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'portal_getpackage_last_try';
        $shouldRetry = true;

        if (is_file($retryMarker) && (time() - @filemtime($retryMarker)) < $retryTtl) {
            $shouldRetry = false;
        }

        if ($shouldRetry) {
            @file_put_contents($retryMarker, (string) time());
            $fetchedPackage = getpackage();
            if ($fetchedPackage != '') {
                $ci->db->update('other', [
                    'package' => $fetchedPackage,
                ]);
                $other['package'] = $fetchedPackage;
            }
        }

        if (!empty($other['package'])) {
            $package = decryptArray($other['package'], 'abdussalam');
        } else {
            $package = $ci->db->get('package')->row_array();
        }
    } else {
        $package = decryptArray($other['package'], 'abdussalam');
    }

    if (!is_array($package)) {
        $package = $ci->db->get('package')->row_array();
    }

    $packageCache = $package;
    return $packageCache;
}"""
if old_pkg not in text:
    raise SystemExit('current package() block not found')
text = text.replace(old_pkg, new_pkg, 1)
lh.write_text(text)
print('patched package() retry cache')
