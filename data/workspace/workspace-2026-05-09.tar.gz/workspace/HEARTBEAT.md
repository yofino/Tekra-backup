# HEARTBEAT.md

## Cek Model Aktif
Setiap heartbeat, panggil `session_status` dan cek model yang sedang aktif.
- Jangan hardcode model primary. Pakai hasil live dari `session_status` atau config aktif.
- Kalau model primary atau fallback berubah tak sesuai config saat ini, baru notif ke Yofi sekali per transisi.
- Jangan spam: kalau sudah pernah notif fallback di session yang sama, skip (cukup sekali per transisi).
