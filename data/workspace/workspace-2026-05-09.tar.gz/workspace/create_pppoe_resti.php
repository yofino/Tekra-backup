<?php
// Script: create PPPoE for Resti Alyani di PUSAT X86
// Coverage: BOJONG SUREN GIRANG (ID=5), Router: PUSAT X86 (ID=2)
// Customer ID: 975, No Services: R-20260428105151

// Load Mikweb library
require_once '/www/wwwroot/portal.tekra.id/application/libraries/Mikweb.php';

// Router PUSAT X86
$router_ip   = 'id-24.tunnel.web.id';
$router_user = 'keanu';
$router_pass = 'k34Nu335577';
$router_port = 2614;

// Customer data
$customer_id  = 975;
$no_services  = 'R-20260428105151';
$customer_name = 'RESTI ALYANI';
// Username PPPoE: no_services tanpa R- prefix, pakai no_services asli angka + nama
// Berdasarkan format portal: 20260428105151-RESTI
$user_mikrotik = '20260428105151-RESTI';
$user_profile  = 'PAKET1';

echo "Connecting to MikroTik PUSAT X86...\n";
$API = new Mikweb();
try {
    $API->connect($router_ip, $router_user, $router_pass, $router_port);
} catch (Exception $e) {
    die("GAGAL connect MikroTik: " . $e->getMessage() . "\n");
}

echo "Connected OK\n";

// Cek apakah user sudah ada
$existing = $API->comm("/ppp/secret/print", ['?name' => $user_mikrotik]);
if (!empty($existing)) {
    echo "PPPoE user SUDAH ADA: $user_mikrotik\n";
} else {
    // Buat user PPPoE
    $result = $API->comm("/ppp/secret/add", [
        'name'     => $user_mikrotik,
        'password' => $user_mikrotik,
        'service'  => 'pppoe',
        'profile'  => $user_profile,
        'comment'  => $customer_name . ' - Bojong Suren Girang',
    ]);
    if (isset($result[0]['!trap'])) {
        die("GAGAL buat PPPoE: " . json_encode($result) . "\n");
    }
    echo "PPPoE user BERHASIL dibuat: $user_mikrotik | profile: $user_profile\n";
}

// Update database portal
$dsn = "mysql:host=localhost;dbname=portal;unix_socket=/tmp/mysql.sock;charset=utf8";
$pdo = new PDO($dsn, 'portal', 'portal');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->prepare("UPDATE customer SET 
    coverage = 5,
    router = 2,
    user_mikrotik = :um,
    user_profile = :up,
    c_status = 'Aktif'
    WHERE customer_id = :cid");
$stmt->execute([':um' => $user_mikrotik, ':up' => $user_profile, ':cid' => $customer_id]);
echo "DB updated: coverage=5, router=2, user_mikrotik=$user_mikrotik, user_profile=$user_profile, c_status=Aktif\n";

// Verifikasi
$row = $pdo->query("SELECT customer_id, name, no_services, coverage, router, user_mikrotik, user_profile, c_status FROM customer WHERE customer_id=975")->fetch(PDO::FETCH_ASSOC);
echo "HASIL: " . json_encode($row) . "\n";
echo "SELESAI.\n";
