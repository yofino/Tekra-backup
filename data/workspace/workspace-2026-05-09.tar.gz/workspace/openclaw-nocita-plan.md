# OpenClaw Docker Plan for VPS Nocita

## Goal
Deploy OpenClaw in Docker on VPS Nocita without disturbing existing aaPanel/web/mail services.

## Current host facts
- Web ports already used: 80, 443, 888
- Mail ports already used: 25, 465, 587, 110, 143, 993, 995
- Docker installed
- Docker Compose installed
- Port 18789 currently free

## Safe architecture
- Run OpenClaw in its own Docker project directory
- Bind OpenClaw UI/Gateway only to `127.0.0.1:18789`
- Do **not** bind to `0.0.0.0`
- Keep all persistent data on host path, not inside container
- If public access is needed later, expose it through aaPanel reverse proxy with auth/TLS, not by opening random ports directly

## Recommended host paths
- Project dir: `/opt/openclaw`
- Persistent data: `/opt/openclaw/data`
- Workspace: `/opt/openclaw/data/workspace`

## Example docker-compose.yml
```yaml
services:
  openclaw-gateway:
    image: ghcr.io/openclaw/openclaw:latest
    container_name: openclaw-gateway
    restart: unless-stopped
    ports:
      - "127.0.0.1:18789:18789"
    environment:
      TZ: Asia/Jakarta
      OPENCLAW_GATEWAY_TOKEN: "CHANGE_ME_LONG_RANDOM_TOKEN"
    volumes:
      - /opt/openclaw/data:/home/node/.openclaw
    healthcheck:
      test: ["CMD", "sh", "-lc", "wget -qO- http://127.0.0.1:18789/ >/dev/null 2>&1 || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 5
```

## Minimal deploy flow
1. Create `/opt/openclaw/data`
2. Save `docker-compose.yml`
3. Start container with `docker compose up -d`
4. Run onboarding/config once using the container/CLI
5. Open aaPanel reverse proxy only if needed

## Hard rules
- Never map OpenClaw to port 80/443 directly on this VPS
- Never install extra binaries manually inside the running container
- If a skill needs extra binaries, build a custom image and rebuild
- Keep mail stack and OpenClaw isolated

## aaPanel recommendation
Use aaPanel Docker only as a container manager. Avoid one-click app style deployment. Prefer a Compose project import if available.

## Optional next step
Create a custom Dockerfile if we need extra binaries/skills beyond the stock image.
