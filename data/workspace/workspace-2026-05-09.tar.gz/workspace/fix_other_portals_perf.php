<?php
if ($argc < 2) {
    fwrite(STDERR, "usage: php fix_other_portals_perf.php <root> [<root> ...]\n");
    exit(1);
}

function parseEnvFile($path) {
    $vars = [];
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) $vars[$parts[0]] = $parts[1];
    }
    return $vars;
}

function encryptArrayCompat($data, $key) {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt(serialize($data), 'aes-256-cbc', $key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

foreach (array_slice($argv, 1) as $root) {
    $root = rtrim($root, '/');
    $envPath = $root . '/.env';
    $backendPath = $root . '/application/views/backend.php';

    if (!is_file($envPath) || !is_file($backendPath)) {
        fwrite(STDERR, "skip invalid root: {$root}\n");
        continue;
    }

    $env = parseEnvFile($envPath);
    $db = @new mysqli($env['DB_HOSTNAME'] ?? 'localhost', $env['DB_USERNAME'] ?? '', $env['DB_PASSWORD'] ?? '', $env['DB_DATABASE'] ?? '', 3306, '/tmp/mysql.sock');
    if ($db->connect_error) {
        throw new RuntimeException("DB connect failed for {$root}: " . $db->connect_error);
    }
    $db->set_charset('utf8mb4');

    $res = $db->query("SELECT * FROM package LIMIT 1");
    if (!$res) {
        throw new RuntimeException("Query package failed for {$root}: " . $db->error);
    }
    $package = $res->fetch_assoc();
    if (!$package) {
        throw new RuntimeException("No package row for {$root}");
    }

    $encrypted = encryptArrayCompat($package, 'abdussalam');
    $stmt = $db->prepare("UPDATE other SET package=? WHERE id=1");
    if (!$stmt) {
        throw new RuntimeException("Prepare update failed for {$root}: " . $db->error);
    }
    $stmt->bind_param('s', $encrypted);
    if (!$stmt->execute()) {
        throw new RuntimeException("Update other.package failed for {$root}: " . $stmt->error);
    }
    $stmt->close();

    $backend = file_get_contents($backendPath);
    $old = <<<'PHP'
                    <?php
                    $licence = verify_license();
    $licence = json_decode($licence, true);
    $exp = $licence['expired'];
    $beforeexp = date('Y-m-d', strtotime('-5 day', strtotime($exp)));
    if (package()['code_apps'] == null) {
        getpackage();
        $codeapps = $licence['server'];
    } else {
        $codeapps = $licence['server'] . 'licence/extend?codeapps=' . package()['code_apps'];
    }
    ?>
PHP;
    $new = <<<'PHP'
                    <?php
                    $licence = verify_license();
    $licence = json_decode($licence, true);
    $exp = $licence['expired'];
    $beforeexp = date('Y-m-d', strtotime('-5 day', strtotime($exp)));
    $packageInfo = package();
    if (empty($packageInfo['code_apps'])) {
        $codeapps = $licence['server'];
    } else {
        $codeapps = $licence['server'] . 'licence/extend?codeapps=' . $packageInfo['code_apps'];
    }
    ?>
PHP;
    if (strpos($backend, '$packageInfo = package();') === false) {
        if (strpos($backend, $old) === false) {
            throw new RuntimeException("backend.php block not found for {$root}");
        }
        $backend = str_replace($old, $new, $backend);
        file_put_contents($backendPath, $backend);
    }

    echo "fixed {$root}\n";
}
