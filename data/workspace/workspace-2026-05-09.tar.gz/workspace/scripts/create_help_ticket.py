#!/usr/bin/env python3
"""
Create a Teknologi Rakyat help ticket without browser automation.

The portal endpoint accepts a normal authenticated POST to /help/addhelp.
The main gotcha is that the payload must match the HTML form names exactly.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from typing import Iterable

import requests


@dataclass
class TicketRow:
    no_ticket: str
    no_services: str
    status: str
    report: str
    description: str


class PortalError(RuntimeError):
    pass


class PortalSession:
    def __init__(self, base_url: str, email: str, password: str, verify_ssl: bool = True):
        self.base_url = base_url.rstrip("/")
        self.email = email
        self.password = password
        self.session = requests.Session()
        self.verify_ssl = verify_ssl
        self.session.headers.update(
            {
                "User-Agent": "AsepTicketHelper/1.0",
            }
        )

    def login(self) -> None:
        response = self.session.post(
            f"{self.base_url}/auth",
            data={"email": self.email, "password": self.password},
            allow_redirects=True,
            verify=self.verify_ssl,
            timeout=20,
        )
        response.raise_for_status()
        page = self.session.get(
            f"{self.base_url}/help/datahelp",
            verify=self.verify_ssl,
            timeout=20,
        )
        page.raise_for_status()
        if 'id="formAddHelp"' not in page.text:
            raise PortalError("login gagal atau akun tidak punya akses ke menu tiket")
        self._help_page = page.text

    def resolve_type_id(self, type_name: str | None, type_id: int | None) -> int:
        if type_id is not None:
            return type_id
        options = self._extract_options(self._help_page, "type")
        for value, label in options:
            if label.strip().lower() == type_name.strip().lower():
                return int(value)
        known = ", ".join(label for _, label in options)
        raise PortalError(f'topik "{type_name}" tidak ditemukan. Opsi: {known}')

    def resolve_solution_id(self, type_id: int, solution_name: str | None, solution_id: int | None) -> int:
        if solution_id is not None:
            return solution_id
        response = self.session.post(
            f"{self.base_url}/help/getsolution",
            data={"type": type_id},
            verify=self.verify_ssl,
            timeout=20,
        )
        response.raise_for_status()
        options = self._extract_options(response.text)
        for value, label in options:
            if label.strip().lower() == solution_name.strip().lower():
                return int(value)
        known = ", ".join(label for _, label in options if value_is_int(_))
        raise PortalError(f'solusi "{solution_name}" tidak ditemukan untuk topik ini. Opsi: {known}')

    def get_tickets_for_service(self, no_services: str) -> list[TicketRow]:
        now = datetime.now()
        response = self.session.post(
            f"{self.base_url}/help/serverhelp",
            data={
                "draw": 1,
                "start": 0,
                "length": 100,
                "month": "",
                "year": now.year,
                "coverage": "",
                "status": "",
                "search[value]": no_services,
                "search[regex]": "false",
            },
            verify=self.verify_ssl,
            timeout=20,
        )
        response.raise_for_status()
        payload = response.json()
        rows: list[TicketRow] = []
        for row in payload.get("data", []):
            if str(row.get("no_services", "")).strip() != no_services:
                continue
            rows.append(
                TicketRow(
                    no_ticket=str(row.get("no_ticket", "")).strip(),
                    no_services=str(row.get("no_services", "")).strip(),
                    status=strip_tags(str(row.get("status", "")).strip()),
                    report=strip_tags(str(row.get("report", "")).strip()),
                    description=str(row.get("description", "")).strip(),
                )
            )
        return rows

    def create_ticket(
        self,
        *,
        no_services: str,
        type_id: int,
        solution_id: int,
        remark: str,
        technician_ids: Iterable[int] = (),
    ) -> requests.Response:
        data: list[tuple[str, str]] = [
            ("target_type", "customer"),
            ("no_services", no_services),
            ("type", str(type_id)),
            ("solution", str(solution_id)),
            ("remark", remark),
        ]
        for tech_id in technician_ids:
            data.append(("technician[]", str(tech_id)))
        response = self.session.post(
            f"{self.base_url}/help/addhelp",
            data=data,
            headers={"Referer": f"{self.base_url}/help/datahelp"},
            allow_redirects=False,
            verify=self.verify_ssl,
            timeout=20,
        )
        response.raise_for_status()
        return response

    @staticmethod
    def _extract_options(text: str, select_id: str | None = None) -> list[tuple[str, str]]:
        source = text
        if select_id is not None:
            pattern = rf'<select[^>]+id="{re.escape(select_id)}"[^>]*>(.*?)</select>'
            match = re.search(pattern, text, flags=re.S | re.I)
            if not match:
                raise PortalError(f"select #{select_id} tidak ditemukan")
            source = match.group(1)
        options = []
        for value, label in re.findall(r"<option\s+value=['\"]([^'\"]+)['\"][^>]*>(.*?)</option>", source, flags=re.S | re.I):
            clean_label = strip_tags(html.unescape(label)).strip()
            if not clean_label or clean_label.startswith("-"):
                continue
            options.append((value.strip(), clean_label))
        return options


def strip_tags(value: str) -> str:
    return re.sub(r"<[^>]+>", " ", value).replace("&nbsp;", " ").strip()


def value_is_int(value: str) -> bool:
    try:
        int(value)
        return True
    except ValueError:
        return False


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create Tekra help ticket without browser")
    parser.add_argument("--portal", required=True, help="Portal base URL, e.g. https://portal.tekra.id")
    parser.add_argument("--email", required=True, help="Portal login email")
    parser.add_argument("--password", required=True, help="Portal login password")
    parser.add_argument("--no-services", required=True, help="Customer service ID")
    parser.add_argument("--type", dest="type_name", help='Topik gangguan, e.g. "Internet"')
    parser.add_argument("--type-id", type=int, help="Numeric help_type ID")
    parser.add_argument("--solution", dest="solution_name", help='Solusi gangguan, e.g. "Internet putus-putus"')
    parser.add_argument("--solution-id", type=int, help="Numeric help_solution ID")
    parser.add_argument("--remark", required=True, help="Ticket remark / description")
    parser.add_argument("--technician-id", action="append", type=int, default=[], help="Repeatable technician user ID")
    parser.add_argument("--check-only", action="store_true", help="Only validate login, resolve IDs, and inspect active ticket")
    parser.add_argument("--insecure", action="store_true", help="Disable TLS verification")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.type_id is None and not args.type_name:
        raise SystemExit("--type atau --type-id wajib diisi")
    if args.solution_id is None and not args.solution_name:
        raise SystemExit("--solution atau --solution-id wajib diisi")

    portal = PortalSession(
        base_url=args.portal,
        email=args.email,
        password=args.password,
        verify_ssl=not args.insecure,
    )
    portal.login()

    type_id = portal.resolve_type_id(args.type_name, args.type_id)
    solution_id = portal.resolve_solution_id(type_id, args.solution_name, args.solution_id)

    before_rows = portal.get_tickets_for_service(args.no_services)
    active_rows = [row for row in before_rows if row.status.lower() != "close"]
    result = {
        "portal": args.portal,
        "no_services": args.no_services,
        "type_id": type_id,
        "solution_id": solution_id,
        "active_tickets": [
            {
                "no_ticket": row.no_ticket,
                "status": row.status,
                "report": row.report,
                "description": row.description,
            }
            for row in active_rows
        ],
    }

    if args.check_only:
        result["ready_to_create"] = not active_rows
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if not active_rows else 2

    if active_rows:
        print(json.dumps({**result, "created": False, "reason": "active_ticket_exists"}, indent=2, ensure_ascii=False))
        return 2

    response = portal.create_ticket(
        no_services=args.no_services,
        type_id=type_id,
        solution_id=solution_id,
        remark=args.remark,
        technician_ids=args.technician_id,
    )
    if response.status_code not in (302, 303):
        raise PortalError(f"submit gagal, HTTP {response.status_code}")

    after_rows = portal.get_tickets_for_service(args.no_services)
    before_numbers = {row.no_ticket for row in before_rows}
    new_rows = [row for row in after_rows if row.no_ticket not in before_numbers]
    created_row = new_rows[0] if new_rows else None

    payload = {
        **result,
        "created": bool(created_row),
        "redirect": response.headers.get("Location", ""),
    }
    if created_row:
        payload["ticket"] = {
            "no_ticket": created_row.no_ticket,
            "status": created_row.status,
            "report": created_row.report,
            "description": created_row.description,
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    payload["reason"] = "submit_redirected_but_no_new_ticket_detected"
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 3


if __name__ == "__main__":
    try:
        sys.exit(main())
    except PortalError as exc:
        print(json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False))
        sys.exit(1)
    except requests.RequestException as exc:
        print(json.dumps({"error": f"request gagal: {exc}"}, indent=2, ensure_ascii=False))
        sys.exit(1)
