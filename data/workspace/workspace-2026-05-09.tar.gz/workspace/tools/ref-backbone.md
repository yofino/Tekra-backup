# Backbone TekraNet - Reference

## Ringkasan per POP

| POP | ISP | Kapasitas | LB Aktif | pfSense |
|---|---|---|---|---|
| DAGO | Simaya (PBR only), MyRep ×3 (250M), Sunmory (300M) | 1.150M | 1.050M | 115.178.49.186:1042 |
| PUSAT | Simaya (PBR only), MyRep ×3 (250M), Sunmory ×2 (250M), Cilisung via VLAN (600M), Indibiz (300M) | 2.250M | 2.150M | 192.168.123.1 |
| CILISUNG | MyRep (250M), MyRep (500M) → output ke Pusat WAN6 | 750M | 600M ke Pusat | — |
| KATAPANG | Primacom (PBR only), MyRep (250M) | 350M | 250M | — (langsung MikroTik) |

**Grand Total: ~4.5 Gbps beli, ~3.45 Gbps aktif LB**

## Notes Penting
- Simaya = PBR only, khusus speedtest, tidak masuk LB
- CCR2 = PPPoE, CCR1 = Hotspot (Pusat)
- Katapang: failover recursive gateway → MyRep (d=1) → Primacom (d=2)
- Risiko: gangguan MyRep nasional → semua link MyRep kena sekaligus

## pfSense Gateway Subnets

**Pusat** (192.168.123.1): WAN1=50.1, WAN2=60.1, WAN3=70.1, WAN4=80.1, WAN5=90.1, WAN6=124.1, WAN7GW=110.1

**Dago** (115.178.49.186:1042): WAN1=41.1, WAN2=42.1, WAN3=43.1, WAN4=44.1

## pfSense Dago NIC Mapping (untuk bounce)
| WAN | Interface |
|---|---|
| WAN1 | em0 |
| WAN2 | em1 |
| WAN3 | em2 |
| WAN4 | em3 |
