# Zabbix Item IDs Reference

## Host IDs
| HostID | Host |
|---|---|
| 10678 | KATAPANG |
| 10677 | CILISUNG |
| 10676 | DAGO |
| 10675 | CCR1 Pusat |
| 10674 | CCR2 Pusat |
| 10681 | pfsense Pusat |
| 10084 | Zabbix server |

## Item IDs per POP

**KATAPANG (10678)**
| ItemID | Nama | Satuan |
|---|---|---|
| 58612 | ether1-ISP1 Bits received | bps |
| 58939 | ether1-ISP1 Bits sent | bps |
| 58928 | PPPOE Bits sent (→ pelanggan) | bps |
| 58601 | PPPOE Bits received | bps |

**CILISUNG (10677)**
| ItemID | Nama | Satuan |
|---|---|---|
| 55808 | sfp-sfpplus1 Bits received (uplink ISP) | bps |
| 56297 | sfp-sfpplus1 Bits sent | bps |

**DAGO (10676)**
| ItemID | Nama | Satuan |
|---|---|---|
| 57219 | ether4-SUNMORI Bits received (uplink ISP) | bps |
| 57693 | ether4-SUNMORI Bits sent | bps |

**PUSAT CCR2/PPPoE (10674)**
| ItemID | Nama | Satuan |
|---|---|---|
| 51993 | SFP1-WAN-1 Bits received (10GbE) | bps |
| 53487 | SFP1-WAN-1 Bits sent | bps |

**PUSAT CCR1/Hotspot (10675)**
| ItemID | Nama | Satuan |
|---|---|---|
| 50558 | ether5-pfsense Bits received | bps |

## Cara Query

```bash
# Login (simpan token)
curl -s http://10.10.10.18/zabbix/api_jsonrpc.php -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"user.login","params":{"username":"Admin","password":"zabbix"},"id":1}'

# History (history=3 untuk uint64, simpan ~30 hari)
# Trend (agregasi per jam, simpan lebih lama, cocok analisis historis)
```
