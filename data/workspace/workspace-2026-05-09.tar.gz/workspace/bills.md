# Bills & Subscriptions - Yofi (Teknologi Rakyat)

## Sumber: Neng Resti (22 Maret 2026)

---

## Jatuh Tempo Tanggal 5
- Sunmory 1 Pusat
- Sunmory 2 Pusat
- Sunmory Dago
- Listrik Server Dago
- Listrik Masjid Dago
- Listrik Server Pusat
- Listrik Rumah
- Listrik Mertua
- BPJS Yofi
- BPJS Mertua
- BPJS Orangtua

## Jatuh Tempo Tanggal 10
- Myrep Septian
- Myrep Rohmiati
- Myrep Dago 1
- Telkom
- Simaya Pusat
- Simaya Dago
- Myrep Yofi
- Jamsostek

## Jatuh Tempo Tanggal 15
- Myrep Dago 2
- Myrep Dago 3

## Jatuh Tempo Tanggal 20
- Myrep Fajar
- Myrep Ayi
- Telkomsel Katapang
- Primacom Katapang

## Jatuh Tempo Tanggal 25
- Myrep Katapang

---

## Reminder Settings
- Ingetin Yofi & Neng Resti: H-2 sebelum jatuh tempo
- Jam reminder: 09:00 WIB

---

## SOP Input Keuangan (dari Neng Resti)

### Pemasukan
- Input manual semua field: nominal, tanggal transaksi, penerima/dibuat oleh, kategori, coverage, keterangan
- **Tanggal** → sesuai tanggal transaksi sebenarnya (bukan otomatis hari ini)
- **Coverage:**
  - Voucher → kosongkan coverage
  - Pembayaran tagihan → isi sesuai area yang dilaporkan teknisi
- **Sebelum input** → cek dulu di sistem biar tidak double
- **Setelah input** → cek lagi pastikan sudah masuk
- **Kalau salah** → klik ikon biru (edit) → ubah yang salah, jangan hapus-input ulang
