# KNOWLEDGE.md

## OpenClaw Gateway Lokal

- Config aktif gateway di host ini ada di `/root/.openclaw/openclaw.json`, bukan `/home/node/.openclaw/openclaw.json`.
- Untuk cek atau ubah config gateway host ini via CLI, pakai `HOME=/root openclaw ...` supaya tidak nyasar ke profile Codex yang lain.
- `channels.whatsapp.dmPolicy` bernilai `allowlist` tetap membatasi DM seperti mode pairing/whitelist. Kalau mau semua nomor bisa chat, ubah ke `open`.
- Gateway di host ini berjalan sebagai proses langsung `node /usr/bin/openclaw gateway` pada port `18789`, bukan container Docker.
- `openclaw gateway status` bisa bilang service `stopped` walau gateway sebenarnya hidup kalau prosesnya dijalankan manual. Verifikasi juga dengan `ps` atau cek port `18789`.
- Restart manual gateway aktif bisa ikut mematikan session agent yang sedang berjalan, karena proses agent saat ini diturunkan dari gateway itu. Kalau perlu restart, lebih aman pakai shell lain atau restart detached.

## Portal Tiket Gangguan

- Portal pusat tidak wajib browser untuk bikin tiket. Endpoint `https://portal.tekra.id/help/addhelp` menerima POST biasa selama session login valid.
- Field minimum untuk tiket pelanggan:
  - `target_type=customer`
  - `no_services`
  - `type`
  - `solution`
  - `remark`
- Nama field harus persis seperti form portal. `description` tidak dipakai; controller membaca `remark`.
- Jalur resolve dependensi via HTTP:
  - login: `POST /auth`
  - halaman form: `GET /help/datahelp`
  - solusi per topik: `POST /help/getsolution`
  - teknisi per customer/coverage: `POST /help/gettechnician`
  - verifikasi daftar tiket: `POST /help/serverhelp`
- Helper lokal yang sudah jadi: `/root/.openclaw/workspace/scripts/create_help_ticket.py`
- `scripts/create_help_ticket.py --check-only` bisa dipakai untuk preflight tanpa bikin tiket: validasi login, resolve `type/solution`, dan cek apakah customer masih punya tiket aktif.
