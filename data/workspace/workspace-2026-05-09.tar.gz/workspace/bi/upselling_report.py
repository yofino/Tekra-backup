#!/usr/bin/env python3
"""
Upselling Intelligence Report - Teknologi Rakyat
Identifikasi kandidat upgrade paket & potensi pelanggan baru per POP
"""

import requests
import subprocess
import json
import re
import warnings
from datetime import datetime
warnings.filterwarnings("ignore")

PORTALS = [
    {"name": "Pusat",    "url": "https://portal.tekra.id"},
    {"name": "Dago",     "url": "https://north.my.id"},
    {"name": "Katapang", "url": "https://southnet.my.id"},
]
ACS_URL = "http://10.10.10.230:7557"
ACS_AUTH = ("admin", "admin")

SSH_PORT = 18
SSH_USER = "asep"
SSH_PASS = "asep$888"

# Mapping paket harga → speed (Mbps) — update sesuai kondisi
PAKET_SPEED = {
    "PAKET1": 10, "PAKET 1": 10, "PAKET-1": 10, "PAKET HEMAT": 10,
    "PAKET2": 16, "PAKET 2": 16, "PAKET-2": 16,
    "PAKET3": 20, "PAKET 3": 20, "PAKET-3": 20, "PAKET MANTAP": 20,
    "PAKET4": 25, "PAKET 4": 25, "PAKET-4": 25,
    "PAKET5": 30, "PAKET 5": 30, "PAKET-5": 30, "PAKET PUAS": 30,
}

# Threshold: banyak device → butuh upgrade
DEVICE_THRESHOLD = 5  # >= 5 device aktif = kandidat upgrade
SLOW_COMPLAINT_KEYWORDS = ["lambat", "lemot", "slow", "lelet", "buffering", "lag", "putus"]

portal_sessions = {}

def login_portals():
    for p in PORTALS:
        s = requests.Session()
        try:
            s.post(f"{p['url']}/auth", data={
                "email": "asep@tekra.id",
                "password": "12345"
            }, allow_redirects=True, verify=False, timeout=10)
        except:
            pass
        portal_sessions[p["name"]] = {"session": s, "url": p["url"]}

def get_acs_devices(projection="DeviceID,VirtualParameters"):
    try:
        r = requests.get(
            f"{ACS_URL}/devices",
            params={"limit": 2000, "projection": projection},
            auth=ACS_AUTH, timeout=15
        )
        return r.json()
    except:
        return []

def ssh_command(ip, cmd, timeout=10):
    try:
        result = subprocess.run(
            ["sshpass", f"-p{SSH_PASS}",
             "ssh", "-p", str(SSH_PORT),
             "-o", "StrictHostKeyChecking=no",
             "-o", f"ConnectTimeout={timeout}",
             f"{SSH_USER}@{ip}", cmd],
            capture_output=True, text=True, timeout=timeout + 2
        )
        return result.stdout.strip()
    except:
        return ""

def get_pppoe_profiles(ip):
    """Ambil mapping username → profile dari MikroTik"""
    out = ssh_command(ip, "/ppp secret print")
    mapping = {}
    current_name = None
    for line in out.splitlines():
        line = line.strip()
        m_name = re.search(r'name="([^"]+)"', line)
        m_prof = re.search(r'profile="([^"]+)"', line)
        if m_name:
            current_name = m_name.group(1)
        if m_prof and current_name:
            mapping[current_name] = m_prof.group(1)
            current_name = None
    return mapping

def get_slow_complainers():
    """Pelanggan yang tiket-nya berkaitan dengan keluhan lambat — semua portal"""
    complainers = []  # list of dict {id, name, portal}
    for portal_name, pd in portal_sessions.items():
        s = pd["session"]
        url = pd["url"]
        try:
            for status in ["pending", "process"]:
                r = s.post(f"{url}/help/serverhelp", data={
                    "status": status,
                    "month": f"{datetime.now().month:02d}",
                    "year": datetime.now().year,
                    "coverage": "", "draw": 1, "start": 0, "length": 500
                }, verify=False, timeout=10)
                tickets = r.json().get("data", [])
                for row in tickets:
                    if not isinstance(row, list):
                        continue
                    desc = " ".join(str(x) for x in row).lower()
                    if any(kw in desc for kw in SLOW_COMPLAINT_KEYWORDS):
                        for cell in row[1:5]:
                            cell_str = str(cell)
                            if re.match(r'^\d{14,}', cell_str):
                                complainers.append({"id": cell_str[:20], "portal": portal_name})
                                break
        except:
            pass
    return complainers

def get_olt_capacity():
    """Cek kapasitas ONU di OLT GPON"""
    # Ini butuh akses OLT, gunakan estimasi dari GenieACS
    try:
        r = requests.get(
            f"{ACS_URL}/devices",
            params={"limit": 1, "projection": "DeviceID"},
            auth=ACS_AUTH, timeout=5
        )
        total = len(r.json()) if r.ok else 0
        return total
    except:
        return 0

def run():
    login_portals()
    now = datetime.now()

    lines = [
        f"📈 *UPSELLING INTELLIGENCE*",
        f"_{now.strftime('%d %B %Y, %H:%M')} WIB_",
        "",
    ]

    # === 1. Kandidat Upgrade dari GenieACS (banyak device) ===
    lines.append("🔍 *Kandidat Upgrade Paket (Banyak Device)*")

    devices = get_acs_devices(
        "DeviceID,VirtualParameters.pppoeUsername,VirtualParameters.activedevices,VirtualParameters.getSerialNumber"
    )

    upgrade_candidates = []
    for dev in devices:
        vp = dev.get("VirtualParameters", {})
        username_obj = vp.get("pppoeUsername", {})
        activedev_obj = vp.get("activedevices", {})
        sn_obj = vp.get("getSerialNumber", {})

        username = str(username_obj.get("_value", "")).strip()
        active_dev = str(activedev_obj.get("_value", "0")).strip()
        sn = str(sn_obj.get("_value", "")).strip()

        try:
            active_dev_count = int(active_dev)
        except:
            continue

        if active_dev_count >= DEVICE_THRESHOLD and username:
            upgrade_candidates.append({
                "username": username,
                "devices": active_dev_count,
                "sn": sn
            })

    # Sort by most devices
    upgrade_candidates.sort(key=lambda x: -x["devices"])

    if upgrade_candidates:
        lines.append(f"  Ditemukan *{len(upgrade_candidates)} pelanggan* dengan ≥{DEVICE_THRESHOLD} device aktif:")
        for c in upgrade_candidates[:10]:
            # Ambil nama dari username (format: NOMORID-NAMA)
            nama = c["username"].split("-", 1)[1] if "-" in c["username"] else c["username"]
            lines.append(f"  📱 {nama}: {c['devices']} device aktif")
        if len(upgrade_candidates) > 10:
            lines.append(f"  _...dan {len(upgrade_candidates)-10} lainnya_")
    else:
        lines.append("  _Tidak ada data device aktif dari ACS_")

    lines.append("")

    # === 2. Kandidat Upgrade dari Keluhan Lambat ===
    lines.append("🐌 *Kandidat Upgrade (Sering Komplain Lambat)*")
    slow_complainers = get_slow_complainers()
    if slow_complainers:
        lines.append(f"  *{len(slow_complainers)} pelanggan* komplain lambat bulan ini:")
        for sc in slow_complainers[:8]:
            lines.append(f"  - [{sc['portal']}] ID: {sc['id']}")
        if len(slow_complainers) > 8:
            lines.append(f"  _...dan {len(slow_complainers)-8} lainnya_")
    else:
        lines.append("  ✅ Tidak ada komplain lambat aktif")

    lines.append("")

    # === 3. Distribusi paket per POP (dari MikroTik) ===
    lines.append("📊 *Distribusi Paket per POP*")

    ROUTERS = [
        {"name": "Pusat",    "ip": "172.80.10.100"},
        {"name": "Cilisung", "ip": "10.6.0.5"},
        {"name": "Katapang", "ip": "10.6.0.4"},
        {"name": "Dago",     "ip": "10.6.0.2"},
    ]

    total_low = 0
    total_all = 0

    for router in ROUTERS:
        # Hitung secret per profile (proxy untuk distribusi paket)
        out = ssh_command(router["ip"], "/ppp secret print count-only")
        total = 0
        try:
            total = int(out.strip())
        except:
            pass

        # Hitung yang masih di paket rendah (profile PAKET1/HEMAT)
        low_out = ssh_command(router["ip"], '/ppp secret print count-only where profile="PAKET1" or profile="PAKET HEMAT" or profile="PAKET 1"')
        low = 0
        try:
            low = int(low_out.strip())
        except:
            pass

        total_all += total
        total_low += low

        pct_low = (low / total * 100) if total > 0 else 0
        upsell_potential = low  # pelanggan paket terendah = potensi upsell

        lines.append(f"  🔵 *{router['name']}*: {total} pelanggan | Paket 10M: {low} ({pct_low:.0f}%) → potensi upsell")

    lines.append("")

    # === 4. Estimasi Revenue Upselling ===
    lines.append("💰 *Estimasi Potensi Revenue Upselling*")
    # Kalau 20% dari pelanggan paket 10M upgrade ke 20M (tambah Rp35rb/bulan)
    upgrade_potential = int(total_low * 0.20)
    revenue_potential = upgrade_potential * 35000
    lines.append(f"  Jika *20%* dari {total_low} pelanggan paket 10M upgrade ke 20M:")
    lines.append(f"  → ~{upgrade_potential} pelanggan × Rp35.000 = *Rp{revenue_potential:,.0f}/bulan*".replace(",", "."))

    lines.append("")

    # === 5. Total ONT terdaftar di ACS ===
    total_onts = len(devices)
    lines.append(f"📡 *Total ONT terdaftar di ACS:* {total_onts} unit")
    lines.append(f"👥 *Total pelanggan aktif (semua POP):* {total_all}")
    lines.append("")
    lines.append("💡 _Fokus upselling: pelanggan banyak device + sering komplain lambat_")

    return "\n".join(lines)

if __name__ == "__main__":
    print(run())
