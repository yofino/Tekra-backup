#!/usr/bin/env python3
"""Network/Bandwidth Intelligence Report - Teknologi Rakyat"""

import subprocess
import requests
import re
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")

ROUTERS = [
    {"name": "Pusat X86",   "ip": "172.80.10.100"},
    {"name": "Cilisung GX4","ip": "10.6.0.5"},
    {"name": "Katapang",    "ip": "10.6.0.4"},
    {"name": "Dago",        "ip": "10.6.0.2"},
]

# pfSense configs untuk cek WAN gateway per POP
PFSENSE = [
    {"name": "Pusat",  "url": "https://192.168.123.1",       "wans": ["WAN1","WAN2","WAN3","WAN4","WAN5","WAN6","WAN7GW"]},
    {"name": "Dago",   "url": "https://115.178.49.186:1042", "wans": ["WAN1","WAN2","WAN3","WAN4"], "port": 1042},
]
SSH_PORT = 18
SSH_USER = "asep"
SSH_PASS = "asep$888"

def ssh_command(ip, cmd, timeout=10):
    try:
        result = subprocess.run(
            ["sshpass", f"-p{SSH_PASS}",
             "ssh", "-p", str(SSH_PORT),
             "-o", "StrictHostKeyChecking=no",
             "-o", f"ConnectTimeout={timeout}",
             f"{SSH_USER}@{ip}", cmd],
            capture_output=True, text=True, timeout=timeout + 2
        )
        return result.stdout.strip()
    except Exception as e:
        return f"ERROR: {e}"

def parse_bytes(val):
    """Parse MikroTik bytes value (bisa ada suffix K/M/G)"""
    val = str(val).strip().upper()
    try:
        if val.endswith("GIB") or val.endswith("G"):
            return float(val.rstrip("GIB").rstrip("G")) * 1024**3
        elif val.endswith("MIB") or val.endswith("M"):
            return float(val.rstrip("MIB").rstrip("M")) * 1024**2
        elif val.endswith("KIB") or val.endswith("K"):
            return float(val.rstrip("KIB").rstrip("K")) * 1024
        else:
            return float(val)
    except:
        return 0

def format_bytes(b):
    if b >= 1024**3:
        return f"{b/1024**3:.1f} GB"
    elif b >= 1024**2:
        return f"{b/1024**2:.1f} MB"
    elif b >= 1024:
        return f"{b/1024:.1f} KB"
    return f"{b:.0f} B"

def get_active_pppoe(ip):
    out = ssh_command(ip, "/ppp active print count-only")
    try:
        return int(out.strip())
    except:
        return -1

def get_queue_stats(ip):
    out = ssh_command(ip, "/queue simple print stats")
    queues = []
    current = {}
    for line in out.splitlines():
        line = line.strip()
        if "name=" in line:
            if current:
                queues.append(current)
            current = {"name": ""}
            import re
            m = re.search(r'name="([^"]+)"', line)
            if m:
                current["name"] = m.group(1)
        elif "bytes=" in line:
            import re
            m = re.search(r'bytes=(\S+)/(\S+)', line)
            if m:
                current["tx"] = parse_bytes(m.group(1))
                current["rx"] = parse_bytes(m.group(2))
        elif "rate=" in line:
            import re
            m = re.search(r'rate=(\S+)/(\S+)', line)
            if m:
                current["tx_rate"] = parse_bytes(m.group(1))
                current["rx_rate"] = parse_bytes(m.group(2))
    if current:
        queues.append(current)
    return queues

def get_interface_traffic(ip, interfaces=["ether1-ISP1", "ether2-PRIMACOM", "ether1", "ether2"]):
    """Ambil TX/RX rate dari interface utama"""
    results = []
    for iface in interfaces[:2]:  # Cek 2 interface ISP
        out = ssh_command(ip, f'/interface monitor-traffic {iface} once', timeout=8)
        if "ERROR" not in out and "rx-bits-per-second" in out.lower():
            import re
            rx = re.search(r'rx-bits-per-second:\s*(\S+)', out, re.IGNORECASE)
            tx = re.search(r'tx-bits-per-second:\s*(\S+)', out, re.IGNORECASE)
            if rx or tx:
                results.append({
                    "iface": iface,
                    "rx_bps": parse_bytes(rx.group(1).replace("bps","")) if rx else 0,
                    "tx_bps": parse_bytes(tx.group(1).replace("bps","")) if tx else 0,
                })
    return results

pfsense_sessions = {}

def login_pfsense(url, user="admin", password="k34Nu335577"):
    s = requests.Session()
    try:
        r = s.get(url + "/", verify=False, timeout=8)
        import re
        csrf = re.search(r'csrfMagicToken = "([^"]+)"', r.text)
        token = csrf.group(1) if csrf else ""
        s.post(url + "/index.php", data={
            "__csrf_magic": token,
            "usernamefld": user,
            "passwordfld": password,
            "login": "Sign In"
        }, verify=False, timeout=8, allow_redirects=False)
        return s
    except:
        return None

def get_pfsense_gateways(url, session):
    try:
        r = session.get(url + "/widgets/widgets/gateways.widget.php", verify=False, timeout=8)
        gateways = []
        rows = re.findall(r'WAN\w*.*?<td class="bg-(\w+)">(\w+)</td>', r.text, re.DOTALL)
        # Parse lebih detail
        wan_blocks = re.findall(
            r'(WAN\w*).*?<td>(\d+\.\d+ms)</td>.*?<td>(\d+\.\d+ms)</td>.*?<td>(\d+\.?\d*%)</td>.*?bg-(\w+)">([^<]+)</td>',
            r.text, re.DOTALL
        )
        for name, rtt, rttsd, loss, status_class, status in wan_blocks:
            gateways.append({
                "name": name.strip(),
                "rtt": rtt.strip(),
                "loss": loss.strip(),
                "online": "success" in status_class
            })
        return gateways
    except:
        return []

def run():
    now = datetime.now()
    lines = [
        f"📡 *NETWORK INTELLIGENCE*",
        f"_{now.strftime('%d %B %Y, %H:%M')} WIB_",
        "",
    ]

    # === pfSense WAN Status ===
    for pf in PFSENSE:
        pf_name = pf["name"]
        pf_url = pf["url"]
        lines.append(f"🌐 *pfSense {pf_name}*")
        s = login_pfsense(pf_url)
        if s:
            gws = get_pfsense_gateways(pf_url, s)
            if gws:
                online = [g for g in gws if g["online"]]
                offline = [g for g in gws if not g["online"]]
                lines.append(f"  ✅ Online: {len(online)}/{len(gws)} WAN")
                for g in offline:
                    lines.append(f"  🔴 {g['name']} OFFLINE!")
                for g in online:
                    loss_warn = " ⚠️" if float(g['loss'].replace('%','')) > 5 else ""
                    lines.append(f"  🟢 {g['name']}: {g['rtt']} | loss {g['loss']}{loss_warn}")
            else:
                lines.append("  ⚠️ Tidak bisa parse gateway data")
        else:
            lines.append("  ⚠️ Tidak bisa login pfSense")
        lines.append("")

    # === MikroTik per POP ===
    for router in ROUTERS:
        name = router["name"]
        ip = router["ip"]
        lines.append(f"🔵 *{name}* (`{ip}`)")

        # Active PPPoE
        active = get_active_pppoe(ip)
        if active >= 0:
            lines.append(f"  👥 Active PPPoE: {active} sesi")
        else:
            lines.append(f"  ⚠️ Tidak bisa cek PPPoE (timeout/error)")

        # Queue stats - cari parent queue PAKET-x
        queues = get_queue_stats(ip)
        parent_queues = [q for q in queues if q.get("name","").startswith("PAKET")]
        if parent_queues:
            for q in parent_queues[:5]:
                tx = q.get("tx", 0)
                rx = q.get("rx", 0)
                total = format_bytes(tx + rx)
                lines.append(f"  📦 {q['name']}: {total} total")
        elif queues:
            # Tampilkan ringkasan total semua queue
            total_tx = sum(q.get("tx", 0) for q in queues)
            total_rx = sum(q.get("rx", 0) for q in queues)
            lines.append(f"  📦 Total traffic: ↑{format_bytes(total_tx)} ↓{format_bytes(total_rx)}")

        lines.append("")

    lines.append("💡 _Data diambil real-time dari MikroTik via SSH_")
    return "\n".join(lines)

if __name__ == "__main__":
    print(run())
