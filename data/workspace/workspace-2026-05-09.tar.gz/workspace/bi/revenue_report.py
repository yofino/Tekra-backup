#!/usr/bin/env python3
"""Revenue Intelligence Report - Teknologi Rakyat (semua portal)
Includes: Revenue, Pengeluaran, Margin per portal
"""

import requests
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings("ignore")

PORTALS = [
    {"name": "Pusat",    "url": "https://portal.tekra.id"},
    {"name": "Dago",     "url": "https://north.my.id"},
    {"name": "Katapang", "url": "https://southnet.my.id"},
]
EMAIL = "asep@tekra.id"
PASSWORD = "12345"

def make_session(base_url):
    s = requests.Session()
    try:
        s.post(f"{base_url}/auth", data={
            "email": EMAIL,
            "password": PASSWORD
        }, allow_redirects=True, verify=False, timeout=10)
    except Exception:
        pass
    return s

def parse_nominal(val):
    try:
        return int(str(val).replace(".", "").replace(",", "").strip())
    except:
        return 0

def get_income(session, base_url, month, year):
    try:
        r = session.post(f"{base_url}/income/getDataIncome", data={
            "draw": 1, "start": 0, "length": 2000,
            "month": f"{month:02d}", "year": year,
            "coverage": "", "category": ""
        }, verify=False, timeout=10)
        return r.json().get("data", [])
    except:
        return []

def get_saldo_kas(session, base_url):
    """Ambil saldo kas berjalan (akumulasi all-time income - expenditure)"""
    try:
        r = session.post(f"{base_url}/finance/get_debit_kredit_data", data={
            "filter_type": "all",
            "saldo_mode": "global"
        }, verify=False, timeout=10)
        import re
        tfoot = r.json().get("tfoot", "")
        nums = re.findall(r'style="text-align:right[^"]*">([0-9.,]+)<', tfoot)
        # nums: [total_income, total_exp, saldo]
        if len(nums) >= 3:
            return parse_nominal(nums[2])
        elif len(nums) == 1:
            return parse_nominal(nums[0])
    except:
        pass
    return None

def get_expenditure_month(session, base_url, ym_prefix):
    """Fetch all expenditures for a given YYYY-MM prefix by paginating."""
    all_items = []
    start = 0
    while True:
        try:
            r = session.post(f"{base_url}/expenditure/getDataFilter", data={
                "draw": 1, "start": start, "length": 500,
                "coverage": "", "category": ""
            }, verify=False, timeout=10)
            batch = r.json().get("data", [])
        except:
            break
        if not batch:
            break
        all_items.extend(batch)
        start += 500
        # Stop paginating if oldest entry in batch is before target month
        oldest = min(i["date_payment"] for i in batch)
        if oldest < ym_prefix + "-01":
            break

    return sum(
        parse_nominal(i["nominal"])
        for i in all_items
        if i["date_payment"].startswith(ym_prefix)
    )

def get_customers_by_status(session, base_url, status):
    try:
        r = session.post(f"{base_url}/customer/getdatacustomercoverage", data={
            "draw": 1, "start": 0, "length": 2000,
            "status": status, "coverage": "", "router": "", "mediaconnection": ""
        }, verify=False, timeout=10)
        return r.json().get("data", [])
    except:
        return []

def run():
    now = datetime.now()
    prev_month = (now.replace(day=1) - timedelta(days=1))
    cur_ym = now.strftime("%Y-%m")
    prv_ym = prev_month.strftime("%Y-%m")

    lines = [
        f"📊 *REVENUE INTELLIGENCE*",
        f"_{now.strftime('%d %B %Y, %H:%M')} WIB_",
        "",
    ]

    totals = []

    for portal in PORTALS:
        name = portal["name"]
        url = portal["url"]
        session = make_session(url)

        # Income
        cur_income_data = get_income(session, url, now.month, now.year)
        prv_income_data = get_income(session, url, prev_month.month, prev_month.year)

        inc_cur = sum(parse_nominal(r[3]) for r in cur_income_data if isinstance(r, list) and len(r) > 3)
        inc_prv = sum(parse_nominal(r[3]) for r in prv_income_data if isinstance(r, list) and len(r) > 3)

        # Expenditure
        exp_cur = get_expenditure_month(session, url, cur_ym)
        exp_prv = get_expenditure_month(session, url, prv_ym)

        # Saldo Kas
        saldo_kas = get_saldo_kas(session, url)

        # Margin
        mar_cur = inc_cur - exp_cur
        mar_prv = inc_prv - exp_prv
        mar_pct = (mar_cur / inc_cur * 100) if inc_cur > 0 else 0

        inc_diff = inc_cur - inc_prv
        inc_pct = (inc_diff / inc_prv * 100) if inc_prv > 0 else 0
        inc_trend = "📈" if inc_diff >= 0 else "📉"

        totals.append({
            "name": name,
            "inc_cur": inc_cur, "inc_prv": inc_prv,
            "exp_cur": exp_cur, "exp_prv": exp_prv,
            "mar_cur": mar_cur, "mar_prv": mar_prv,
            "saldo_kas": saldo_kas,
        })

        # Pelanggan
        pasang = [r for r in cur_income_data if isinstance(r, list) and len(r) > 4 and "Pemasangan" in str(r[4])]
        isolir = get_customers_by_status(session, url, "Isolir")

        kas_str = f"Rp{saldo_kas:,.0f}".replace(",", ".") if saldo_kas is not None else "N/A"
        plines = [
            f"🏢 *{name}*",
            f"  💰 Revenue: *Rp{inc_cur:,.0f}*".replace(",", "."),
            f"  💸 Pengeluaran: Rp{exp_cur:,.0f}".replace(",", "."),
            f"  📊 Margin: *Rp{mar_cur:,.0f}* ({mar_pct:.1f}%)".replace(",", "."),
            f"  🏦 Saldo Kas: *{kas_str}*",
            f"  {inc_trend} vs bln lalu: Rp{abs(inc_diff):,.0f} ({inc_pct:+.1f}%)".replace(",", "."),
            f"  🆕 Pelanggan baru: {len(pasang)} orang",
            f"  🔴 Isolir: {len(isolir)} pelanggan",
        ]
        lines.append("\n".join(plines))
        lines.append("")

    # Grand total
    grand_inc_cur = sum(t["inc_cur"] for t in totals)
    grand_inc_prv = sum(t["inc_prv"] for t in totals)
    grand_exp_cur = sum(t["exp_cur"] for t in totals)
    grand_mar_cur = grand_inc_cur - grand_exp_cur
    grand_mar_pct = (grand_mar_cur / grand_inc_cur * 100) if grand_inc_cur > 0 else 0
    grand_diff = grand_inc_cur - grand_inc_prv
    grand_pct = (grand_diff / grand_inc_prv * 100) if grand_inc_prv > 0 else 0
    grand_trend = "📈" if grand_diff >= 0 else "📉"
    grand_kas = sum(t["saldo_kas"] for t in totals if t["saldo_kas"] is not None)

    lines.append("─" * 30)
    lines.append(f"💵 *GRAND TOTAL {now.strftime('%B %Y').upper()}*")
    lines.append(f"  💰 Revenue:      *Rp{grand_inc_cur:,.0f}*".replace(",", "."))
    lines.append(f"  💸 Pengeluaran:  Rp{grand_exp_cur:,.0f}".replace(",", "."))
    lines.append(f"  📊 Margin:       *Rp{grand_mar_cur:,.0f}* ({grand_mar_pct:.1f}%)".replace(",", "."))
    lines.append(f"  🏦 Total Saldo Kas: *Rp{grand_kas:,.0f}*".replace(",", "."))
    lines.append(f"  {grand_trend} vs bln lalu: Rp{abs(grand_diff):,.0f} ({grand_pct:+.1f}%)")
    lines.append(f"💡 _Data dari 3 portal: Pusat, Dago, Katapang_")

    return "\n".join(lines)

if __name__ == "__main__":
    print(run())
