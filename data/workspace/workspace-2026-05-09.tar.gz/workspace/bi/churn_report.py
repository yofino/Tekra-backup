#!/usr/bin/env python3
"""Churn Prevention Report - Teknologi Rakyat"""

import requests
from datetime import datetime, timedelta
import re

PORTAL = "https://portal.tekra.id"

session = requests.Session()

def login():
    session.post(f"{PORTAL}/auth", data={
        "email": "asep@tekra.id",
        "password": "12345"
    }, allow_redirects=True, verify=False)

def get_customers_by_status(status, coverage=""):
    r = session.post(f"{PORTAL}/customer/getdatacustomercoverage", data={
        "draw": 1, "start": 0, "length": 2000,
        "status": status, "coverage": coverage,
        "router": "", "mediaconnection": ""
    }, verify=False)
    try:
        return r.json().get("data", [])
    except:
        return []

def get_tickets(status="close", month=None, year=None):
    now = datetime.now()
    r = session.post(f"{PORTAL}/help/serverhelp", data={
        "status": status,
        "month": f"{(month or now.month):02d}",
        "year": year or now.year,
        "coverage": "",
        "draw": 1, "start": 0, "length": 500
    }, verify=False)
    try:
        return r.json().get("data", [])
    except:
        return []

COVERAGE_MAP = {
    "1": "BOJONG SEUREUH", "2": "BOJONG SUREN", "3": "SEKEANDUR",
    "4": "CISUMINTA", "5": "BOJONG SUREN GIRANG", "7": "CIGURIANG",
    "8": "LEUWI MELANG", "9": "MOCH TOHA", "10": "SUKALUYU",
    "14": "CILISUNG", "16": "SEKEAWI", "17": "CIBURUY",
    "22": "BOJONG CILEBAK", "23": "CITAMIANG", "24": "CITEPUS"
}

def run():
    login()
    now = datetime.now()

    # === Non-Aktif (churn) ===
    nonaktif = get_customers_by_status("Non-Aktif")
    total_churn = len(nonaktif)

    # Churn per coverage area
    churn_by_area = {}
    for row in nonaktif:
        if isinstance(row, list) and len(row) > 0:
            # Coba ambil coverage dari data
            raw = " ".join(str(x) for x in row)
            for cid, cname in COVERAGE_MAP.items():
                if cname in raw.upper() or f'"{cid}"' in raw:
                    churn_by_area[cname] = churn_by_area.get(cname, 0) + 1
                    break

    top_churn_area = sorted(churn_by_area.items(), key=lambda x: -x[1])[:3]

    # === Pelanggan at-risk: banyak komplain ===
    # Cek tiket bulan ini + bulan lalu
    tickets_cur = get_tickets(status="pending", month=now.month, year=now.year)
    tickets_close = get_tickets(status="close", month=now.month, year=now.year)
    all_tickets = tickets_cur + tickets_close

    # Hitung tiket per pelanggan
    ticket_counter = {}
    for row in all_tickets:
        if isinstance(row, list) and len(row) > 2:
            no_services = str(row[2]) if len(row) > 2 else ""
            nama = str(row[1]) if len(row) > 1 else ""
            key = f"{no_services}|{nama}"
            if no_services and no_services != "None":
                ticket_counter[key] = ticket_counter.get(key, 0) + 1

    at_risk = [(k, v) for k, v in ticket_counter.items() if v >= 2]
    at_risk.sort(key=lambda x: -x[1])

    # === Isolir (hampir churn) ===
    isolir = get_customers_by_status("Isolir")
    isolir_count = len(isolir)

    # === Format report ===
    lines = [
        f"🔴 *CHURN PREVENTION*",
        f"_{now.strftime('%d %B %Y, %H:%M')} WIB_",
        "",
        f"📉 *Total Non-Aktif:* {total_churn} pelanggan",
        f"⚠️ *Isolir (risiko churn):* {isolir_count} pelanggan",
        "",
    ]

    if top_churn_area:
        lines.append("🗺️ *Area paling banyak churn:*")
        for area, count in top_churn_area:
            lines.append(f"  - {area}: {count} pelanggan")
        lines.append("")

    if at_risk:
        lines.append(f"🚨 *Pelanggan at-risk ({len(at_risk)} total, ≥2 tiket bulan ini):*")
        for key, count in at_risk[:5]:
            no_services, nama = key.split("|", 1)
            lines.append(f"  - {nama} ({no_services}): {count} tiket")
    else:
        lines.append("✅ *Tidak ada pelanggan at-risk saat ini*")

    lines.append("")
    lines.append(f"💡 _Pelanggan isolir perlu follow-up sebelum churn_")

    return "\n".join(lines)

if __name__ == "__main__":
    print(run())
