#!/usr/bin/env python3
"""
BI Report - Teknologi Rakyat
Usage: python3 bi_report.py [revenue|churn|network|all]
Output: print ke terminal (bisa di-pipe ke WhatsApp atau disimpan)
"""

import sys
import requests
import warnings
warnings.filterwarnings("ignore")

def separator():
    return "\n" + "─" * 35 + "\n"

def run_all():
    parts = []

    print("📊 Mengambil data revenue...", file=sys.stderr)
    try:
        from revenue_report import run as revenue_run
        parts.append(revenue_run())
    except Exception as e:
        parts.append(f"📊 *REVENUE*\n⚠️ Gagal: {e}")

    print("🔴 Mengambil data churn...", file=sys.stderr)
    try:
        from churn_report import run as churn_run
        parts.append(churn_run())
    except Exception as e:
        parts.append(f"🔴 *CHURN*\n⚠️ Gagal: {e}")

    print("📡 Mengambil data network...", file=sys.stderr)
    try:
        from bandwidth_report import run as bw_run
        parts.append(bw_run())
    except Exception as e:
        parts.append(f"📡 *NETWORK*\n⚠️ Gagal: {e}")

    print("📈 Mengambil data upselling...", file=sys.stderr)
    try:
        from upselling_report import run as upsell_run
        parts.append(upsell_run())
    except Exception as e:
        parts.append(f"📈 *UPSELLING*\n⚠️ Gagal: {e}")

    print("🎫 Mengambil data tiket...", file=sys.stderr)
    try:
        from ticket_report import run as ticket_run
        parts.append(ticket_run())
    except Exception as e:
        parts.append(f"🎫 *TICKET*\n⚠️ Gagal: {e}")

    return separator().join(parts)

def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"

    if mode == "revenue":
        from revenue_report import run
        print(run())
    elif mode == "churn":
        from churn_report import run
        print(run())
    elif mode == "network":
        from bandwidth_report import run
        print(run())
    elif mode == "upselling":
        from upselling_report import run
        print(run())
    elif mode == "ticket":
        from ticket_report import run
        print(run())
    else:
        print(run_all())

if __name__ == "__main__":
    main()
