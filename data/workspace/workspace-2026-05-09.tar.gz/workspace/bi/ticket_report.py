#!/usr/bin/env python3
"""
Ticket Intelligence Report - Teknologi Rakyat
Laporan tiket: status, jumlah, dan lama pending
"""

import requests
import warnings
from datetime import datetime
import re
warnings.filterwarnings("ignore")

PORTAL = "https://portal.tekra.id"
session = requests.Session()

def login():
    session.post(f"{PORTAL}/auth", data={
        "email": "asep@tekra.id",
        "password": "12345"
    }, allow_redirects=True, verify=False, timeout=10)

def get_tickets(status, month=None, year=None):
    now = datetime.now()
    r = session.post(f"{PORTAL}/help/serverhelp", data={
        "status": status,
        "month": f"{(month or now.month):02d}",
        "year": year or now.year,
        "coverage": "", "draw": 1, "start": 0, "length": 500
    }, verify=False, timeout=10)
    try:
        return r.json().get("data", [])
    except:
        return []

def parse_date(s):
    for fmt in ["%d %b %Y %H:%M:%S", "%d %B %Y %H:%M:%S", "%Y-%m-%d %H:%M:%S"]:
        try:
            return datetime.strptime(str(s).strip(), fmt)
        except:
            continue
    return None

def run():
    login()
    now = datetime.now()

    closed  = get_tickets("close")
    pending = get_tickets("pending")
    process = get_tickets("process")

    total_closed  = len(closed)
    total_pending = len(pending)
    total_process = len(process)
    total_all     = total_closed + total_pending + total_process

    lines = [
        f"🎫 *TICKET INTELLIGENCE*",
        f"_{now.strftime('%d %B %Y, %H:%M')} WIB_",
        "",
        f"📊 *Ringkasan Tiket Bulan Ini:*",
        f"  ✅ Selesai (Close): *{total_closed}* tiket",
        f"  🔄 Proses: *{total_process}* tiket",
        f"  ⏳ Pending: *{total_pending}* tiket",
        f"  📋 Total: *{total_all}* tiket",
        "",
    ]

    # === Tiket aktif: sudah berapa lama? ===
    active = pending + process
    if active:
        lines.append("⚠️ *Tiket Aktif (belum selesai):*")
        ages = []
        for row in active:
            if not isinstance(row, dict):
                continue
            no     = row.get("no_ticket", "-")
            name   = row.get("name", "-")[:20]
            status = row.get("status", "-")
            desc   = re.sub(r'<[^>]+>', '', row.get("report", ""))[:35]
            created_dt = parse_date(row.get("date_created", ""))

            if created_dt:
                elapsed = now - created_dt
                total_m = int(elapsed.total_seconds() / 60)
                h, m = divmod(total_m, 60)
                age_str = f"{h}j {m}m" if h > 0 else f"{m} menit"
                ages.append(total_m)
            else:
                age_str = "?"

            emoji = "⏳" if status == "Pending" else "🔄"
            lines.append(f"  {emoji} [{no}] {name}")
            lines.append(f"      {desc}")
            lines.append(f"      Sudah menunggu: *{age_str}*")

        if ages:
            avg = sum(ages) // len(ages)
            ah, am = divmod(avg, 60)
            avg_str = f"{ah}j {am}m" if ah > 0 else f"{avg} menit"
            lines.append(f"")
            lines.append(f"  📈 Rata-rata lama pending: *{avg_str}*")
    else:
        lines.append("✅ *Tidak ada tiket aktif saat ini*")

    lines.append("")

    # === Tiket close hari ini ===
    today_str = now.strftime("%d %b %Y")
    today_closed = [r for r in closed if isinstance(r, dict) and today_str in str(r.get("date_created", ""))]
    if today_closed:
        lines.append(f"🏆 *Selesai hari ini ({len(today_closed)} tiket):*")
        for row in today_closed[:8]:
            no   = row.get("no_ticket", "-")
            name = row.get("name", "-")
            lines.append(f"  ✅ [{no}] {name}")
        lines.append("")

    # === Tiket close bulan ini (semua) ===
    if total_closed > 0:
        lines.append(f"📋 *Tiket selesai bulan ini: {total_closed} tiket*")
        for row in closed[:5]:
            if isinstance(row, dict):
                no   = row.get("no_ticket", "-")
                name = row.get("name", "-")
                desc = re.sub(r'<[^>]+>', '', row.get("report", ""))[:30]
                lines.append(f"  ✅ [{no}] {name} — {desc}")
        if total_closed > 5:
            lines.append(f"  _...dan {total_closed - 5} tiket lainnya_")

    lines.append("")
    lines.append("💡 _Response cepat = pelanggan happy = churn rendah_")

    return "\n".join(lines)

if __name__ == "__main__":
    print(run())
