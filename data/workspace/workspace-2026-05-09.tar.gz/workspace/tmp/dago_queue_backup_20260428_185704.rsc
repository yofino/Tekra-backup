# apr/28/2026 18:56:50 by RouterOS 6.48.6
# software id = J6U8-PVK7
#
# model = CCR1009-7G-1C-1S+
# serial number = HD0086H608D
/queue simple add max-limit=10M/10M name="ADE SUPANDI" target=10.20.40.61/32
/queue simple add max-limit=10M/10M name="PAK ANIM ( euis) " target=10.20.30.43/32
/queue simple add max-limit=10M/10M name="IBU YUYUN/BPK ASEP" target=10.20.30.111/32
/queue simple add max-limit=15M/15M name="LISA PRATIWI" target=10.20.30.112/32
/queue simple add max-limit=10M/10M name="PITRIYA NURRAHMI" target=10.20.30.119/32
/queue simple add max-limit=10M/10M name="RANGGA RAHADIANSYAH" target=10.20.30.18/32
/queue simple add max-limit=5M/5M name="NOVAL HENDRAWAN" target=10.20.30.20/32
/queue simple add max-limit=2M/2M name="NENENG CAHYANI" target=10.20.30.21/32
/queue simple add max-limit=10M/10M name="MEGA NINGSIH" target=10.20.30.22/32
/queue simple add max-limit=10M/10M name="REDO ARKUS AGUSTUS" target=10.20.30.25/32
/queue simple add max-limit=10M/10M name="ROSSY WULANSARI" target=10.20.30.24/32
/queue simple add max-limit=10M/10M name="YUDI SURYADI" target=10.20.30.30/32
/queue simple add max-limit=2M/2M name="WULAN HENDRA" target=10.20.30.31/32
/queue simple add max-limit=5M/5M name="PEPEN (port)" target=10.20.30.34/32
/queue simple add max-limit=10M/10M name=SRIYANI target=10.20.30.36/32
/queue simple add max-limit=2M/2M name=IKIN target=10.20.30.37/32
/queue simple add max-limit=2M/2M name=HENDI target=10.20.30.38/32
/queue simple add max-limit=10M/10M name=RANDI target=10.20.30.39/32
/queue simple add max-limit=2M/2M name=SATIANA target=10.20.30.35/32
/queue simple add max-limit=15M/15M name=RATNASIH target=10.20.30.17/32
/queue simple add max-limit=2M/2M name="ADE TOKO" target=10.20.30.19/32
/queue simple add max-limit=5M/5M name=queue1 target=10.20.30.11/32
/queue simple add max-limit=10M/10M name="TEH IPEY" target=10.20.30.6/32
/queue simple add max-limit=10M/10M name=ARNOAH target=10.20.30.14/32
/queue simple add max-limit=10M/10M name=ARYANTO target=10.20.30.44/32
/queue simple add max-limit=10M/10M name="TIA SETIAWATI" target=10.20.30.45/32
/queue simple add max-limit=10M/10M name="DINDIN SAHIDIN" target=10.20.30.46/32
/queue simple add max-limit=2M/2M name=PIPIH target=10.20.30.48/32
/queue simple add max-limit=15M/15M name=HAERUDIN target=10.20.30.33/32
/queue simple add max-limit=5M/5M name="WAHYUDIN (PORT)" target=10.20.30.40/32
/queue simple add max-limit=15M/15M name=JAY target=10.20.30.41/32
/queue simple add max-limit=10M/10M name="ROSITA (port)" target=10.20.30.42/32
/queue simple add max-limit=5M/5M name="APENG SURIP" target=10.20.30.47/32
/queue simple add max-limit=5M/5M name="HENI ROHAENI" target=10.20.30.50/32
/queue simple add max-limit=10M/10M name="SADAM HUSEIN" target=10.20.30.52/32
/queue simple add max-limit=10M/10M name="SITI DIAH K (port)" target=10.20.30.51/32
/queue simple add max-limit=10M/10M name="YETI CIRAPUHAN" target=10.20.30.53/32
/queue simple add max-limit=10M/10M name=ALFIAN target=10.20.30.55/32
/queue simple add max-limit=5M/5M name="UMA (PORT)" target=10.20.30.56/32
/queue simple add max-limit=10M/10M name="YUMI ARTI" target=10.20.30.57/32
/queue simple add max-limit=10M/10M name="TIARA RATIH STATIK" target=10.20.30.60/32
/queue simple add max-limit=10M/10M name="DADANG HERDIANSYAH" target=10.20.30.54/32
/queue simple add max-limit=10M/10M name="NOVA LESMANA" target=10.20.30.58/32
/queue simple add max-limit=10M/10M name="DEDE LUKI" target=10.20.30.59/32
/queue simple add max-limit=10M/10M name=DANI target=10.20.30.61/32
/queue simple add max-limit=5M/5M name="RINA JUJU" target=10.20.30.62/32
/queue simple add max-limit=2M/2M name=MARYANI target=10.20.30.63/32
/queue simple add max-limit=2M/2M name="DYAH MELYA" target=10.20.30.65/32
/queue simple add max-limit=2M/2M name="KUSNADI INDRA" target=10.20.30.67/32
/queue simple add max-limit=2M/2M name="RIKI MOHAMAD RAMDAN" target=10.20.30.69/32
/queue simple add max-limit=10M/10M name="YUYUN YUSI" target=10.20.30.72/32
/queue simple add max-limit=10M/10M name=BAYU target=10.20.30.73/32
/queue simple add max-limit=10M/10M name=RAFA target=10.20.30.74/32
/queue simple add max-limit=10M/10M name="REVAL SINGAGATI" target=10.20.30.76/32
/queue simple add max-limit=5M/5M name="FARID MARUF" target=10.20.30.75/32
/queue simple add max-limit=2M/2M name=NURAENI target=10.20.30.77/32
/queue simple add max-limit=2M/2M name="ELSA IRMA SARI" target=10.20.30.78/32
/queue simple add max-limit=10M/10M name="SAKILAH ARYANI PRATIWI" target=10.20.30.79/32
/queue simple add max-limit=2M/2M name=ALAN target=10.20.30.82/32
/queue simple add max-limit=5M/5M name="RIZKY AYU" target=10.20.30.83/32
/queue simple add max-limit=15M/15M name="SITI KOMARIAH" target=10.20.30.84/32
/queue simple add max-limit=10M/10M name=AJI target=10.20.30.86/32
/queue simple add max-limit=1M/1M name="YETI (PORT) " target=10.20.30.87/32
/queue simple add max-limit=5M/5M name=DEDI target=10.20.30.88/32
/queue simple add max-limit=10M/10M name="DENI SINGGAGATI" target=10.20.30.90/32
/queue simple add max-limit=2M/2M name="RENDY AGUSTIAN KOBOY" target=10.20.30.91/32
/queue simple add max-limit=10M/10M name="NUNING TUTIATI" target=10.20.30.93/32
/queue simple add max-limit=10M/10M name="SRI JULIANA" target=10.20.30.94/32
/queue simple add max-limit=2M/2M name=WIDANINGSIH target=10.20.30.95/32
/queue simple add max-limit=2M/2M name=EUIS target=10.20.30.96/32
/queue simple add max-limit=10M/10M name=RINI target=10.20.30.92/32
/queue simple add max-limit=10M/10M name="DEPI KURNIAWAN" target=10.20.30.8/32
/queue simple add name="TOTAL BANDWIT"
/queue simple add max-limit=10M/10M name="MIA ELOS" target=10.20.30.100/32
/queue simple add max-limit=10M/10M name=SURYADI target=10.20.30.102/32
/queue simple add max-limit=10M/10M name="TRISA ASMIATI" target=10.20.30.101/32
/queue simple add max-limit=2M/2M name="IJANG WAHYUDIN" target=10.20.30.106/32
/queue simple add max-limit=10M/10M name=ANDIKA target=10.20.30.105/32
/queue simple add max-limit=10M/10M name=ANGGITA target=10.20.30.107/32
/queue simple add max-limit=10M/10M name="BU RINI PORT NOPIK" target=10.20.30.103/32
/queue simple add max-limit=10M/10M name="NANDA NADIA" target=10.20.30.108/32
/queue simple add max-limit=10M/10M name="DIAH HASANAH" target=10.20.30.110/32
/queue simple add max-limit=10M/10M name="LILIS ELOS" target=10.20.30.99/32
/queue simple add max-limit=10M/10M name=EGI target=10.20.30.115/32
/queue simple add max-limit=10M/10M name="RENA DELIANTI" target=10.20.30.116/32
/queue simple add max-limit=10M/10M name=KRISNA target=10.20.30.113/32
/queue simple add max-limit=10M/10M name="ELISA DESWITA AMALIA" target=10.20.30.117/32
/queue simple add max-limit=10M/10M name=YAYAN target=10.20.30.118/32
/queue simple add max-limit=10M/10M name=YANTI target=10.20.30.119/32
/queue simple add max-limit=10M/10M name="PITO TABAH" target=10.20.30.122/32
/queue simple add max-limit=10M/10M name="TATA " target=10.20.30.114/32
/queue simple add max-limit=10M/10M name=ANDRI target=10.20.30.124/32
/queue simple add max-limit=10M/10M name="NENENG ROHAENI" target=10.20.30.125/32
/queue simple add max-limit=10M/10M name="AAS ASTUTI" target=10.20.30.120/32
/queue simple add max-limit=10M/10M name="NOVI PADANG" target=10.20.30.127/32
/queue simple add max-limit=10M/10M name="NISA NURJANAH" target=10.20.30.128/32
/queue simple add max-limit=10M/10M name=DEDE target=10.20.30.129/32
/queue simple add max-limit=10M/10M name="TJUTJU MULYANA" target=10.20.30.126/32
/queue simple add max-limit=10M/10M name="WAHYU SINGGATI ( PORT) " target=10.20.30.131/32
/queue simple add max-limit=10M/10M name="JEJEN SETIAWAN" target=10.20.30.132/32
/queue simple add max-limit=10M/10M name="DINA AZAHRA" target=10.20.30.133/32
/queue simple add max-limit=2M/2M name=ROSMIATI target=10.20.30.137/32
/queue simple add max-limit=10M/10M name="samsul maarif" target=10.20.30.134/32
/queue simple add max-limit=10M/10M name="SITI SARIFAH" target=10.20.30.135/32
/queue simple add max-limit=10M/10M name=IWAN target=10.20.30.136/32
/queue simple add max-limit=10M/10M name=RIDWAN target=10.20.30.138/32
/queue simple add max-limit=10M/10M name=YENI target=10.20.30.139/32
/queue simple add max-limit=10M/10M name="DEVI ROSITA" target=10.20.30.140/32
/queue simple add max-limit=2M/2M name="SITI SALAMAH" target=10.20.30.141/32
/queue simple add max-limit=2M/2M name="RINI RT 4" target=10.20.30.142/32
/queue simple add max-limit=10M/10M name="ELAH AISYAH" target=10.20.30.143/32
/queue simple add max-limit=2M/2M name=FAZAR target=10.20.30.130/32
/queue simple add max-limit=10M/10M name=ESIH target=10.20.30.144/32
/queue simple add max-limit=10M/10M name="RIAN SONJAYA" target=10.20.30.145/32
/queue simple add max-limit=10M/10M name="LUFTI MUBAROK" target=10.20.30.147/32
/queue simple add max-limit=10M/10M name=KARTONO target=10.20.30.148/32
/queue simple add max-limit=10M/10M name="BU WATI" target=10.20.30.149/32
/queue simple add max-limit=10M/10M name="ELLA KURNIATI" target=10.20.30.150/32
/queue simple add max-limit=10M/10M name=FIQRI target=10.20.30.151/32
/queue simple add max-limit=10M/10M name="PIAH SUPIAH" target=10.20.30.152/32
/queue simple add max-limit=10M/10M name="RIDOAN EFENDI" target=10.20.30.153/32
/queue simple add max-limit=10M/10M name=ROSMAWATI target=10.20.30.155/32
/queue simple add max-limit=10M/10M name="WIDA YANTI" target=10.20.30.156/32
/queue simple add max-limit=10M/10M name="ANI SURYANI" target=10.20.30.157/32
/queue simple add max-limit=10M/10M name="RINA ANGGRAENI" target=10.20.30.158/32
/queue simple add max-limit=10M/10M name=RIKA target=10.20.30.169/32
/queue simple add max-limit=2M/2M name=WAHYU target=10.20.30.154/32
/queue simple add max-limit=15M/15M name="liska vidia" target=10.20.30.160/32
/queue simple add max-limit=10M/10M name="RIRIN RIANDA" target=10.20.30.161/32
/queue simple add max-limit=10M/10M name=ONENG target=10.20.30.165/32
/queue simple add max-limit=10M/10M name=LENI target=10.20.30.164/32
/queue simple add max-limit=10M/10M name="SHERA WIDYA PUTRI UTAMI" target=10.20.30.168/32
/queue simple add max-limit=10M/10M name=queue2 target=10.20.30.169/32
/queue simple add max-limit=15M/15M name=JOSTA target=10.20.30.171/32
/queue simple add max-limit=10M/10M name="RIADI SOMANTRI" target=10.20.30.170/32
/queue simple add max-limit=2M/2M name=PUNGKI target=10.20.30.173/32
/queue simple add max-limit=10M/10M name="LINA WATI" target=10.20.30.174/32
/queue simple add max-limit=15M/15M name="TRY LYSTINA(port) " target=10.20.30.175/32
/queue simple add max-limit=20M/20M name=SULIS target=10.20.30.167/32
/queue simple add max-limit=10M/10M name="NENDEN ELVAPUSPITA" target=10.20.30.176/32
/queue simple add max-limit=15M/15M name=TREESHIA target=10.20.30.172/32
/queue simple add max-limit=10M/10M name="DEVI SUMIATI" target=10.20.30.178/32
/queue simple add max-limit=10M/10M name="EYET ROHAYAT" target=10.20.30.177/32
/queue simple add max-limit=10M/10M name="ADE KANDA" target=10.20.30.179/32
/queue simple add max-limit=10M/10M name="PANCAR PUSPA" target=10.20.30.180/32
/queue simple add max-limit=10M/10M name="JAJANG BUDI ABEK STATIC" target=10.20.30.181/32
/queue simple add max-limit=15M/15M name=SAEPUDIN target=10.20.30.186/32
/queue simple add max-limit=10M/10M name=OTEN target=10.20.30.187/32
/queue simple add max-limit=10M/10M name="RITA PEBRITA" target=10.20.30.188/32
/queue simple add max-limit=2M/2M name=ROHIMAT target=10.20.30.189/32
/queue simple add max-limit=2M/2M name="WAHYU HUDAYAT" target=10.20.30.190/32
/queue simple add max-limit=2M/2M name="JAJANG HADI" target=10.20.30.193/32
/queue simple add max-limit=10M/10M name="NUNU NUGRAHA" target=10.20.30.191/32
/queue simple add max-limit=10M/10M name=SOPIAN target=10.20.30.182/32
/queue simple add max-limit=10M/10M name=IYANG target=10.20.30.195/32
/queue simple add max-limit=2M/2M name=ENTIS target=10.20.30.196/32
/queue simple add max-limit=10M/10M name="NUR KANIFAH" target=10.20.30.197/32
/queue simple add max-limit=10M/10M name=KOMALASARI target=10.20.30.202/32
/queue simple add max-limit=10M/10M name=SUTISNA target=10.20.30.199/32
/queue simple add max-limit=10M/10M name="AJI SETIAJI" target=10.20.30.204/32
/queue simple add max-limit=10M/10M name="SIPA NURJANAH" target=10.20.30.205/32
/queue simple add max-limit=2M/2M name="ULFI NUR" target=10.20.30.198/32
/queue simple add max-limit=10M/10M name="NENDEN SITI JULAEHA" target=10.20.30.201/32
/queue simple add max-limit=10M/10M name="RIZKY NUR RAMDHAN" target=10.20.30.200/32
/queue simple add max-limit=10M/10M name="MIA ROSMIAATI" target=10.20.30.203/32
/queue simple add max-limit=10M/10M name="RIKA ATTY" target=10.20.30.206/32
/queue simple add max-limit=10M/10M name="EVI RAMAYANTI" target=10.20.30.194/32
/queue simple add max-limit=2M/2M name=KHOLIS target=10.20.30.208/32
/queue simple add max-limit=10M/10M name=GILANG target=10.20.30.209/32
/queue simple add max-limit=2M/2M name="NCIH CARSIH" target=10.20.30.210/32
/queue simple add max-limit=10M/10M name="ONGKI ARDIANSYAH" target=10.20.30.212/32
/queue simple add max-limit=10M/10M name="DEDE INTAN KARTIKA" target=10.20.30.213/32
/queue simple add max-limit=10M/10M name="RIZWAN GUSTIAWAN" target=10.20.30.207/32
/queue simple add max-limit=10M/10M name=TRIYANTI target=10.20.30.215/32
/queue simple add max-limit=10M/10M name="WAHYUDIN PAKAR" target=10.20.30.217/32
/queue simple add max-limit=10M/10M name="KARTIKA PAKAR" target=10.20.30.218/32
/queue simple add max-limit=10M/10M name="AI KURNIA" target=10.20.30.219/32
/queue simple add max-limit=10M/10M name=ZETI target=10.20.30.220/32
/queue simple add max-limit=10M/10M name="AHMAD SAEPUDIN" target=10.20.30.214/32
/queue simple add max-limit=10M/10M name="ASEP MIMIN" target=10.20.30.221/32
/queue simple add max-limit=10M/10M name="IRMA NURMAWATI" target=10.20.30.222/32
/queue simple add max-limit=10M/10M name="DADANG RAMDANI" target=10.20.30.223/32
/queue simple add max-limit=10M/10M name="DENI HIDAYAT" target=10.20.30.224/32
/queue simple add max-limit=10M/10M name="NURI HIDAYANTI" target=10.20.30.226/32
/queue simple add max-limit=10M/10M name=LUDIAH target=10.20.30.225/32
/queue simple add max-limit=10M/10M name="SERLI YULIANI" target=10.20.30.230/32
/queue simple add max-limit=10M/10M name=GUNAWAN target=10.20.30.231/32
/queue simple add max-limit=10M/10M name=RISMA target=10.20.30.232/32
/queue simple add max-limit=10M/10M name="RIDWAN SINGAGATI" target=10.20.30.234/32
/queue simple add max-limit=10M/10M name="TITIN SETIAWAN" target=10.20.30.227/32
/queue simple add max-limit=10M/10M name="SITI ROHMANAH" target=10.20.40.15/32
/queue simple add max-limit=10M/10M name="WIWIN WINARTI" target=10.20.30.245/32
/queue simple add max-limit=10M/10M name="YANA RUHIAT" target=10.20.30.242/32
/queue simple add max-limit=10M/10M name="TANTI SUSANTI" target=10.20.40.18/32
/queue simple add max-limit=10M/10M name="SONY IRAWAN" target=10.20.30.239/32
/queue simple add max-limit=10M/10M name="SRI MULYANI" target=10.20.40.14/32
/queue simple add max-limit=15M/15M name="RIZKY HAPIPAH" target=10.20.30.244/32
/queue simple add max-limit=10M/10M name="RANI APRIYANI" target=10.20.40.31/32
/queue simple add max-limit=10M/10M name="HAPID BURHANUDIN" target=10.20.40.22/32
/queue simple add max-limit=10M/10M name=ASTUTI target=10.20.40.21/32
/queue simple add max-limit=10M/10M name=DISYA target=10.20.30.233/32
/queue simple add max-limit=10M/10M name="ERIN AYU WULANDARI" target=10.20.40.25/32
/queue simple add max-limit=10M/10M name="SUSAN SUSANTI" target=10.20.30.248/32
/queue simple add max-limit=10M/10M name="NURUL KURNIAWATI" target=10.20.30.66/32
/queue simple add max-limit=15M/15M name="TRI SURYANTO" target=10.20.30.236/32
/queue simple add max-limit=10M/10M name="EUIS RITAWATI" target=10.20.40.36/32
/queue simple add max-limit=10M/10M name=HENIFAH target=10.20.40.30/32
/queue simple add max-limit=10M/10M name="DEDE EDIH" target=10.20.30.192/32
/queue simple add max-limit=15M/15M name="TETI SUSANTI" target=10.20.40.38/32
/queue simple add max-limit=15M/15M name="Maya Pujianti Putri" target=10.20.30.184/32
/queue simple add max-limit=15M/15M name="NUNUNG SARININGSIH" target=10.20.30.109/32
/queue simple add max-limit=15M/15M name="YEYET MARYANI" target=10.20.30.166/32
/queue simple add max-limit=10M/10M name="DADANG HERMAWAN" target=10.20.30.240/32
/queue simple add max-limit=10M/10M name="YANI SURYANI" target=10.20.40.52/32
/queue simple add max-limit=15M/15M name=KOSAN target=10.20.30.70/32
/queue simple add max-limit=10M/10M name="MUHAMAD GUSTIAN" target=10.20.40.39/32
/queue simple add max-limit=10M/10M name="NOVIA HILDA SAHIRA" target=10.20.30.49/32
/queue simple add max-limit=15M/15M name="IMAS MASYITOH" target=10.20.30.68/32
/queue simple add max-limit=15M/15M name="KARYATI DRA" target=10.20.30.159/32
/queue simple add max-limit=10M/10M name="DINI PRATIWI" target=10.20.40.34/32
/queue simple add max-limit=10M/10M name="ADE KOSWARA" target=10.20.40.51/32
/queue simple add max-limit=10M/10M name=MELI target=10.20.30.60/32
/queue simple add max-limit=10M/10M name="ILYAS RUHIYAT." target=10.20.30.71/32
/queue simple add max-limit=10M/10M name="KRISNA KURNAESIH" target=10.20.40.28/32
/queue simple add max-limit=10M/10M name="IRGI RENALDI" target=10.20.40.64/32
/queue simple add name=PARRENT queue=SFQ/SFQ target=10.0.0.0/8
/queue simple add name=PAKET2 parent=PARRENT queue=pcq-up-10/pcq-down-10 target=10.12.0.0/21
/queue simple add name=PAKET3 parent=PARRENT queue=pcq-up-15/pcq-down-15 target=10.13.0.0/24
/queue simple add name=PAKET4 parent=PARRENT queue=pcq-up-20/pcq-down-20 target=10.14.0.0/24
/queue simple add name=PAKET5 parent=PARRENT queue=pcq-up-30/pcq-down-30 target=10.15.0.0/24
/queue simple add name=PAKET1 parent=PARRENT queue=pcq-up-2/pcq-down-2 target=10.11.0.0/24
