# POP Dago - Reference

## Ringkasan
- **PIC:** Jay (+6281320385966)
- **Portal:** north.my.id
- **ISP:** Simaya (PBR only), MyRep ×3 (250M), Sunmory (300M)
- **Total Kapasitas:** 1.150M | **LB Aktif:** 1.050M

## MikroTik Dago (CCR1009-7G-1C-1S+)
- **IP:** 10.6.0.2 (via OVPN tunnel CCR1 Pusat)
- **SSH:** asep / asep$888 port 18
- **RouterOS:** 6.48.6 (long-term)
- **CPU:** tilegx 9-core @ 1.2GHz, load ~82%
- **RAM:** 2GB
- **Uptime:** mingguan

### Interface
| Interface | Nama | Fungsi |
|---|---|---|
| ether1 | SIMAYA | Simaya PBR |
| ether2 | SWITCH TO LAN | Switch lokal |
| ether3 | SWITCH TO FO | Switch FO |
| ether4 | SUNMORI | Sunmori |
| ether5 | OLT-HSGQ | OLT HSGQ |
| ether6 | TO OLT-HIOSO | OLT HIOSO |
| ether7 | - | - |
| sfp-sfpplus1 | - | 10G kosong |

### IP Addresses
| IP | Network | Interface |
|---|---|---|
| 115.178.48.106/30 | 115.178.48.104 | ether1-SIMAYA |
| 192.168.123.50/24 | 192.168.123.0 | ether4-SUNMORI |
| 10.20.30.1/24 | 10.20.30.0 | MASTER |
| 10.20.40.1/24 | 10.20.40.0 | MASTER |
| 10.20.64.1/20 | 10.20.64.0 | vlan100-TR069 |
| 10.8.0.1/24 | 10.8.0.0 | VLAN-HOTSPOT |
| 192.168.78.1/24 | 192.168.78.0 | vlan3-MGMT |
| 10.6.0.2/24 | 10.6.0.0 | TUNNEL-CCR1-PUSAT-OVPN |
| 172.29.0.78/22 | 172.29.0.0 | tunnel-31734 |

### Tunnel OVPN
| Tunnel | Type | IP | Connect To | Mode |
|---|---|---|---|---|
| TUNNEL-CCR1-PUSAT-OVPN | ovpn-out | 10.6.0.2/24 | pfSense Dago port 1000 | ethernet |
| tunnel-31734 | ovpn-out | 172.29.0.78/22 | id-27.tunnel.web.id:1194 | ip |

### Route
- Main: 0.0.0.0/0 → 192.168.123.1 (via Sunmori/pfSense)
- Backup: 0.0.0.0/0 → 115.178.48.105 (Simaya)
- ACS (10.10.10.230) via 10.6.0.1 (tunnel CCR1)

## pfSense Dago
- **URL:** https://115.178.49.186:1042
- **Login:** admin / k34Nu335577
- **Suhu:** ~57-64°C
- **Hardware:** Celeron J1900, Intel 82574L NIC

### WAN
|| WAN | ISP | Gateway | Interface | Bandwidth |
||---|---|---|---|---|
|| WAN1 | MyRep 1 | 192.168.41.1 | em0 | 250M |
|| WAN2 | MyRep 2 | 192.168.42.1 | em1 | 250M |
|| WAN3 | Sunmori | 192.168.43.1 | em2 | 300M |
|| WAN4 | MyRep 3 | 192.168.44.1 | em3 | 500M |

### Known Issues
- WAN4 (em3) kadang hang → bounce interface: `ifconfig em3 down; sleep 3; ifconfig em3 up`
- EEE disabled: `dev.em.3.eee_control=0` di `/boot/loader.conf.local`
- NIC Intel 82574L aging, perlu dipantau

## OLT (2 unit)
- **OLT HSGQ** — via ether5
- **OLT HIOSO** — via ether6
- IP OLT belum terdokumentasi
