#!/bin/bash
# Watchdog pfSense Dago WAN status — only alerts when WAN goes OFFLINE
# Silent when all WANs online

STATE_FILE="/tmp/pfsense_dago_wan_state.txt"
LOGIN_COOKIE="/tmp/pfsense_dago_check.txt"

# Login + get gateway widget
CSRF=$(curl -sk -c "$LOGIN_COOKIE" "https://115.178.49.186:1042/" 2>/dev/null | grep -oP "name='__csrf_magic'\s+value=\"\K[^\"]+")
curl -sk -b "$LOGIN_COOKIE" -c "$LOGIN_COOKIE" \
  -d "__csrf_magic=${CSRF}&usernamefld=admin&passwordfld=k34Nu335577&login=Login" \
  "https://115.178.49.186:1042/" -o /dev/null 2>/dev/null

GW_HTML=$(curl -sk -b "$LOGIN_COOKIE" "https://115.178.49.186:1042/widgets/widgets/gateways.widget.php" 2>/dev/null)

# Parse: extract all text content from table
CURRENT=""
echo "$GW_HTML" | python3 -c "
import sys, re
html = sys.stdin.read()
cells = re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>', html, re.DOTALL)
cleaned = [re.sub(r'<[^>]+>', '', c).strip() for c in cells if re.sub(r'<[^>]+>', '', c).strip()]
for i, c in enumerate(cleaned):
    if c.startswith('WAN') and i+4 < len(cleaned):
        gw = c[4:].strip()
        rtt = cleaned[i+1]
        loss = cleaned[i+2]
        status = cleaned[i+3]
        name = c[:4]
        line = f'{name}|{gw}|{rtt}|{loss}|{status}'
        print(line)
" > /tmp/pfsense_wan_current.txt

# Compare with previous state
CHANGED=""
if [ -f "$STATE_FILE" ]; then
    while IFS='|' read -r name gw rtt loss status; do
        prev_line=$(grep "^$name|" "$STATE_FILE" 2>/dev/null)
        if [ -z "$prev_line" ]; then
            # New WAN appeared
            CHANGED="${CHANGED}🆕 $name ($gw): $status
"
        else
            prev_status=$(echo "$prev_line" | cut -d'|' -f5)
            if [ "$status" != "$prev_status" ]; then
                if echo "$status" | grep -q "Off"; then
                    CHANGED="${CHANGED}🔴 $name ($gw): ONLINE → OFFLINE
"
                elif echo "$status" | grep -q "On"; then
                    CHANGED="${CHANGED}🟢 $name ($gw): OFFLINE → ONLINE ✅
"
                fi
            fi
        fi
    done < /tmp/pfsense_wan_current.txt
    
    # Check for removed WANs
    while IFS='|' read -r name gw rtt loss status; do
        if ! grep -q "^$name|" /tmp/pfsense_wan_current.txt; then
            CHANGED="${CHANGED}⚠️ $name ($gw): REMOVED
"
        fi
    done < "$STATE_FILE"
else
    # First run — show current state
    CHANGED="📊 pfSense Dago WAN Status:
"
    while IFS='|' read -r name gw rtt loss status; do
        icon="🟢"
        echo "$status" | grep -q "Off" && icon="🔴"
        CHANGED="${CHANGED}${icon} $name: $gw | $loss
"
    done < /tmp/pfsense_wan_current.txt
fi

# Output if changed
if [ -n "$CHANGED" ]; then
    cp /tmp/pfsense_wan_current.txt "$STATE_FILE"
    echo "$CHANGED"
fi
