#!/bin/bash
# Monitor AI Agents - Zara (Pak Jemmy) & Anatasya (Pak Ryan)
# Host: Nocita VPS 103.129.148.97, user: keanuvps

NOCITA="103.129.148.97"
USER="keanuvps"
REPORT=""

check_docker_container() {
    local NAME="$1"
    local CONTAINER="$2"
    
    # Check container status via Docker
    STATUS=$(ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$NOCITA" \
        "sudo docker inspect -f '{{.State.Status}}' $CONTAINER 2>/dev/null" 2>/dev/null)
    
    if [ -z "$STATUS" ]; then
        REPORT="${REPORT}🔴 ${NAME}: Container ga ada/ga bisa diakses\n"
        return 1
    fi
    
    if [ "$STATUS" != "running" ]; then
        REPORT="${REPORT}🔴 ${NAME}: Container status=${STATUS}\n"
        return 1
    fi
    
    # Health check
    HEALTH=$(ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$NOCITA" \
        "sudo docker inspect -f '{{.State.Health.Status}}' $CONTAINER 2>/dev/null" 2>/dev/null)
    
    # Uptime (started time)
    STARTED=$(ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "$USER@$NOCITA" \
        "sudo docker inspect -f '{{.State.StartedAt}}' $CONTAINER 2>/dev/null" 2>/dev/null)
    
    REPORT="${REPORT}🟢 ${NAME}: UP (health=${HEALTH:-N/A}, started=${STARTED})\n"
}

check_docker_container "Zara" "openclaw-zara"
check_docker_container "Anatasya" "openclaw-ana"

echo -e "$REPORT"
